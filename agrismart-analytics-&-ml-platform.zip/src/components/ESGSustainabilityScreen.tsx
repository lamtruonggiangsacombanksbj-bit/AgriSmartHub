import React, { useState, useMemo } from "react";
import { 
  Leaf, 
  Wind, 
  Droplet, 
  Cpu, 
  Compass, 
  Award, 
  CheckCircle,
  HelpCircle,
  TrendingDown,
  Sparkles
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip
} from "recharts";

export default function ESGSustainabilityScreen() {
  // Input parameters for Carbon Footprint Calculator
  const [dieselLiters, setDieselLiters] = useState(120); // liters of diesel
  const [inorganicFertilizerKg, setInorganicFertilizerKg] = useState(450); // kg of inorganic NPK
  const [electricityKWh, setElectricityKWh] = useState(850); // kWh grid power
  const [compostWasteKg, setCompostWasteKg] = useState(1200); // organic compost waste recycled (offsets carbon!)

  const carbonCalculation = useMemo(() => {
    // Standard GHG protocol emission factors
    const dieselEmissions = dieselLiters * 2.68; // 2.68 kg CO2e per liter
    const fertilizerEmissions = inorganicFertilizerKg * 1.5; // 1.5 kg CO2e per kg NPK
    const gridEmissions = electricityKWh * 0.72; // 0.72 kg CO2e per kWh
    const offsetCredits = compostWasteKg * 0.4; // organic waste recycling saves 0.4 kg CO2e per kg

    const totalEmissionsRaw = dieselEmissions + fertilizerEmissions + gridEmissions - offsetCredits;
    const netEmissions = Math.max(totalEmissionsRaw, 50); // floor to 50 kg CO2e
    
    // Rating classification
    let rating = "A - Xuất Sắc (Low Carbon)";
    let ringColor = "text-emerald-400";
    if (netEmissions > 1500) {
      rating = "C - Trung bình (Cần cải thiện bón phân)";
      ringColor = "text-amber-400";
    } else if (netEmissions > 800) {
      rating = "B - Khá (Tiêu chuẩn VietGAP)";
      ringColor = "text-sky-400";
    }

    return {
      dieselEmissions,
      fertilizerEmissions,
      gridEmissions,
      offsetCredits,
      netEmissions,
      rating,
      ringColor
    };
  }, [dieselLiters, inorganicFertilizerKg, electricityKWh, compostWasteKg]);

  // Environmental scores across five axes
  const esgScores = [
    { name: "Độ đa dạng sinh học", score: 85, desc: "Bảo tồn thảm cỏ tự nhiên vùng sầu riêng" },
    { name: "Tiết kiệm tài nguyên nước", score: 92, desc: "Tưới nhỏ giọt nhỏ giọt định lượng IoT" },
    { name: "Mức độ hữu cơ hóa đất", score: 78, desc: "Tận dụng mùn bã sầu riêng và phân hữu cơ" },
    { name: "An toàn lao động CTV", score: 95, desc: "Trang bị đầy đủ bảo hộ, quản lý ca thông minh" },
    { name: "Khả năng giảm phát thải CO2", score: 80, desc: "Sử dụng pin mặt trời và bơm biến tần" },
  ];

  // Mock historical carbon intensity trend
  const historyData = [
    { year: "2022", CO2: 2400 },
    { year: "2023", CO2: 2150 },
    { year: "2024", CO2: 1800 },
    { year: "2025", CO2: 1450 },
    { year: "2026", CO2: 980 },
  ];

  return (
    <div className="space-y-6 text-slate-200">
      
      {/* Title block */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900/40 p-5 rounded-2xl border border-slate-800/60 backdrop-blur-md">
        <div>
          <h2 className="text-xl font-black text-slate-100 flex items-center gap-2.5 uppercase tracking-tight">
            <span className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
              <Leaf className="w-5 h-5" />
            </span>
            Chỉ số ESG & Canh tác Nông nghiệp Bền vững
          </h2>
          <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
            Hệ thống theo dõi phát thải nhà kính CO2 thực tế, kiểm soát lượng tài nguyên nước ngầm tưới tiêu, tái chế phế phẩm nông nghiệp hữu cơ và xếp hạng đạt tiêu chuẩn xanh toàn quốc.
          </p>
        </div>
        <span className="px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/30 text-[10px] font-black uppercase text-emerald-400 rounded-xl block shrink-0">
          Xếp hạng: Net Zero Ready
        </span>
      </div>

      {/* Highlights metrics cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 flex items-center gap-4">
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl shrink-0">
            <Wind className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Tổng Giảm phát thải CO2</span>
            <strong className="text-lg text-slate-100 font-mono font-black">-1.42 Tấn CO2e</strong>
            <span className="text-[9px] text-emerald-400 block mt-0.5">Tiết kiệm nhờ tối ưu hóa phân vi lượng</span>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 flex items-center gap-4">
          <div className="p-3 bg-sky-500/10 border border-sky-500/20 text-sky-400 rounded-xl shrink-0">
            <Droplet className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Tổng nước ngầm tiết kiệm</span>
            <strong className="text-lg text-slate-100 font-mono font-black">2.450 m³ Nước</strong>
            <span className="text-[9px] text-sky-400 block mt-0.5">Bình quân giảm 35% lượng nước tưới tiêu</span>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 flex items-center gap-4">
          <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-xl shrink-0">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Chứng chỉ Xanh Quốc tế đạt</span>
            <strong className="text-lg text-slate-100 font-mono font-black">VietGAP & GlobalGAP</strong>
            <span className="text-[9px] text-emerald-400 block mt-0.5">Tiêu chuẩn truy xuất Blockchain đồng bộ</span>
          </div>
        </div>

      </div>

      {/* Main Carbon Calculator & ESG checklist radar layout */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        
        {/* Interactive GHG / Carbon Footprint Calculator */}
        <div className="lg:col-span-3 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800/60 pb-3">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-emerald-400" />
              <h3 className="text-xs font-black text-slate-100 uppercase tracking-wider">Trình Máy tính phát thải Carbon Carbon Footprint (CO2 Equivalent)</h3>
            </div>
            <span className="text-[8px] bg-slate-950 px-1.5 py-0.5 rounded text-emerald-400 border border-emerald-500/20 font-black">ISO 14064 Standard</span>
          </div>

          <div className="space-y-4">
            
            {/* Control 1 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-400">Nhiên liệu Diesel vận hành máy bơm, máy kéo (Lít/năm):</span>
                <span className="text-amber-500 font-mono font-black">{dieselLiters} Lít</span>
              </div>
              <input
                type="range"
                min="0"
                max="500"
                step="10"
                value={dieselLiters}
                onChange={(e) => setDieselLiters(Number(e.target.value))}
                className="w-full h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
            </div>

            {/* Control 2 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-400">Lượng phân bón vô cơ NPK hóa học bón (Kg/năm):</span>
                <span className="text-rose-400 font-mono font-black">{inorganicFertilizerKg} Kg</span>
              </div>
              <input
                type="range"
                min="0"
                max="1500"
                step="50"
                value={inorganicFertilizerKg}
                onChange={(e) => setInorganicFertilizerKg(Number(e.target.value))}
                className="w-full h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-rose-400"
              />
            </div>

            {/* Control 3 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-400">Điện năng tiêu thụ lưới sưởi, tưới phun sương (kWh/năm):</span>
                <span className="text-sky-400 font-mono font-black">{electricityKWh} kWh</span>
              </div>
              <input
                type="range"
                min="100"
                max="3000"
                step="50"
                value={electricityKWh}
                onChange={(e) => setElectricityKWh(Number(e.target.value))}
                className="w-full h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-sky-400"
              />
            </div>

            {/* Control 4 - Offset organically! */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-400">Thu gom & ủ phân compost hữu cơ rác sầu riêng (Kg/năm):</span>
                <span className="text-emerald-400 font-mono font-black">{compostWasteKg} Kg (Chỉ số bù trừ)</span>
              </div>
              <input
                type="range"
                min="0"
                max="3000"
                step="100"
                value={compostWasteKg}
                onChange={(e) => setCompostWasteKg(Number(e.target.value))}
                className="w-full h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-emerald-400"
              />
            </div>

          </div>

          {/* Result Calculation panel */}
          <div className="bg-slate-950 border border-slate-900 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mt-4">
            <div>
              <span className="text-[10px] text-slate-500 uppercase block font-bold">Lượng phát thải ròng thực tế (Net CO2 Equivalent)</span>
              <strong className="text-xl text-slate-100 font-mono font-black block mt-1">
                {carbonCalculation.netEmissions.toFixed(0)} <span className="text-xs">kg CO2e / vụ</span>
              </strong>
              <div className="text-[10px] text-slate-400 mt-1 leading-relaxed">
                Chi tiết: Diesel (+{carbonCalculation.dieselEmissions.toFixed(0)}kg) • NPK (+{carbonCalculation.fertilizerEmissions.toFixed(0)}kg) • Điện (+{carbonCalculation.gridEmissions.toFixed(0)}kg) • Compost (-{carbonCalculation.offsetCredits.toFixed(0)}kg)
              </div>
            </div>

            <div className="bg-slate-900/60 border border-slate-850 p-3 rounded-xl shrink-0 text-center">
              <span className="text-[9px] text-slate-500 uppercase block font-black">Xếp hạng ESG Nông trại</span>
              <span className={`text-xs font-black block mt-1 ${carbonCalculation.ringColor}`}>
                {carbonCalculation.rating}
              </span>
            </div>
          </div>

        </div>

        {/* ESG Historical chart decrease graph */}
        <div className="lg:col-span-2 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="border-b border-slate-800/60 pb-3 mb-4">
              <h3 className="text-xs font-black text-slate-100 uppercase tracking-wider">Lộ trình cắt giảm Carbon hàng năm</h3>
              <p className="text-[10px] text-slate-400 mt-0.5">Mục tiêu phát thải bằng Không (Net-Zero Carbon) năm 2030</p>
            </div>

            <div className="h-44 w-full text-slate-900 text-[10px] font-bold">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={historyData}>
                  <defs>
                    <linearGradient id="colorCO2" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.25}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="year" stroke="#64748b" tick={{ fill: '#94a3b8' }} />
                  <YAxis stroke="#64748b" tick={{ fill: '#94a3b8' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155' }} labelStyle={{ color: '#fff' }} />
                  <Area type="monotone" dataKey="CO2" name="Lượng phát thải (kg CO2e)" stroke="#10b981" fillOpacity={1} fill="url(#colorCO2)" strokeWidth={2.5} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="text-center text-[9px] text-emerald-400 bg-emerald-500/5 border border-emerald-500/10 p-2.5 rounded-xl mt-3 leading-relaxed">
            🌿 Năng lượng sạch (Solar) hiện cung cấp <strong>45%</strong> tổng nhu cầu điện bơm tự động của tổ liên kết sầu riêng.
          </div>
        </div>

      </div>

      {/* ESG Criteria detail checklists with Completion Status indicators */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl">
        <h3 className="text-xs font-black text-slate-100 uppercase tracking-wider border-b border-slate-800/60 pb-3 mb-4">
          Xếp hạng đánh giá tiêu chí Phát triển Bền vững (ESG Audit Index)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {esgScores.map((score, idx) => (
            <div key={idx} className="p-4 bg-slate-950/80 border border-slate-900 rounded-2xl space-y-3 flex flex-col justify-between">
              <div className="space-y-1">
                <span className="text-[10px] text-slate-500 uppercase font-black tracking-wider block">Tiêu chí {idx + 1}</span>
                <strong className="text-xs text-slate-200 font-bold block leading-snug">{score.name}</strong>
                <p className="text-[9px] text-slate-400 leading-snug mt-1">{score.desc}</p>
              </div>

              <div className="space-y-1 pt-2 border-t border-slate-900">
                <div className="flex justify-between text-[10px]">
                  <span className="text-slate-500 font-bold">Mức đạt:</span>
                  <span className="font-mono font-black text-emerald-400">{score.score}%</span>
                </div>
                {/* Progress bar */}
                <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
                  <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${score.score}%` }} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
