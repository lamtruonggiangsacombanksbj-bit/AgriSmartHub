import React, { useState, useEffect, useMemo, useRef } from "react";
import { 
  APIProvider, 
  Map, 
  AdvancedMarker, 
  InfoWindow, 
  Pin, 
  useMap, 
  useAdvancedMarkerRef 
} from "@vis.gl/react-google-maps";
import { 
  Map as MapIcon, 
  Layers, 
  Compass, 
  Wifi, 
  Thermometer, 
  Droplet, 
  Sprout, 
  User, 
  TrendingUp, 
  Settings, 
  Maximize2, 
  Info, 
  Plus, 
  Activity, 
  CheckCircle, 
  Sparkles,
  Search,
  AlertTriangle,
  Play
} from "lucide-react";

// Google Maps API Key Setup
const API_KEY =
  process.env.GOOGLE_MAPS_PLATFORM_KEY ||
  (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
  (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY ||
  "";

const hasValidKey =
  Boolean(API_KEY) &&
  API_KEY !== "YOUR_API_KEY" &&
  API_KEY.startsWith("AIzaSy");

if (typeof window !== "undefined") {
  (window as any).gm_authFailure = () => {
    console.warn("Google Maps authentication failed! Dispatching recovery event.");
    window.dispatchEvent(new CustomEvent("google-maps-auth-failure"));
  };
}

export interface RegionData {
  id: string;
  name: string;
  locationName: string;
  crop: string;
  areaHa: number;
  center: google.maps.LatLngLiteral;
  polygonPaths: google.maps.LatLngLiteral[];
  status: "active" | "warning" | "idle";
  soilHealth: {
    moisture: number; // %
    temp: number; // °C
    ph: number;
    npk: string; // N-P-K ratio
  };
  iotNodes: Array<{
    id: string;
    lat: number;
    lng: number;
    status: "online" | "offline";
    moisture: number;
    temp: number;
  }>;
}

export const REGIONS: RegionData[] = [
  {
    id: "vietnam-full",
    name: "Bản đồ Toàn cảnh Việt Nam",
    locationName: "Toàn quốc (Bản đồ số S-Shape)",
    crop: "Tổng quan các vùng HTX trọng điểm",
    areaHa: 1250,
    center: { lat: 15.9000, lng: 108.2000 },
    polygonPaths: [],
    status: "active",
    soilHealth: {
      moisture: 66,
      temp: 28.5,
      ph: 6.1,
      npk: "Hỗn hợp"
    },
    iotNodes: []
  },
  {
    id: "daklak-coffee",
    name: "HTX Cà phê & Hồ tiêu Đắk Lắk",
    locationName: "Cư M'gar, Đắk Lắk",
    crop: "Cà phê Robusta & Hồ tiêu Đắk Nông",
    areaHa: 450,
    center: { lat: 12.7865, lng: 108.0543 },
    polygonPaths: [
      { lat: 12.7950, lng: 108.0450 },
      { lat: 12.7980, lng: 108.0620 },
      { lat: 12.7780, lng: 108.0680 },
      { lat: 12.7750, lng: 108.0480 }
    ],
    status: "active",
    soilHealth: {
      moisture: 68,
      temp: 26.4,
      ph: 6.2,
      npk: "15-15-15"
    },
    iotNodes: [
      { id: "NODE-DL-01", lat: 12.7900, lng: 108.0500, status: "online", moisture: 67, temp: 26.2 },
      { id: "NODE-DL-02", lat: 12.7820, lng: 108.0600, status: "online", moisture: 69, temp: 26.6 },
      { id: "NODE-DL-03", lat: 12.7850, lng: 108.0550, status: "online", moisture: 68, temp: 26.4 }
    ]
  },
  {
    id: "tiengiang-mango",
    name: "HTX Xoài Cát Hòa Lộc Cái Bè",
    locationName: "Cái Bè, Tiền Giang",
    crop: "Xoài Cát Hòa Lộc",
    areaHa: 380,
    center: { lat: 10.3344, lng: 106.0152 },
    polygonPaths: [
      { lat: 10.3400, lng: 106.0080 },
      { lat: 10.3430, lng: 106.0220 },
      { lat: 10.3280, lng: 106.0240 },
      { lat: 10.3250, lng: 106.0100 }
    ],
    status: "warning",
    soilHealth: {
      moisture: 82,
      temp: 29.8,
      ph: 5.6,
      npk: "12-12-17"
    },
    iotNodes: [
      { id: "NODE-TG-01", lat: 10.3370, lng: 106.0120, status: "online", moisture: 81, temp: 29.5 },
      { id: "NODE-TG-02", lat: 10.3310, lng: 106.0180, status: "online", moisture: 83, temp: 30.1 }
    ]
  },
  {
    id: "binhthuan-dragon",
    name: "HTX Thanh long hữu cơ Hàm Thuận",
    locationName: "Hàm Thuận Nam, Bình Thuận",
    crop: "Thanh long ruột đỏ",
    areaHa: 270,
    center: { lat: 10.9333, lng: 107.9833 },
    polygonPaths: [
      { lat: 10.9410, lng: 107.9750 },
      { lat: 10.9440, lng: 107.9950 },
      { lat: 10.9250, lng: 108.0000 },
      { lat: 10.9210, lng: 107.9780 }
    ],
    status: "active",
    soilHealth: {
      moisture: 42,
      temp: 31.2,
      ph: 6.5,
      npk: "20-20-15"
    },
    iotNodes: [
      { id: "NODE-BT-01", lat: 10.9360, lng: 107.9800, status: "online", moisture: 41, temp: 31.0 },
      { id: "NODE-BT-02", lat: 10.9290, lng: 107.9900, status: "online", moisture: 43, temp: 31.4 }
    ]
  },
  {
    id: "bentre-pomelo",
    name: "HTX Bưởi Da Xanh Châu Thành",
    locationName: "Châu Thành, Bến Tre",
    crop: "Bưởi Da Xanh xuất khẩu",
    areaHa: 150,
    center: { lat: 10.2415, lng: 106.3751 },
    polygonPaths: [
      { lat: 10.2480, lng: 106.3680 },
      { lat: 10.2510, lng: 106.3820 },
      { lat: 10.2350, lng: 106.3850 },
      { lat: 10.2320, lng: 106.3700 }
    ],
    status: "idle",
    soilHealth: {
      moisture: 74,
      temp: 28.5,
      ph: 6.0,
      npk: "15-30-15"
    },
    iotNodes: [
      { id: "NODE-BT-01", lat: 10.2440, lng: 106.3720, status: "online", moisture: 73, temp: 28.2 },
      { id: "NODE-BT-02", lat: 10.2380, lng: 106.3780, status: "online", moisture: 75, temp: 28.8 }
    ]
  }
];

// Helper to draw google.maps.Polygon on map
function MapPolygon({ paths, options }: { paths: google.maps.LatLngLiteral[], options?: google.maps.PolygonOptions }) {
  const map = useMap();
  useEffect(() => {
    if (!map) return;
    const polygon = new google.maps.Polygon({
      paths,
      ...options,
      map
    });
    return () => {
      polygon.setMap(null);
    };
  }, [map, paths, options]);
  return null;
}

// Controller to handle center / zoom changes smoothly
function MapController({ center, zoom }: { center: google.maps.LatLngLiteral; zoom: number }) {
  const map = useMap();
  useEffect(() => {
    if (!map || !center) return;
    map.panTo(center);
    map.setZoom(zoom);
  }, [map, center, zoom]);
  return null;
}

export interface FarmingMapScreenProps {
  regions?: RegionData[];
  onUpdateRegion?: (updatedRegion: RegionData) => void;
}

export default function FarmingMapScreen({ regions: propRegions, onUpdateRegion }: FarmingMapScreenProps = {}) {
  const [localRegions, setLocalRegions] = useState<RegionData[]>(() => {
    const cached = localStorage.getItem("farming_regions");
    if (cached) {
      try { return JSON.parse(cached); } catch (e) { return REGIONS; }
    }
    return REGIONS;
  });

  const regions = propRegions || localRegions;

  const [selectedRegionId, setSelectedRegionId] = useState<string>(regions[0]?.id || "vietnam-full");
  const selectedRegion = useMemo(() => {
    return regions.find((r) => r.id === selectedRegionId) || regions[0];
  }, [regions, selectedRegionId]);

  const [mapZoom, setMapZoom] = useState(selectedRegionId === "vietnam-full" ? 6 : 14);
  const [mapType, setMapType] = useState<"roadmap" | "satellite" | "hybrid" | "terrain">("satellite");
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [useSimulatedMap, setUseSimulatedMap] = useState(true);
  const [googleMapsAuthFailed, setGoogleMapsAuthFailed] = useState(false);
  const [customNodes, setCustomNodes] = useState<Array<{ id: string; lat: number; lng: number; temp: number; moisture: number }>>(() => {
    try {
      const cached = localStorage.getItem("farming_custom_nodes");
      return cached ? JSON.parse(cached) : [];
    } catch (e) {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("farming_custom_nodes", JSON.stringify(customNodes));
    } catch (e) {
      console.error("Failed to save custom nodes:", e);
    }
  }, [customNodes]);
  const [showConfig, setShowConfig] = useState(false);
  const [editingRegion, setEditingRegion] = useState<RegionData | null>(null);

  // Quick edit form inputs
  const [editCrop, setEditCrop] = useState("");
  const [editArea, setEditArea] = useState(0);
  const [editStatus, setEditStatus] = useState<"active" | "warning" | "idle">("active");

  useEffect(() => {
    if (editingRegion) {
      setEditCrop(editingRegion.crop);
      setEditArea(editingRegion.areaHa);
      setEditStatus(editingRegion.status);
    }
  }, [editingRegion]);

  const [liveLogs, setLiveLogs] = useState<string[]>([
    "📍 Đã tải dữ liệu không gian các vùng hợp tác xã trọng điểm.",
    "📡 Hệ thống GPS & GIS vùng trồng đã đồng bộ.",
    "🗺️ Đang đồng nhất tọa độ số hóa thực địa."
  ]);

  const addLog = (msg: string) => {
    const time = new Date().toLocaleTimeString("vi-VN", { hour12: false });
    setLiveLogs((prev) => [...prev, `[${time}] ${msg}`].slice(-6));
  };

  useEffect(() => {
    const handleAuthFailure = () => {
      addLog("⚠️ Phát hiện lỗi khóa API Google Maps. Hệ thống tự động kích hoạt Bản đồ số AgriSmart AI.");
      setGoogleMapsAuthFailed(true);
      setUseSimulatedMap(true);
    };
    window.addEventListener("google-maps-auth-failure", handleAuthFailure);
    return () => {
      window.removeEventListener("google-maps-auth-failure", handleAuthFailure);
    };
  }, []);

  const filteredRegions = useMemo(() => {
    if (!searchQuery.trim()) return regions;
    return regions.filter((r) => 
      r.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      r.crop.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.locationName.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [regions, searchQuery]);

  const handleRegionClick = (region: RegionData) => {
    setSelectedRegionId(region.id);
    setMapZoom(region.id === "vietnam-full" ? 6 : 14);
    setSelectedNodeId(null);
    addLog(`🧭 Bay đến ${region.name} (${region.locationName})`);
  };

  const handleUpdateRegionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRegion) return;

    const updated: RegionData = {
      ...editingRegion,
      crop: editCrop,
      areaHa: editArea,
      status: editStatus,
    };

    if (onUpdateRegion) {
      onUpdateRegion(updated);
    } else {
      const nextRegions = regions.map((r) => r.id === updated.id ? updated : r);
      setLocalRegions(nextRegions);
      localStorage.setItem("farming_regions", JSON.stringify(nextRegions));
    }

    addLog(`✅ Cập nhật vùng ${updated.name}: Cây ${updated.crop}, DT ${updated.areaHa}ha, TT: ${updated.status}`);
    setEditingRegion(null);
  };

  const handleAddCustomNode = () => {
    const randomOffsetLat = (Math.random() - 0.5) * 0.006;
    const randomOffsetLng = (Math.random() - 0.5) * 0.006;
    const newLat = selectedRegion.center.lat + randomOffsetLat;
    const newLng = selectedRegion.center.lng + randomOffsetLng;
    const id = `NODE-CUST-${Date.now().toString().slice(-4)}`;

    const newNode = {
      id,
      lat: newLat,
      lng: newLng,
      temp: Number((25 + Math.random() * 8).toFixed(1)),
      moisture: Math.floor(40 + Math.random() * 50)
    };

    setCustomNodes((prev) => [...prev, newNode]);
    addLog(`⚡ Cắm mốc IoT ảo thành công: ${id} tại tọa độ (${newLat.toFixed(5)}, ${newLng.toFixed(5)})`);
  };

  const activePolygonPaths = useMemo(() => selectedRegion.polygonPaths, [selectedRegion]);

  return (
    <div id="real-maps-root" className="space-y-6">
      
      {/* 1. Header with live stats and simulation controller */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-sky-400 text-[10px] font-black uppercase tracking-widest block">GIS & Bản đồ nông học</span>
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[9px] font-bold tracking-wider">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              SATELLITE & POLYGON LIVE
            </span>
          </div>
          <h2 className="text-slate-100 font-black text-2xl tracking-tight">Số hóa Không gian Vùng trồng Thực tế</h2>
          <p className="text-slate-400 text-xs mt-0.5">Đối chiếu ranh giới nông trại, đo đạc IoT thực địa và đồng bộ vệ tinh với hệ thống máy học</p>
        </div>

        {/* Action controllers */}
        <div className="flex gap-2.5 self-end md:self-auto">
          <button
            onClick={handleAddCustomNode}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-slate-100 rounded-xl text-xs font-black transition-all cursor-pointer shadow-lg shadow-indigo-950/40 active:scale-95 flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            Cắm cảm biến IoT ảo
          </button>

          <button
            onClick={() => setShowConfig(!showConfig)}
            className="p-2 bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200 rounded-xl transition-all cursor-pointer"
            title="Tùy chỉnh lớp phủ"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 2. Interactive Map Splitsheet Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* Left column (col-span-4): Regions and Telemetry stats */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          
          {/* Quick List of cooperatives */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-md">
            
            {/* Search inputs */}
            <div className="relative">
              <input
                type="text"
                placeholder="Tìm hợp tác xã, cây trồng..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-850 rounded-xl pl-9 pr-4 py-2.5 text-xs text-slate-205 focus:outline-none focus:border-indigo-500 placeholder:text-slate-600 font-semibold"
              />
              <Search className="w-4 h-4 text-slate-600 absolute left-3 top-3.5" />
            </div>

            <div className="space-y-2.5 max-h-[220px] overflow-y-auto pr-1">
              {filteredRegions.map((region) => {
                const isSelected = selectedRegion.id === region.id;
                return (
                  <button
                    key={region.id}
                    onClick={() => handleRegionClick(region)}
                    className={`w-full text-left p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                      isSelected 
                        ? "bg-slate-950 border-indigo-500/40 text-indigo-400" 
                        : "bg-slate-950/50 border-slate-850 hover:border-slate-800 text-slate-400"
                    }`}
                  >
                    <div className="min-w-0">
                      <span className={`text-[9px] font-black uppercase tracking-wider block ${isSelected ? "text-indigo-400" : "text-slate-500"}`}>
                        {region.crop}
                      </span>
                      <h4 className="font-extrabold text-xs text-slate-200 truncate mt-0.5">{region.name}</h4>
                      <span className="text-[10px] text-slate-500 font-mono mt-0.5 block truncate">
                        {region.locationName} • {region.areaHa} ha
                      </span>
                    </div>

                    <span className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                      region.status === "active" 
                        ? "bg-emerald-500" 
                        : region.status === "warning" 
                        ? "bg-amber-500 animate-pulse" 
                        : "bg-slate-600"
                    }`} />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Regional sensors statistics card */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-md flex-1">
            <h3 className="text-slate-100 font-extrabold text-xs uppercase tracking-wider border-b border-slate-800 pb-3 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-sky-400 animate-pulse" />
                Trạng thái Môi trường Vùng trồng
              </span>
              <span className="text-[9px] font-mono text-slate-500 uppercase">IoT Node: {selectedRegion.iotNodes.length + customNodes.length}</span>
            </h3>

            {/* Weather & Soil details */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-slate-950 border border-slate-850/60 p-3.5 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Độ ẩm đất</span>
                  <Droplet className="w-3.5 h-3.5 text-sky-400" />
                </div>
                <strong className="text-lg font-black text-slate-100 font-mono">{selectedRegion.soilHealth.moisture}%</strong>
                <span className="text-[9px] text-slate-500 block">Độ ẩm tối ưu cho rễ</span>
              </div>

              <div className="bg-slate-950 border border-slate-850/60 p-3.5 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Nhiệt độ đất</span>
                  <Thermometer className="w-3.5 h-3.5 text-amber-500" />
                </div>
                <strong className="text-lg font-black text-slate-100 font-mono">{selectedRegion.soilHealth.temp}°C</strong>
                <span className="text-[9px] text-slate-500 block">Nhiệt ẩm ca ngày</span>
              </div>

              <div className="bg-slate-950 border border-slate-850/60 p-3.5 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Độ pH đất</span>
                  <Sprout className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <strong className="text-lg font-black text-slate-100 font-mono">{selectedRegion.soilHealth.ph}</strong>
                <span className="text-[9px] text-slate-500 block">Độ chua dinh dưỡng</span>
              </div>

              <div className="bg-slate-950 border border-slate-850/60 p-3.5 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Tỷ lệ NPK</span>
                  <TrendingUp className="w-3.5 h-3.5 text-indigo-400" />
                </div>
                <strong className="text-lg font-black text-slate-100 font-mono text-ellipsis overflow-hidden block">{selectedRegion.soilHealth.npk}</strong>
                <span className="text-[9px] text-slate-500 block">Tiêu chuẩn hữu cơ</span>
              </div>
            </div>

            {selectedRegion.id !== "vietnam-full" && (
              <button
                onClick={() => setEditingRegion(selectedRegion)}
                className="w-full py-2.5 bg-slate-950 border border-indigo-500/30 hover:bg-indigo-500/10 text-indigo-400 text-xs font-black rounded-xl transition-all uppercase cursor-pointer flex items-center justify-center gap-2"
              >
                <Settings className="w-3.5 h-3.5 text-indigo-400" />
                Hiệu chỉnh nhanh vùng này
              </button>
            )}

            {/* Quick logs footer */}
            <div className="bg-slate-950/80 border border-slate-850/80 p-3 rounded-xl space-y-1.5 font-mono text-[9px] text-slate-500 select-none">
              <span className="text-slate-400 font-bold block uppercase tracking-wider border-b border-slate-850 pb-1 mb-1.5">Sự kiện GIS gần đây:</span>
              {liveLogs.map((log, i) => (
                <div key={i} className="truncate">
                  {log}
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right column (col-span-8): Map engine */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-3xl p-4 flex flex-col h-[560px] relative shadow-md overflow-hidden">
          
          {/* Top floating bar inside map container for view modes */}
          <div className="absolute top-6 left-6 right-6 z-10 flex flex-wrap justify-between items-center gap-3 pointer-events-none select-none">
            
            {/* Left float: Selected Cooperate Label */}
            <div className="bg-slate-950/90 backdrop-blur border border-slate-800 px-3.5 py-2 rounded-2xl shadow-xl flex items-center gap-2 pointer-events-auto">
              <div className="p-1.5 bg-indigo-500/15 text-indigo-400 rounded-lg">
                <MapIcon className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] font-extrabold text-sky-400 uppercase tracking-wider leading-none block">Đang xem thực địa</span>
                <span className="text-xs font-black text-slate-100 block mt-0.5 leading-none">{selectedRegion.name}</span>
              </div>
            </div>

            {/* Right float: Map Type/Simulation Selector and Tools */}
            <div className="flex flex-wrap gap-2 pointer-events-auto bg-slate-950/95 backdrop-blur border border-slate-800 p-1.5 rounded-2xl shadow-xl">
              {/* Simulation vs Google Maps Toggle */}
              <div className="flex bg-slate-900 border border-slate-850 p-0.5 rounded-xl gap-0.5">
                <button
                  onClick={() => {
                    setUseSimulatedMap(true);
                    addLog("🔄 Kích hoạt Bản đồ số AgriSmart AI (Giao diện vector mượt mà).");
                  }}
                  className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 ${
                    useSimulatedMap 
                      ? "bg-indigo-600 text-slate-100 shadow" 
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <Sparkles className="w-3 h-3 text-indigo-300 animate-pulse" />
                  Bản đồ số AI
                </button>
                <button
                  onClick={() => {
                    setUseSimulatedMap(false);
                    addLog("🌐 Chuyển sang Bản đồ vệ tinh thực tế (Google Maps Platform).");
                  }}
                  className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 ${
                    !useSimulatedMap 
                      ? "bg-indigo-600 text-slate-100 shadow" 
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <Layers className="w-3 h-3 text-slate-300" />
                  Google Maps
                </button>
              </div>

              {/* Show original Google Maps style toggles ONLY if useSimulatedMap is false */}
              {!useSimulatedMap && (
                <div className="flex gap-1 bg-slate-900 border border-slate-850 p-0.5 rounded-xl">
                  {(["roadmap", "satellite", "hybrid", "terrain"] as const).map((t) => (
                    <button
                      key={t}
                      onClick={() => {
                        setMapType(t);
                        addLog(`🗺️ Đổi chế độ bản đồ thành: ${t.toUpperCase()}`);
                      }}
                      className={`px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                        mapType === t 
                          ? "bg-indigo-600 text-slate-100 shadow" 
                          : "text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      {t === "roadmap" ? "Thường" : t === "satellite" ? "Vệ tinh" : t === "hybrid" ? "Hỗn hợp" : "Địa hình"}
                    </button>
                  ))}
                </div>
              )}
            </div>

          </div>

          {/* Map Content Engine: Toggle between Custom Simulated Vector and Actual Google Map */}
          {useSimulatedMap ? (
            <div className="flex-1 rounded-2xl overflow-hidden border border-slate-800 relative bg-slate-950 flex flex-col items-center justify-center p-4 min-h-[380px] select-none" style={{ height: "100%" }}>
              {/* Grid Background */}
              <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-25" />
              
              {selectedRegion.id === "vietnam-full" ? (
                /* --- INTERACTIVE VIETNAM VECTOR MAP --- */
                <div className="relative w-full h-full flex items-center justify-center">
                  {/* Decorative Elements */}
                  <div className="absolute top-4 left-4 flex flex-col gap-1 text-[9px] font-mono text-slate-500">
                    <span>GRID COORDINATES: WGS 84</span>
                    <span>RESOLUTION: VỆ TINH KỸ THUẬT SỐ</span>
                    <span>HEADING: NORTH / THUẬN GIÓ</span>
                  </div>

                  {/* Compass Rose */}
                  <div className="absolute bottom-4 right-4 flex flex-col items-center justify-center bg-slate-900/60 p-2.5 rounded-xl border border-slate-850">
                    <Compass className="w-5 h-5 text-indigo-400 animate-[spin_20s_linear_infinite]" />
                    <span className="text-[8px] font-mono text-slate-400 mt-1 uppercase font-black">La bàn AI</span>
                  </div>

                  {/* Ocean wave ripples */}
                  <div className="absolute bottom-1/4 left-1/4 opacity-30 animate-pulse">
                    <svg className="w-12 h-4 text-sky-500" viewBox="0 0 100 20">
                      <path d="M0,10 Q25,0 50,10 T100,10" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray="4,4" />
                    </svg>
                  </div>

                  {/* Vietnam Map S-Shape */}
                  <div className="w-full max-w-[450px] h-[340px] relative flex items-center justify-center">
                    <svg viewBox="0 0 500 500" className="w-full h-full drop-shadow-[0_0_15px_rgba(99,102,241,0.15)]">
                      {/* Grid background for mapping feel */}
                      <path d="M 50,0 L 50,500 M 150,0 L 150,500 M 250,0 L 250,500 M 350,0 L 350,500 M 450,0 L 450,500 M 0,50 L 500,50 M 0,150 L 500,150 M 0,250 L 500,250 M 0,350 L 500,350 M 0,450 L 500,450" fill="none" stroke="#1e293b" strokeWidth="0.5" />
                      
                      {/* Stylized Vietnam S-Shape Path */}
                      <path 
                        d="M 170,40 Q 230,20 280,50 T 260,110 T 210,140 T 240,190 Q 280,220 290,270 T 320,350 Q 300,410 270,440 T 230,460" 
                        fill="none" 
                        stroke="#1e293b" 
                        strokeWidth="32" 
                        strokeLinecap="round" 
                        className="opacity-20"
                      />

                      {/* Glowing Main Map Line */}
                      <path 
                        d="M 170,40 Q 230,20 280,50 T 260,110 T 210,140 T 240,190 Q 280,220 290,270 T 320,350 Q 300,410 270,440 T 230,460" 
                        fill="none" 
                        stroke="url(#vietnam-glow)" 
                        strokeWidth="6" 
                        strokeLinecap="round" 
                        strokeLinejoin="round"
                        className="animate-pulse"
                      />

                      {/* Map Gradients */}
                      <defs>
                        <linearGradient id="vietnam-glow" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stopColor="#38bdf8" />
                          <stop offset="50%" stopColor="#6366f1" />
                          <stop offset="100%" stopColor="#10b981" />
                        </linearGradient>
                      </defs>

                      {/* Paracel Islands (Hoàng Sa) */}
                      <g className="cursor-pointer" transform="translate(370, 200)">
                        <circle cx="0" cy="0" r="3" fill="#6366f1" />
                        <circle cx="10" cy="-5" r="2.5" fill="#6366f1" />
                        <circle cx="-5" cy="-8" r="2" fill="#6366f1" />
                        <text x="18" y="-2" fill="#64748b" className="text-[10px] font-black tracking-widest uppercase font-sans pointer-events-none">Hoàng Sa</text>
                      </g>

                      {/* Spratly Islands (Trường Sa) */}
                      <g className="cursor-pointer" transform="translate(390, 390)">
                        <circle cx="0" cy="0" r="3.5" fill="#10b981" />
                        <circle cx="12" cy="15" r="3.5" fill="#10b981" />
                        <circle cx="-15" cy="8" r="2.5" fill="#10b981" />
                        <circle cx="20" cy="-10" r="2" fill="#10b981" />
                        <text x="30" y="5" fill="#64748b" className="text-[10px] font-black tracking-widest uppercase font-sans pointer-events-none">Trường Sa</text>
                      </g>
                    </svg>

                    {/* Regional Pins absolute overlaying */}
                    {regions.filter(r => r.id !== "vietnam-full").map((region) => {
                      let top = "10%";
                      let left = "10%";

                      if (region.id === "daklak-coffee") {
                        top = "44%";
                        left = "54%";
                      } else if (region.id === "tiengiang-mango") {
                        top = "78%";
                        left = "34%";
                      } else if (region.id === "binhthuan-dragon") {
                        top = "64%";
                        left = "51%";
                      } else if (region.id === "bentre-pomelo") {
                        top = "83%";
                        left = "40%";
                      }

                      const isWarning = region.status === "warning";

                      return (
                        <div
                          key={`sim-marker-${region.id}`}
                          className="absolute transform -translate-x-1/2 -translate-y-1/2 z-20 group"
                          style={{ top, left }}
                        >
                          <div className={`absolute -inset-3 rounded-full filter blur-xs opacity-50 animate-ping pointer-events-none ${
                            isWarning ? "bg-amber-500" : "bg-emerald-500"
                          }`} style={{ animationDuration: "3s" }} />

                          <button
                            onClick={() => handleRegionClick(region)}
                            className={`w-5 h-5 rounded-full border-2 border-slate-950 flex items-center justify-center shadow-lg transition-all transform hover:scale-125 cursor-pointer relative ${
                              isWarning 
                                ? "bg-amber-500 text-slate-950 hover:bg-amber-400" 
                                : "bg-emerald-500 text-slate-950 hover:bg-emerald-400"
                            }`}
                          >
                            <MapIcon className="w-2.5 h-2.5" />
                          </button>

                          {/* Hover Tooltip Card */}
                          <div className="absolute top-7 left-1/2 transform -translate-x-1/2 w-48 bg-slate-950/95 border border-slate-850 p-2.5 rounded-xl shadow-2xl opacity-0 scale-95 group-hover:opacity-100 group-hover:scale-100 transition-all pointer-events-none z-30 flex flex-col items-center text-center">
                            <div className="flex items-center gap-1.5 justify-center">
                              <span className={`w-1.5 h-1.5 rounded-full ${isWarning ? 'bg-amber-400 animate-pulse' : 'bg-emerald-400 animate-pulse'}`} />
                              <span className="text-[8.5px] font-black text-slate-200 uppercase tracking-wider">{region.crop}</span>
                            </div>
                            <h4 className="text-[10px] font-extrabold text-sky-400 mt-1 leading-tight">{region.name}</h4>
                            <span className="text-[7.5px] font-bold text-slate-500 mt-0.5">{region.locationName}</span>
                            <div className="border-t border-slate-900 w-full my-1.5" />
                            <div className="flex gap-3 justify-center text-[8.5px] font-mono font-bold text-slate-400">
                              <span>DT: {region.areaHa} ha</span>
                              <span>pH: {region.soilHealth.ph}</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                /* --- INTERACTIVE REGIONAL FARMLAND PLOTS GRID --- */
                <div className="w-full h-full flex flex-col justify-between p-2 relative">
                  {/* Top Header: Weather / Operations Indicators */}
                  <div className="flex items-center justify-between border-b border-slate-900 pb-2 mb-2 select-none">
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 px-2 py-1 rounded-lg text-[9px] font-bold text-slate-300">
                        <Activity className="w-3 h-3 text-sky-400 animate-pulse" />
                        <span>Sóng LoRa: Cực tốt</span>
                      </div>
                      <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 px-2 py-1 rounded-lg text-[9px] font-bold text-slate-300">
                        <Compass className="w-3 h-3 text-amber-500" />
                        <span>Patrol Drone Active</span>
                      </div>
                    </div>

                    <div className="text-[8.5px] font-mono text-slate-500">
                      TỌA ĐỘ TRẠM: {selectedRegion.center.lat.toFixed(4)}N, {selectedRegion.center.lng.toFixed(4)}E
                    </div>
                  </div>

                  {/* Farmland Grid Container */}
                  <div className="flex-1 grid grid-cols-2 sm:grid-cols-3 gap-3 overflow-y-auto max-h-[300px] p-1.5 relative custom-scrollbar">
                    
                    {/* Floating Patrol Drone */}
                    <div className="absolute top-1/4 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none animate-[bounce_4s_ease-in-out_infinite]">
                      <div className="relative flex flex-col items-center">
                        <div className="flex items-center justify-center p-2 bg-slate-950 border border-indigo-500/50 rounded-full shadow-lg text-indigo-400 animate-pulse">
                          <Compass className="w-4 h-4 animate-[spin_5s_linear_infinite]" />
                        </div>
                        {/* Downward scanning light */}
                        <div className="w-8 h-12 bg-indigo-500/10 [clip-path:polygon(30%_0%,70%_0%,100%_100%,0%_100%)] border-b-2 border-indigo-500/30 filter blur-xs -mt-1" />
                        <span className="text-[7.5px] font-mono font-black text-indigo-400 bg-slate-950/80 px-1 py-0.5 rounded border border-indigo-900/60 mt-0.5">AGRI-DRONE GPS</span>
                      </div>
                    </div>

                    {/* Generate Beautiful Custom Farm Plots for this Region */}
                    {[1, 2, 3, 4, 5, 6].map((plotNum) => {
                      const isWarningPlot = selectedRegion.status === "warning" && (plotNum === 2 || plotNum === 4);
                      const isSelected = selectedNodeId === `NODE-${selectedRegion.id.toUpperCase().slice(0, 2)}-0${plotNum}`;
                      const moisture = isWarningPlot 
                        ? Math.floor(selectedRegion.soilHealth.moisture * 0.7) 
                        : Math.floor(selectedRegion.soilHealth.moisture + (plotNum % 2 === 0 ? 3 : -2));
                      
                      const temp = isWarningPlot
                        ? Number((selectedRegion.soilHealth.temp + 2).toFixed(1))
                        : Number((selectedRegion.soilHealth.temp + (plotNum % 2 === 0 ? -0.5 : 0.4)).toFixed(1));

                      const ph = isWarningPlot
                        ? Number((selectedRegion.soilHealth.ph - 0.5).toFixed(1))
                        : Number((selectedRegion.soilHealth.ph + (plotNum % 2 === 0 ? 0.1 : -0.1)).toFixed(1));

                      return (
                        <div
                          key={`plot-${plotNum}`}
                          onClick={() => {
                            setSelectedNodeId(`NODE-${selectedRegion.id.toUpperCase().slice(0, 2)}-0${plotNum}`);
                            addLog(`🔍 Xem trạng thái Lô Đất #${plotNum} - Diện tích canh tác.`);
                          }}
                          className={`p-3 rounded-xl border transition-all cursor-pointer relative overflow-hidden group flex flex-col justify-between ${
                            isSelected
                              ? "bg-slate-900 border-indigo-500 shadow-lg shadow-indigo-950/20"
                              : isWarningPlot
                              ? "bg-amber-950/10 border-amber-500/30 hover:bg-amber-950/20 hover:border-amber-500/50 text-amber-100"
                              : "bg-slate-950/40 border-slate-850 hover:bg-slate-900/30 hover:border-slate-800 text-slate-300"
                          }`}
                        >
                          {/* Inner Scanline decorative effect on hover */}
                          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-indigo-500/5 bg-[size:100%_4px] opacity-0 group-hover:opacity-100 pointer-events-none" />

                          {/* Plot Title */}
                          <div className="flex items-center justify-between gap-1.5 border-b border-slate-900/40 pb-1.5 mb-1.5">
                            <span className="text-[10px] font-black uppercase tracking-wider text-slate-100 truncate">
                              Lô #{plotNum} - {selectedRegion.crop.split(" ")[0]}
                            </span>
                            <span className={`w-1.5 h-1.5 rounded-full ${
                              isWarningPlot ? "bg-amber-500 animate-pulse" : "bg-emerald-500 animate-pulse"
                            }`} />
                          </div>

                          {/* Plot Stats */}
                          <div className="space-y-1.5 text-[10px] font-medium text-slate-400 select-none">
                            <div className="flex items-center justify-between">
                              <span className="flex items-center gap-1">
                                <Droplet className="w-3 h-3 text-sky-400" />
                                Ẩm đất
                              </span>
                              <strong className={`font-mono ${isWarningPlot ? "text-amber-400" : "text-slate-100"}`}>{moisture}%</strong>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="flex items-center gap-1">
                                <Thermometer className="w-3 h-3 text-amber-500" />
                                Nhiệt
                              </span>
                              <strong className="font-mono text-slate-100">{temp}°C</strong>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="flex items-center gap-1">
                                <Sprout className="w-3 h-3 text-emerald-400" />
                                Độ pH
                              </span>
                              <strong className="font-mono text-slate-100">{ph}</strong>
                            </div>
                          </div>

                          {/* Bottom IoT Node Tag */}
                          <div className="flex items-center justify-between border-t border-slate-900/40 pt-1.5 mt-1.5 text-[8px] font-mono text-slate-500">
                            <span>IoT-N{plotNum}</span>
                            <span className="flex items-center gap-0.5 text-emerald-400 font-extrabold text-[7.5px]">
                              <Wifi className="w-2.5 h-2.5 animate-pulse" /> 98%
                            </span>
                          </div>
                        </div>
                      );
                    })}

                    {/* Render Custom Spawned Nodes */}
                    {customNodes.map((node) => (
                      <div
                        key={node.id}
                        onClick={() => {
                          setSelectedNodeId(node.id);
                        }}
                        className={`p-3 rounded-xl border transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between ${
                          selectedNodeId === node.id
                            ? "bg-slate-900 border-indigo-500 shadow-lg shadow-indigo-950/20"
                            : "bg-indigo-950/10 border-indigo-500/20 text-indigo-300"
                        }`}
                      >
                        <div className="flex items-center justify-between gap-1.5 border-b border-indigo-950/40 pb-1.5 mb-1.5">
                          <span className="text-[10px] font-black uppercase tracking-wider text-indigo-400 truncate flex items-center gap-1">
                            <Sparkles className="w-3 h-3 animate-spin" /> {node.id}
                          </span>
                          <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse" />
                        </div>
                        <div className="space-y-1.5 text-[10px] font-medium text-slate-400 select-none">
                          <div className="flex items-center justify-between">
                            <span>Ẩm đất</span>
                            <strong className="font-mono text-indigo-400">{node.moisture}%</strong>
                          </div>
                          <div className="flex items-center justify-between">
                            <span>Nhiệt</span>
                            <strong className="font-mono text-slate-100">{node.temp}°C</strong>
                          </div>
                        </div>
                        <div className="flex items-center justify-between border-t border-indigo-950/40 pt-1.5 mt-1.5 text-[8px] font-mono text-indigo-500">
                          <span>IoT-VIRTUAL</span>
                          <span className="flex items-center gap-0.5 text-indigo-400 font-extrabold text-[7.5px]">
                            <Wifi className="w-2.5 h-2.5 animate-pulse" /> SIM
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Dynamic Popover Overlay for Selected Plot / Node */}
                  {selectedNodeId && (() => {
                    const nodeNum = selectedNodeId.split("-").pop()?.replace(/^0+/, "");
                    const isCustom = selectedNodeId.startsWith("NODE-CUST-");
                    
                    const moisture = isCustom
                      ? customNodes.find(n => n.id === selectedNodeId)?.moisture || 60
                      : selectedRegion.status === "warning" && (nodeNum === "2" || nodeNum === "4")
                      ? Math.floor(selectedRegion.soilHealth.moisture * 0.7)
                      : Math.floor(selectedRegion.soilHealth.moisture + (Number(nodeNum) % 2 === 0 ? 3 : -2));

                    const temp = isCustom
                      ? customNodes.find(n => n.id === selectedNodeId)?.temp || 27
                      : selectedRegion.status === "warning" && (nodeNum === "2" || nodeNum === "4")
                      ? Number((selectedRegion.soilHealth.temp + 2).toFixed(1))
                      : Number((selectedRegion.soilHealth.temp + (Number(nodeNum) % 2 === 0 ? -0.5 : 0.4)).toFixed(1));

                    const ph = selectedRegion.status === "warning" && (nodeNum === "2" || nodeNum === "4")
                      ? Number((selectedRegion.soilHealth.ph - 0.5).toFixed(1))
                      : Number((selectedRegion.soilHealth.ph + (Number(nodeNum) % 2 === 0 ? 0.1 : -0.1)).toFixed(1));

                    const npk = isCustom ? "NPK 16-16-8" : selectedRegion.soilHealth.npk;

                    return (
                      <div className="absolute bottom-2 left-2 right-2 bg-slate-950 border-2 border-indigo-500/40 p-3.5 rounded-2xl shadow-2xl z-30 flex flex-col sm:flex-row gap-3 sm:items-center justify-between animate-fadeIn select-none">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                            <strong className="text-slate-100 text-xs font-black uppercase">
                              Chi tiết trạm cảm biến {selectedNodeId}
                            </strong>
                            <span className="text-[8px] font-mono font-black px-1.5 py-0.5 bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 rounded">
                              {isCustom ? "Mốc Thử Nghiệm" : `Lô đất #${nodeNum}`}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-400 font-semibold leading-relaxed">
                            Vị trí: {selectedRegion.locationName} • Kết nối vô tuyến LoRaWan an toàn 256-bit.
                          </p>
                        </div>

                        {/* Telemetry quick indicators */}
                        <div className="flex flex-wrap gap-4 text-xs font-semibold">
                          <div className="flex items-center gap-1.5">
                            <Droplet className="w-3.5 h-3.5 text-sky-400" />
                            <span className="text-slate-400">Độ ẩm:</span>
                            <strong className="text-sky-400 font-mono font-black">{moisture}%</strong>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Thermometer className="w-3.5 h-3.5 text-amber-500" />
                            <span className="text-slate-400">Nhiệt độ:</span>
                            <strong className="text-amber-500 font-mono font-black">{temp}°C</strong>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <Sprout className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-slate-400">Độ pH:</span>
                            <strong className="text-emerald-400 font-mono font-black">{ph}</strong>
                          </div>
                          <div className="flex items-center gap-1.5">
                            <TrendingUp className="w-3.5 h-3.5 text-indigo-400" />
                            <span className="text-slate-400">NPK:</span>
                            <strong className="text-indigo-400 font-mono font-black">{npk}</strong>
                          </div>
                        </div>

                        {/* Close button */}
                        <button
                          onClick={() => setSelectedNodeId(null)}
                          className="px-2.5 py-1 text-[9px] font-bold uppercase text-slate-400 hover:text-slate-100 hover:bg-slate-900 rounded-lg border border-slate-900 shrink-0 cursor-pointer transition-all"
                        >
                          Đóng
                        </button>
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>
          ) : (
            /* --- ORIGINAL GOOGLE MAP COMPONENT --- */
            <div className="flex-1 rounded-2xl overflow-hidden border border-slate-800 relative bg-slate-950 flex flex-col items-center justify-center p-6 text-center" style={{ height: "100%" }}>
              {hasValidKey && !googleMapsAuthFailed ? (
                <APIProvider apiKey={API_KEY} version="weekly">
                  <Map
                    defaultCenter={selectedRegion.center}
                    defaultZoom={mapZoom}
                    mapId="DEMO_MAP_ID"
                    mapTypeId={mapType}
                    internalUsageAttributionIds={["gmp_mcp_codeassist_v1_aistudio"]}
                    style={{ width: "100%", height: "100%" }}
                    disableDefaultUI={false}
                    gestureHandling="cooperative"
                  >
                    {/* Dynamically pan and zoom based on state */}
                    <MapController center={selectedRegion.center} zoom={mapZoom} />

                    {/* Draw planting region polygon on map */}
                    {activePolygonPaths && activePolygonPaths.length > 0 && (
                      <MapPolygon 
                        paths={activePolygonPaths} 
                        options={{
                          fillColor: selectedRegion.status === "warning" ? "#f59e0b" : "#10b981",
                          fillOpacity: 0.22,
                          strokeColor: selectedRegion.status === "warning" ? "#d97706" : "#059669",
                          strokeWeight: 2,
                          clickable: true
                        }}
                      />
                    )}

                    {/* Draw region flags/markers on full Vietnam view */}
                    {selectedRegion.id === "vietnam-full" && 
                      regions.filter(r => r.id !== "vietnam-full").map((region) => (
                        <AdvancedMarker
                          key={`region-badge-${region.id}`}
                          position={region.center}
                          onClick={() => {
                            handleRegionClick(region);
                          }}
                        >
                          <div 
                            className="cursor-pointer transition-all duration-300 hover:scale-110 flex flex-col items-center bg-slate-950/95 border-2 border-indigo-500/60 p-2.5 rounded-2xl shadow-xl hover:border-indigo-400 select-none text-center"
                            style={{ minWidth: "150px" }}
                          >
                            <div className="flex items-center gap-1.5 justify-center">
                              <span className={`w-2 h-2 rounded-full ${region.status === 'active' ? 'bg-emerald-500 animate-pulse' : region.status === 'warning' ? 'bg-amber-500 animate-pulse' : 'bg-slate-500'}`} />
                              <span className="text-[10px] font-black text-slate-100 uppercase tracking-wider">{region.crop}</span>
                            </div>
                            <h4 className="text-[9.5px] font-extrabold text-sky-400 mt-1 leading-tight">{region.name}</h4>
                            <span className="text-[8px] font-bold text-slate-500 mt-0.5">{region.locationName}</span>

                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setEditingRegion(region);
                              }}
                              className="mt-2 w-full text-center py-1 bg-indigo-600 hover:bg-indigo-500 text-slate-100 font-extrabold rounded-lg text-[9px] uppercase tracking-wider transition-all cursor-pointer shadow shadow-indigo-950/40"
                            >
                              Chỉnh sửa nhanh
                            </button>
                          </div>
                        </AdvancedMarker>
                      ))
                    }

                    {/* Draw IoT online nodes as markers */}
                    {selectedRegion.iotNodes.map((node) => (
                      <AdvancedMarker
                        key={node.id}
                        position={{ lat: node.lat, lng: node.lng }}
                        onClick={() => {
                          setSelectedNodeId(node.id);
                          setMapZoom(16);
                          addLog(`🎯 Nhấp chọn cảm biến IoT Node: ${node.id}`);
                        }}
                      >
                        {/* Explicit CSS sizing prevents 0x0 collapse */}
                        <div 
                          className="cursor-pointer transition-all active:scale-90 hover:scale-110 flex items-center justify-center p-1.5 rounded-full bg-slate-950 border-2 border-emerald-500 shadow-lg shadow-emerald-950/50"
                          style={{ width: "36px", height: "36px" }}
                        >
                          <Wifi className="w-4 h-4 text-emerald-400 animate-pulse" />
                        </div>
                      </AdvancedMarker>
                    ))}

                    {/* Draw custom placed nodes */}
                    {customNodes.map((node) => (
                      <AdvancedMarker
                        key={node.id}
                        position={{ lat: node.lat, lng: node.lng }}
                        onClick={() => {
                          setSelectedNodeId(node.id);
                          setMapZoom(16);
                          addLog(`🎯 Nhấp chọn cảm biến IoT ảo tự tạo: ${node.id}`);
                        }}
                      >
                        <div 
                          className="cursor-pointer transition-all active:scale-90 hover:scale-110 flex items-center justify-center p-1.5 rounded-full bg-slate-950 border-2 border-indigo-500 shadow-lg shadow-indigo-950/50 animate-bounce"
                          style={{ width: "36px", height: "36px" }}
                        >
                          <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse" />
                        </div>
                      </AdvancedMarker>
                    ))}

                    {/* Info Window for selected node */}
                    {selectedNodeId && (() => {
                      const node = selectedRegion.iotNodes.find((n) => n.id === selectedNodeId) || 
                                   customNodes.find((n) => n.id === selectedNodeId);
                      
                      if (!node) return null;

                      return (
                        <InfoWindow
                          position={{ lat: node.lat, lng: node.lng }}
                          onCloseClick={() => setSelectedNodeId(null)}
                        >
                          <div className="p-2 text-slate-900 text-xs font-semibold space-y-1.5 min-w-[170px]">
                            <div className="flex items-center justify-between border-b pb-1">
                              <strong className="text-slate-950 font-black">{node.id}</strong>
                              <span className="text-[8px] font-black uppercase text-emerald-600 bg-emerald-50 px-1 py-0.5 rounded">Online</span>
                            </div>
                            <div className="space-y-1">
                              <p className="flex items-center justify-between">
                                <span>Độ ẩm đất:</span>
                                <strong className="text-indigo-600">{node.moisture}%</strong>
                              </p>
                              <p className="flex items-center justify-between">
                                <span>Nhiệt độ rễ:</span>
                                <strong className="text-amber-600">{node.temp}°C</strong>
                              </p>
                              <p className="text-[8.5px] text-slate-500 pt-1 border-t text-center font-mono">
                                Tọa độ: {node.lat.toFixed(4)}, {node.lng.toFixed(4)}
                              </p>
                            </div>
                          </div>
                        </InfoWindow>
                      );
                    })()}

                  </Map>
                </APIProvider>
              ) : (
                <div className="max-w-md mx-auto space-y-5 p-6 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl animate-fadeIn text-center pointer-events-auto">
                  <div className="mx-auto w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 animate-pulse">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-slate-100 uppercase tracking-wider">
                      {googleMapsAuthFailed ? "Khóa API Google Maps không hợp lệ" : "Cấu hình Google Maps Platform"}
                    </h3>
                    <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                      {googleMapsAuthFailed 
                        ? "Khóa API Google Maps hiện tại của dự án bị từ chối xác thực bởi Google (InvalidKeyMapError). Vui lòng cấu hình khóa hợp lệ." 
                        : "Để xem bản đồ vệ tinh thực tế toàn cầu, vui lòng thiết lập khóa bí mật GOOGLE_MAPS_PLATFORM_KEY trong cài đặt Secrets của dự án."}
                    </p>
                    <p className="text-[10px] text-slate-500 mt-2">
                      Bạn có thể tiếp tục sử dụng <span className="text-sky-400 font-bold">Bản đồ số AI</span> mà không cần bất kỳ cấu hình nào.
                    </p>
                  </div>
                  <div className="flex gap-2.5 pt-1">
                    <button
                      onClick={() => {
                        setUseSimulatedMap(true);
                        addLog("🔄 Quay về Bản đồ số AgriSmart AI.");
                      }}
                      className="flex-1 py-2 px-3 bg-indigo-600 hover:bg-indigo-500 text-slate-100 text-[10px] font-extrabold uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow shadow-indigo-950"
                    >
                      Dùng Bản đồ số AI
                    </button>
                    <a
                      href="https://console.cloud.google.com/google/maps-apis/start?utm_campaign=gmp-code-assist-ais"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 py-2 px-3 bg-slate-800 hover:bg-slate-750 text-slate-300 text-[10px] font-extrabold uppercase tracking-wider rounded-xl transition-all text-center"
                    >
                      Đăng ký khóa API
                    </a>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Floating bottom legends */}
          <div className="absolute bottom-6 left-6 bg-slate-950/95 border border-slate-800 p-3 rounded-xl shadow-xl z-10 flex gap-4 text-[9px] font-bold uppercase tracking-wider text-slate-400 select-none">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-emerald-500/30 border border-emerald-500 rounded" />
              <span>Cành/Rễ bình thường</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-amber-500/30 border border-amber-500 rounded" />
              <span>Rủi ro sinh học</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-slate-950 border-2 border-emerald-500 rounded-full" />
              <span>Trạm IoT Cảm Biến</span>
            </div>
          </div>

        </div>

      </div>

      {/* Quick Edit Popup Modal */}
      {editingRegion && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-[9999] p-4">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl w-full max-w-md shadow-2xl relative space-y-4 text-left">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-sky-400 text-[10px] font-black uppercase tracking-widest block">Hiệu chỉnh vùng trồng</span>
                <h3 className="text-slate-100 font-extrabold text-base mt-0.5">{editingRegion.name}</h3>
              </div>
              <button 
                type="button"
                onClick={() => setEditingRegion(null)}
                className="text-slate-400 hover:text-slate-200 text-sm font-bold p-1 bg-slate-950 rounded-lg border border-slate-850 cursor-pointer w-6 h-6 flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleUpdateRegionSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Cây trồng canh tác</label>
                <input
                  type="text"
                  required
                  value={editCrop}
                  onChange={(e) => setEditCrop(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-semibold"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Diện tích quy mô (ha)</label>
                <input
                  type="number"
                  required
                  min="1"
                  max="10000"
                  value={editArea}
                  onChange={(e) => setEditArea(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-semibold font-mono"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Trạng thái sinh học</label>
                <select
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-semibold"
                >
                  <option value="active">🟢 Hoạt động (Phát triển tốt)</option>
                  <option value="warning">🟡 Cảnh báo (Rủi ro rễ/dinh dưỡng)</option>
                  <option value="idle">⚫ Tạm ngưng canh tác</option>
                </select>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingRegion(null)}
                  className="flex-1 py-2.5 bg-slate-950 border border-slate-850 hover:bg-slate-850 text-slate-300 text-xs font-bold rounded-xl transition-all cursor-pointer text-center"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-slate-100 text-xs font-black rounded-xl transition-all shadow-lg shadow-indigo-950/40 cursor-pointer text-center"
                >
                  Cập nhật ngay
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
