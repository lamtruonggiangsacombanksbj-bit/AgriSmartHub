import React, { useState, useEffect, useRef } from "react";
import {
  ClipboardList,
  Plus,
  Trash2,
  CheckCircle,
  Clock,
  User,
  AlertCircle,
  Play,
  RotateCcw,
  Radio,
  Activity,
  Volume2,
  VolumeX,
  Sparkles,
  Loader2,
  Wifi,
  Cpu,
  Tv
} from "lucide-react";

interface FarmingTask {
  id: string;
  title: string;
  farmer: string;
  crop: string;
  priority: "Cao" | "Trung bình" | "Thấp";
  status: "todo" | "doing" | "done";
  notes: string;
}

const INITIAL_TASKS: FarmingTask[] = [
  {
    id: "1",
    title: "Phun thuốc nấm lá rỉ sắt",
    farmer: "Phạm Đức Minh",
    crop: "Cà phê Robusta",
    priority: "Cao",
    status: "todo",
    notes: "Sử dụng vôi boóc-đô 1% phun ướt đều 2 mặt lá sầu riêng.",
  },
  {
    id: "2",
    title: "Bón phân hữu cơ gốc đợt 3",
    farmer: "Trần Văn Hùng",
    crop: "Sầu riêng Ri6",
    priority: "Trung bình",
    status: "doing",
    notes: "Bón gốc 5-10kg phân hữu cơ hoai mục cho mỗi cây sầu riêng.",
  },
  {
    id: "3",
    title: "Kiểm tra độ ẩm đất qua cảm biến IoT",
    farmer: "Lê Hoàng Anh",
    crop: "Tiêu lốt",
    priority: "Cao",
    status: "doing",
    notes: "Kiểm định trạm IoT số 12 bị nhiễu sóng ẩm.",
  },
  {
    id: "4",
    title: "Xả nước úng bảo vệ ruộng lúa vụ Hè Thu",
    farmer: "Nguyễn Thị Mai",
    crop: "Lúa cao sản",
    priority: "Thấp",
    status: "done",
    notes: "Đã bơm xả rãnh thoát nước thành công ngày hôm qua.",
  },
];

export default function TaskDispatchScreen() {
  const [tasks, setTasks] = useState<FarmingTask[]>(() => {
    try {
      const cached = localStorage.getItem("agrismart_farming_tasks");
      return cached ? JSON.parse(cached) : INITIAL_TASKS;
    } catch (e) {
      return INITIAL_TASKS;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem("agrismart_farming_tasks", JSON.stringify(tasks));
    } catch (e) {
      console.error("Failed to save farming tasks:", e);
    }
  }, [tasks]);

  const [newTitle, setNewTitle] = useState("");
  const [newFarmer, setNewFarmer] = useState("Trần Văn Hùng");
  const [newCrop, setNewCrop] = useState("Sầu riêng Ri6");
  const [newPriority, setNewPriority] = useState<"Cao" | "Trung bình" | "Thấp">("Trung bình");
  const [newNotes, setNewNotes] = useState("");

  // Real-time states
  const [isSoundEnabled, setIsSoundEnabled] = useState(true);
  const [isAutoProgress, setIsAutoProgress] = useState(false);
  const [isTransmitting, setIsTransmitting] = useState(false);
  const [liveLogs, setLiveLogs] = useState<string[]>([
    "🛰️ Đã khởi chạy mạng lưới vô tuyến đồng ruộng.",
    "📡 Trạm Gateway AgriSmart-IoT trực tuyến.",
    "🟢 Công nghệ Sync-Core: Sẵn sàng phát sóng lệnh."
  ]);

  const logContainerRef = useRef<HTMLDivElement>(null);

  // Auto scroll logs
  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [liveLogs]);

  // Audio synthesizer helper
  const playSound = (type: "beep" | "success" | "shimmer") => {
    if (!isSoundEnabled) return;
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      if (type === "beep") {
        // Simple command transmit sound
        osc.type = "sine";
        osc.frequency.setValueAtTime(800, ctx.currentTime);
        gain.gain.setValueAtTime(0.04, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.15);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.15);
      } else if (type === "success") {
        // High ascending double chime
        osc.type = "sine";
        osc.frequency.setValueAtTime(520, ctx.currentTime);
        osc.frequency.setValueAtTime(780, ctx.currentTime + 0.08);
        gain.gain.setValueAtTime(0.04, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.25);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.25);
      } else if (type === "shimmer") {
        // Lower tech warning/alert sweep
        osc.type = "triangle";
        osc.frequency.setValueAtTime(350, ctx.currentTime);
        osc.frequency.setValueAtTime(450, ctx.currentTime + 0.08);
        gain.gain.setValueAtTime(0.03, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.3);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.3);
      }
    } catch (e) {
      console.error("Audio synthesis failed", e);
    }
  };

  const addLog = (message: string) => {
    const time = new Date().toLocaleTimeString("vi-VN", { hour12: false });
    setLiveLogs((prev) => [...prev, `[${time}] ${message}`]);
  };

  // Submit new task with radio telemetry delay
  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    setIsTransmitting(true);
    playSound("beep");
    addLog(`📡 Đang truyền phát vô tuyến lệnh "${newTitle}" tới vùng trồng ${newCrop}...`);

    setTimeout(() => {
      const newTask: FarmingTask = {
        id: String(Date.now()),
        title: newTitle,
        farmer: newFarmer,
        crop: newCrop,
        priority: newPriority,
        status: "todo",
        notes: newNotes || "Không có ghi chú thêm.",
      };

      setTasks((prev) => [...prev, newTask]);
      addLog(`✅ Lệnh sản xuất #${newTask.id.slice(-4)} truyền thành công! Thiết bị của ${newFarmer} đã nhận lệnh.`);
      playSound("success");
      
      setNewTitle("");
      setNewNotes("");
      setIsTransmitting(false);
    }, 1200); // 1.2 second simulated radio wave write latency
  };

  const updateTaskStatus = (id: string, newStatus: "todo" | "doing" | "done") => {
    setTasks((prev) => {
      const updated = prev.map((t) => (t.id === id ? { ...t, status: newStatus } : t));
      const target = prev.find((t) => t.id === id);
      if (target) {
        const statusLabel = newStatus === "todo" ? "CHỜ THỰC HIỆN" : newStatus === "doing" ? "ĐANG TIẾN HÀNH" : "ĐÃ HOÀN THÀNH";
        addLog(`⚡ Cập nhật: Nhiệm vụ "${target.title}" chuyển sang [${statusLabel}] bởi quản trị viên.`);
        playSound(newStatus === "done" ? "success" : "beep");
      }
      return updated;
    });
  };

  const handleDeleteTask = (id: string) => {
    setTasks((prev) => {
      const target = prev.find((t) => t.id === id);
      if (target) {
        addLog(`🗑️ Đã hủy bỏ nhiệm vụ "${target.title}" khỏi mạng điều phối.`);
        playSound("shimmer");
      }
      return prev.filter((t) => t.id !== id);
    });
  };

  // Simulate progress of a random farm task
  const handleSimulateFieldProgress = () => {
    const eligibleTasks = tasks.filter((t) => t.status === "todo" || t.status === "doing");
    if (eligibleTasks.length === 0) {
      addLog("ℹ️ Mọi việc đã hoàn thành hoặc trống. Hãy tạo thêm lệnh sản xuất mới.");
      return;
    }

    const randomTask = eligibleTasks[Math.floor(Math.random() * eligibleTasks.length)];
    const nextStatus: "doing" | "done" = randomTask.status === "todo" ? "doing" : "done";

    setTasks((prev) =>
      prev.map((t) => (t.id === randomTask.id ? { ...t, status: nextStatus } : t))
    );

    const logMessage = nextStatus === "doing"
      ? `👨‍🌾 ${randomTask.farmer} bắt tay vào việc: "${randomTask.title}"`
      : `🎉 ${randomTask.farmer} báo cáo hoàn tất: "${randomTask.title}" (Đồng bộ thành công!)`;

    addLog(logMessage);
    playSound(nextStatus === "done" ? "success" : "beep");
  };

  // Auto simulation effect
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isAutoProgress) {
      addLog("🔄 Đã bật chế độ đồng ruộng tự động thực thi nhiệm vụ (35 giây/lần).");
      timer = setInterval(() => {
        handleSimulateFieldProgress();
      }, 35000);
    } else {
      addLog("⏸️ Đã tạm dừng thực thi tự động ngoài đồng ruộng.");
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isAutoProgress, tasks]);

  return (
    <div id="task-dispatch-root" className="space-y-6">
      
      {/* Header block with realtime label */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-sky-400 text-[10px] font-black uppercase tracking-widest block">Điều phối sản xuất</span>
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-400 text-[9px] font-bold tracking-wider">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse" />
              ĐỒNG BỘ THỜI GIAN THỰC
            </span>
          </div>
          <h2 className="text-slate-100 font-black text-2xl tracking-tight">Giao việc Sản xuất & Đồng ruộng</h2>
          <p className="text-slate-400 text-xs mt-0.5">Phân bổ nhiệm vụ trực tiếp đến các hộ liên kết và giám sát tiến độ hoàn thành theo thời gian thực</p>
        </div>

        {/* Sound controls in the header */}
        <button
          onClick={() => {
            setIsSoundEnabled(!isSoundEnabled);
            addLog(isSoundEnabled ? "🔇 Đã tắt âm thanh cảnh báo lệnh." : "🔊 Đã bật âm thanh phản hồi.");
          }}
          className={`p-2.5 rounded-xl border text-xs font-bold transition-all flex items-center justify-center cursor-pointer active:scale-95 self-end md:self-auto ${
            isSoundEnabled 
              ? "bg-slate-900 border-slate-800 text-slate-300 hover:text-slate-100" 
              : "bg-slate-950 border-slate-900 text-slate-600"
          }`}
          title={isSoundEnabled ? "Tắt âm thanh" : "Bật âm thanh"}
        >
          {isSoundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>
      </div>

      {/* 3-way layout grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left column (col-span-3): Task creation form */}
        <div className="lg:col-span-3 bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 h-fit relative overflow-hidden shadow-md">
          {/* Form loading state for wireless transmission latency */}
          {isTransmitting && (
            <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-[1px] flex flex-col items-center justify-center gap-3 z-10">
              <Loader2 className="w-7 h-7 text-indigo-400 animate-spin" />
              <div className="text-center">
                <span className="text-xs font-bold text-indigo-400 block tracking-widest animate-pulse">ĐANG PHÁT SÓNG LỆNH</span>
                <span className="text-[9px] text-slate-500 block">Tần số: 433 MHz LoRa Network</span>
              </div>
            </div>
          )}

          <h3 className="text-slate-100 font-extrabold text-xs uppercase tracking-wider border-b border-slate-800 pb-3 flex items-center gap-1.5">
            <ClipboardList className="w-4 h-4 text-sky-400" />
            Giao nhiệm vụ mới
          </h3>

          <form onSubmit={handleCreateTask} className="space-y-3.5 text-xs">
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block">Nhiệm vụ nông nghiệp</label>
              <input
                type="text"
                required
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="Ví dụ: Phun nấm sầu riêng..."
                className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 placeholder:text-slate-700 font-semibold"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block">Người phụ trách</label>
              <select
                value={newFarmer}
                onChange={(e) => {
                  setNewFarmer(e.target.value);
                  // Auto fill crop matching farmer name for smart feel
                  if (e.target.value === "Trần Văn Hùng") setNewCrop("Sầu riêng Ri6");
                  else if (e.target.value === "Phạm Đức Minh") setNewCrop("Cà phê Robusta");
                  else if (e.target.value === "Lê Hoàng Anh") setNewCrop("Tiêu lốt");
                  else if (e.target.value === "Nguyễn Thị Mai") setNewCrop("Xoài cát Cần Thơ");
                }}
                className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2.5 text-xs text-slate-300 focus:outline-none focus:border-indigo-500 font-semibold"
              >
                <option value="Trần Văn Hùng">Trần Văn Hùng (Sầu riêng)</option>
                <option value="Phạm Đức Minh">Phạm Đức Minh (Cà phê)</option>
                <option value="Lê Hoàng Anh">Lê Hoàng Anh (Cộng tác viên)</option>
                <option value="Nguyễn Thị Mai">Nguyễn Thị Mai (Xoài)</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block">Cây trồng / Sản phẩm</label>
              <input
                type="text"
                value={newCrop}
                onChange={(e) => setNewCrop(e.target.value)}
                className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2.5 text-xs text-slate-305 focus:outline-none focus:border-indigo-500 font-semibold"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block">Độ ưu tiên</label>
              <div className="flex gap-2">
                {["Thấp", "Trung bình", "Cao"].map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setNewPriority(p as any)}
                    className={`flex-1 py-1.5 border rounded-lg text-[10px] font-black tracking-wider uppercase transition-all ${
                      newPriority === p
                        ? p === "Cao"
                          ? "bg-rose-950/80 text-rose-400 border-rose-800"
                          : p === "Trung bình"
                          ? "bg-amber-950/80 text-amber-400 border-amber-800"
                          : "bg-emerald-950/80 text-emerald-400 border-emerald-800"
                        : "bg-slate-950 text-slate-500 border-slate-850/60 hover:border-slate-850"
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block">Ghi chú kỹ thuật</label>
              <textarea
                value={newNotes}
                onChange={(e) => setNewNotes(e.target.value)}
                rows={3}
                placeholder="Nhập liều lượng thuốc, thời gian bón..."
                className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3.5 py-2 text-xs text-slate-205 focus:outline-none focus:border-indigo-500 placeholder:text-slate-700"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-slate-100 font-bold py-2.5 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer text-xs shadow-md shadow-indigo-950/30"
            >
              <Plus className="w-4 h-4" /> Gửi lệnh xuống Đồng ruộng
            </button>
          </form>
        </div>

        {/* Middle column (col-span-6): 3 Kanban columns */}
        <div className="lg:col-span-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* Column 1: Chờ thực hiện */}
          <div className="bg-slate-900/60 p-4 rounded-2xl border border-slate-800/80 space-y-4 flex flex-col h-[560px]">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2 shrink-0">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-indigo-400" /> Chờ thực hiện
              </span>
              <span className="text-[10px] font-mono font-bold bg-slate-950 text-slate-450 px-2 py-0.5 rounded-full border border-slate-850">
                {tasks.filter((t) => t.status === "todo").length}
              </span>
            </div>

            <div className="space-y-3 flex-1 overflow-y-auto pr-1">
              {tasks
                .filter((t) => t.status === "todo")
                .map((t) => (
                  <TaskCard
                    key={t.id}
                    task={t}
                    onStatusChange={updateTaskStatus}
                    onDelete={handleDeleteTask}
                  />
                ))}
              {tasks.filter((t) => t.status === "todo").length === 0 && (
                <div className="h-28 border border-dashed border-slate-850 rounded-xl flex items-center justify-center text-slate-600 text-[10px] font-semibold text-center p-4">
                  Trống. Phát lệnh từ cột trái để thêm nhiệm vụ.
                </div>
              )}
            </div>
          </div>

          {/* Column 2: Đang làm */}
          <div className="bg-slate-900/60 p-4 rounded-2xl border border-slate-800/80 space-y-4 flex flex-col h-[560px]">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2 shrink-0">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-400 animate-spin [animation-duration:12s]" /> Đang làm
              </span>
              <span className="text-[10px] font-mono font-bold bg-slate-950 text-slate-450 px-2 py-0.5 rounded-full border border-slate-850">
                {tasks.filter((t) => t.status === "doing").length}
              </span>
            </div>

            <div className="space-y-3 flex-1 overflow-y-auto pr-1">
              {tasks
                .filter((t) => t.status === "doing")
                .map((t) => (
                  <TaskCard
                    key={t.id}
                    task={t}
                    onStatusChange={updateTaskStatus}
                    onDelete={handleDeleteTask}
                  />
                ))}
              {tasks.filter((t) => t.status === "doing").length === 0 && (
                <div className="h-28 border border-dashed border-slate-850 rounded-xl flex items-center justify-center text-slate-600 text-[10px] font-semibold text-center p-4">
                  Không có công việc nào đang diễn ra.
                </div>
              )}
            </div>
          </div>

          {/* Column 3: Hoàn thành */}
          <div className="bg-slate-900/60 p-4 rounded-2xl border border-slate-800/80 space-y-4 flex flex-col h-[560px]">
            <div className="flex justify-between items-center border-b border-slate-800 pb-2 shrink-0">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> Đã hoàn thành
              </span>
              <span className="text-[10px] font-mono font-bold bg-slate-950 text-slate-450 px-2 py-0.5 rounded-full border border-slate-850">
                {tasks.filter((t) => t.status === "done").length}
              </span>
            </div>

            <div className="space-y-3 flex-1 overflow-y-auto pr-1">
              {tasks
                .filter((t) => t.status === "done")
                .map((t) => (
                  <TaskCard
                    key={t.id}
                    task={t}
                    onStatusChange={updateTaskStatus}
                    onDelete={handleDeleteTask}
                  />
                ))}
              {tasks.filter((t) => t.status === "done").length === 0 && (
                <div className="h-28 border border-dashed border-slate-850 rounded-xl flex items-center justify-center text-slate-600 text-[10px] font-semibold text-center p-4">
                  Chưa có công việc nào được hoàn tất.
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Right column (col-span-3): Realtime logs & simulated worker activities */}
        <div className="lg:col-span-3 space-y-6">
          
          {/* Field simulation panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-md">
            <h3 className="text-slate-100 font-extrabold text-xs uppercase tracking-wider border-b border-slate-800 pb-3 flex items-center gap-1.5">
              <Radio className="w-4 h-4 text-indigo-400 animate-pulse" />
              Mô phỏng Hoạt động Nông hộ
            </h3>

            <p className="text-slate-400 text-[11px] leading-relaxed">
              Mô phỏng hành động phản hồi trực tiếp từ thiết bị cầm tay của nông hộ ngoài đồng ruộng khi họ tiến hành hoặc báo cáo xong nhiệm vụ.
            </p>

            <div className="space-y-2.5">
              <button
                onClick={handleSimulateFieldProgress}
                className="w-full bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-indigo-500/40 text-slate-200 text-[11px] font-black tracking-wide uppercase py-2.5 px-3  rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 shadow-sm"
              >
                <Sparkles className="w-4 h-4 text-indigo-400" />
                Đồng ruộng cập nhật nhanh
              </button>

              <div className="flex items-center justify-between p-3 bg-slate-950/80 border border-slate-850/60 rounded-xl">
                <div>
                  <span className="text-[11px] font-extrabold text-slate-200 block">Tiến độ tự động (IoT)</span>
                  <span className="text-[9px] text-slate-500 block">Nông hộ cập nhật mỗi 35 giây</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isAutoProgress}
                    onChange={(e) => setIsAutoProgress(e.target.checked)}
                    className="sr-only peer cursor-pointer"
                  />
                  <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-slate-400 after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-500 peer-checked:after:bg-slate-100"></div>
                </label>
              </div>
            </div>
          </div>

          {/* Live system logs */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-md flex flex-col h-[280px]">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3 shrink-0">
              <h3 className="text-slate-100 font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-sky-400 animate-pulse" />
                Bộ phát lệnh LoRa (Live)
              </h3>
              <div className="flex items-center gap-1">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span className="text-[9px] font-mono text-slate-450 font-bold uppercase">Transmitting</span>
              </div>
            </div>

            {/* Terminal logs container */}
            <div
              ref={logContainerRef}
              className="flex-1 bg-slate-950 border border-slate-850/80 rounded-2xl p-3 font-mono text-[10px] text-slate-400 overflow-y-auto space-y-2 select-text"
            >
              {liveLogs.map((log, i) => {
                let colorClass = "text-slate-450";
                if (log.includes("👨‍🌾") || log.includes("🎉")) colorClass = "text-amber-400 font-bold";
                else if (log.includes("✅")) colorClass = "text-emerald-400 font-bold";
                else if (log.includes("🛰️") || log.includes("🚀")) colorClass = "text-indigo-400 font-bold";
                else if (log.includes("🗑️")) colorClass = "text-rose-400 font-semibold";
                else if (log.includes("📡")) colorClass = "text-sky-400";

                return (
                  <div key={i} className={`leading-relaxed border-l-2 border-slate-800/50 pl-2 py-0.5 ${colorClass}`}>
                    {log}
                  </div>
                );
              })}
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 gap-2 text-[9px] font-bold uppercase tracking-wider shrink-0 text-slate-500 pt-1">
              <div className="flex items-center gap-1">
                <Wifi className="w-3 h-3 text-sky-400" /> Ping: <span className="font-mono text-slate-300">18ms</span>
              </div>
              <div className="flex items-center gap-1">
                <Cpu className="w-3 h-3 text-indigo-400" /> RF ch: <span className="font-mono text-slate-300">LoRa 43</span>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}

// Sub card component
function TaskCard({
  task,
  onStatusChange,
  onDelete,
}: {
  task: FarmingTask;
  onStatusChange: (id: string, newStatus: "todo" | "doing" | "done") => void;
  onDelete: (id: string) => void;
}) {
  return (
    <div className="p-4 bg-slate-950 border border-slate-850 rounded-2xl hover:border-slate-800 transition-all space-y-3 shadow-md">
      <div className="flex justify-between items-start">
        <span
          className={`text-[8px] px-2 py-0.5 rounded-full font-black tracking-wider uppercase ${
            task.priority === "Cao"
              ? "bg-rose-950 text-rose-400 border border-rose-900/40"
              : task.priority === "Trung bình"
              ? "bg-amber-950 text-amber-400 border border-amber-900/40"
              : "bg-emerald-950 text-emerald-400 border border-emerald-900/40"
          }`}
        >
          {task.priority} Priority
        </span>

        <button
          onClick={() => onDelete(task.id)}
          className="text-slate-600 hover:text-rose-400 transition-colors p-1"
          title="Xóa nhiệm vụ"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="space-y-1">
        <h4 className="font-extrabold text-xs text-slate-200 tracking-wide leading-relaxed">{task.title}</h4>
        <p className="text-slate-500 text-[10px] leading-relaxed">{task.notes}</p>
      </div>

      <div className="flex items-center gap-2 border-t border-slate-900 pt-2.5 text-[11px] font-bold text-slate-400">
        <div className="p-1 bg-slate-900 rounded text-sky-400">
          <User className="w-3 h-3" />
        </div>
        <div className="min-w-0 flex-1">
          <span className="block text-slate-300 truncate">{task.farmer}</span>
          <span className="block text-[9px] text-slate-600 font-medium truncate">{task.crop}</span>
        </div>
      </div>

      {/* Control flows */}
      <div className="flex gap-1 border-t border-slate-900/60 pt-2 text-[9px] font-bold uppercase tracking-wider">
        {task.status !== "todo" && (
          <button
            onClick={() => onStatusChange(task.id, task.status === "done" ? "doing" : "todo")}
            className="flex-1 py-1 text-center text-slate-500 hover:text-slate-300 bg-slate-900 hover:bg-slate-850 rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" /> lùi bước
          </button>
        )}
        {task.status !== "done" && (
          <button
            onClick={() => onStatusChange(task.id, task.status === "todo" ? "doing" : "done")}
            className="flex-1 py-1 text-center text-indigo-400 hover:text-indigo-300 bg-indigo-500/5 hover:bg-indigo-500/10 rounded-lg transition-colors flex items-center justify-center gap-1 cursor-pointer"
          >
            <Play className="w-3 h-3" /> {task.status === "todo" ? "bắt đầu" : "hoàn tất"}
          </button>
        )}
      </div>
    </div>
  );
}
