import React, { useState, useMemo } from "react";
import { motion } from "motion/react";
import { useSyncListener, pushToServer } from "../utils/sync";
import backgroundImg from "../assets/images/smart_farming_bg_1782793350810.jpg";
import {
  TreePine,
  Clock,
  Fingerprint,
  Zap,
  Smartphone,
  Eye,
  EyeOff,
  User,
  AlertCircle,
  HelpCircle,
  ChevronRight,
  ShieldCheck,
  Sun,
  Moon,
} from "lucide-react";

export interface DemoUser {
  name: string;
  email: string;
  role: string;
  roleTag: string;
}

export const DEMO_USERS: DemoUser[] = [
  { name: "Đặng Thị Thanh Vy", email: "admin@agrismart.vn", role: "Quản trị hệ thống", roleTag: "SYSTEM ADMIN" },
  { name: "Đỗ Thị Hà Thanh", email: "analyst@agrismart.vn", role: "Chuyên gia dữ liệu", roleTag: "DATA ANALYST" },
  { name: "Hồ Thủy Hương", email: "farmer@agrismart.vn", role: "Hợp tác xã sầu riêng", roleTag: "FARMER COOP" },
  { name: "Lê Dương Minh Anh", email: "buyer@agrismart.vn", role: "Doanh nghiệp thu mua", roleTag: "BUYER ENTERPRISE" },
  { name: "Lê Hoàng Anh", email: "anhlh@agrismart.vn", role: "Cộng tác viên khảo sát", roleTag: "CONTRIBUTOR" },
];

const DEFAULT_NAME_MAPPING: Record<string, string> = {
  "admin@agrismart.vn": "Đặng Thị Thanh Vy",
  "analyst@agrismart.vn": "Đỗ Thị Hà Thanh",
  "farmer@agrismart.vn": "Hồ Thủy Hương",
  "buyer@agrismart.vn": "Lê Dương Minh Anh",
};

interface LoginScreenProps {
  onLogin: (user: DemoUser) => void;
  isDarkMode?: boolean;
  onToggleTheme?: () => void;
}

export default function LoginScreen({ onLogin, isDarkMode = true, onToggleTheme }: LoginScreenProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("••••••••");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [dynamicUsers, setDynamicUsers] = useState<DemoUser[]>([]);

  React.useEffect(() => {
    try {
      const stored = localStorage.getItem("agrismart_user_accounts");
      if (stored) {
        let parsed: DemoUser[] = JSON.parse(stored);
        let hasChanges = false;
        parsed = parsed.map((u) => {
          const expectedName = DEFAULT_NAME_MAPPING[u.email.toLowerCase()];
          if (expectedName && u.name !== expectedName) {
            hasChanges = true;
            return { ...u, name: expectedName };
          }
          return u;
        });

        if (hasChanges) {
          localStorage.setItem("agrismart_user_accounts", JSON.stringify(parsed));
        }
        setDynamicUsers(parsed);
      } else {
        // Backwards compatibility check
        const storedCollaborators = localStorage.getItem("agrismart_collaborators_accounts");
        const extraCollaborators = storedCollaborators ? JSON.parse(storedCollaborators) : [];
        
        // Merge DEMO_USERS + any existing extra collaborators
        const filteredDynamic = extraCollaborators.filter(
          (du: DemoUser) => !DEMO_USERS.some((su) => su.email.toLowerCase() === du.email.toLowerCase())
        );
        const initialAccounts = [...DEMO_USERS, ...filteredDynamic];
        localStorage.setItem("agrismart_user_accounts", JSON.stringify(initialAccounts));
        setDynamicUsers(initialAccounts);
      }
    } catch (err) {
      console.error("Error loading user accounts:", err);
      setDynamicUsers(DEMO_USERS);
    }
  }, []);

  // Listen to changes in localStorage in case accounts are added/edited in AccountScreen
  React.useEffect(() => {
    const handleStorageChange = () => {
      try {
        const stored = localStorage.getItem("agrismart_user_accounts");
        if (stored) {
          setDynamicUsers(JSON.parse(stored));
        }
      } catch (err) {
        console.error("Error updating user accounts from storage:", err);
      }
    };
    window.addEventListener("storage", handleStorageChange);
    // Also poll/refresh on focus
    window.addEventListener("focus", handleStorageChange);
    return () => {
      window.removeEventListener("storage", handleStorageChange);
      window.removeEventListener("focus", handleStorageChange);
    };
  }, []);

  // Real-time synchronization listener
  useSyncListener<DemoUser[]>("agrismart_user_accounts", (newData) => {
    if (newData && Array.isArray(newData)) {
      setDynamicUsers(newData);
    }
  });

  const mergedUsers = useMemo(() => {
    return dynamicUsers.length > 0 ? dynamicUsers : DEMO_USERS;
  }, [dynamicUsers]);

  const handleDemoClick = (user: DemoUser) => {
    setEmail(user.email);
    setPassword("agrismart2026");
    setErrorMsg("");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setErrorMsg("Vui lòng nhập Email hoặc chọn tài khoản Demo");
      return;
    }

    setIsLoggingIn(true);
    setErrorMsg("");

    // Simulate authenticating against the demo database
    setTimeout(() => {
      const matchedUser = mergedUsers.find(
        (u) => u.email.toLowerCase() === email.toLowerCase()
      );

      if (matchedUser) {
        onLogin(matchedUser);
      } else {
        // Fallback for custom emails
        onLogin({
          name: email.split("@")[0].toUpperCase(),
          email: email,
          role: "Khách mời trải nghiệm",
          roleTag: "GUEST",
        });
      }
      setIsLoggingIn(false);
    }, 1000);
  };

  return (
    <div
      id="login-page-root"
      className="min-h-screen flex flex-col justify-between text-slate-200 font-sans selection:bg-indigo-500/30 selection:text-indigo-200 relative"
      style={{
        backgroundImage: isDarkMode
          ? `radial-gradient(circle at center, rgba(15, 23, 42, 0.75) 0%, rgba(3, 7, 18, 0.95) 100%), url(${backgroundImg})`
          : `radial-gradient(circle at center, rgba(255, 255, 255, 0.88) 0%, rgba(241, 245, 249, 0.99) 100%), url(${backgroundImg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
      }}
    >
      {/* Container wrapper matching CTV Hub visual style */}
      <div className="max-w-7xl mx-auto w-full px-6 lg:px-12 py-10 flex-1 flex flex-col justify-center">
        
        {/* 1. Header logo row & Theme Toggle */}
        <div className="flex items-center justify-between w-full mb-12">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-indigo-600/20 border border-indigo-500/30 rounded-xl text-indigo-400">
              <TreePine className="w-5 h-5" />
            </div>
            <span className="text-slate-200 font-black text-sm tracking-widest uppercase">
              AgriSmart Hub
            </span>
          </div>

          {onToggleTheme && (
            <button
              onClick={onToggleTheme}
              className="p-2 rounded-xl bg-slate-900/40 hover:bg-slate-900 border border-slate-800 hover:border-slate-750 text-slate-400 hover:text-indigo-400 transition-all shadow-md cursor-pointer flex items-center justify-center shrink-0"
              title={isDarkMode ? "Chuyển sang Chế độ Sáng" : "Chuyển sang Chế độ Tối"}
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400 animate-pulse" /> : <Moon className="w-4 h-4 text-indigo-500" />}
            </button>
          )}
        </div>

        {/* 2. Main Login Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Vision & 4 highlights cards */}
          <div className="lg:col-span-7 space-y-12">
            <div className="space-y-6">
              <motion.h2
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="text-slate-100 font-black text-4xl sm:text-5xl lg:text-6xl tracking-tight leading-[1.1]"
              >
                Phân tích & Dự báo
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-sky-400 via-indigo-400 to-purple-400">
                  thông minh & chính xác
                </span>
              </motion.h2>
              <p className="text-slate-400 text-sm sm:text-base max-w-xl leading-relaxed font-medium">
                Hệ thống học máy chuyên sâu tối ưu hóa sản lượng vùng trồng, cảnh báo rủi ro thiên tai, độ ẩm đất và kiểm soát chuỗi cung ứng minh bạch.
              </p>
            </div>

            {/* Bottom highlights - matching 4 bento cards from layout */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              <div className="bg-slate-900/40 backdrop-blur-sm p-5 rounded-2xl border border-slate-800/60 hover:border-slate-700/60 transition-colors space-y-3">
                <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl w-fit border border-indigo-500/20">
                  <Clock className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-200 text-xs uppercase tracking-wider">Mô hình Dự báo Linh hoạt</h4>
                  <p className="text-slate-500 text-[11px] mt-1 leading-normal">
                    Áp dụng Random Forest, Decision Tree CART và Hồi quy tối ưu theo từng mùa vụ.
                  </p>
                </div>
              </div>

              <div className="bg-slate-900/40 backdrop-blur-sm p-5 rounded-2xl border border-slate-800/60 hover:border-slate-700/60 transition-colors space-y-3">
                <div className="p-2 bg-sky-500/10 text-sky-400 rounded-xl w-fit border border-sky-500/20">
                  <Fingerprint className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-200 text-xs uppercase tracking-wider">Bảo Mật Blockchain</h4>
                  <p className="text-slate-500 text-[11px] mt-1 leading-normal">
                    Băm mật dữ liệu đơn hàng và truy xuất nguồn gốc nông sản an toàn tuyệt đối.
                  </p>
                </div>
              </div>

              <div className="bg-slate-900/40 backdrop-blur-sm p-5 rounded-2xl border border-slate-800/60 hover:border-slate-700/60 transition-colors space-y-3">
                <div className="p-2 bg-blue-500/10 text-blue-400 rounded-xl w-fit border border-blue-500/20">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-200 text-xs uppercase tracking-wider">IoT & Realtime Monitoring</h4>
                  <p className="text-slate-500 text-[11px] mt-1 leading-normal">
                    Cập nhật độ ẩm đất, nhiệt độ phòng kính và lượng mưa từng phút qua vệ tinh.
                  </p>
                </div>
              </div>

              <div className="bg-slate-900/40 backdrop-blur-sm p-5 rounded-2xl border border-slate-800/60 hover:border-slate-700/60 transition-colors space-y-3">
                <div className="p-2 bg-purple-500/10 text-purple-400 rounded-xl w-fit border border-purple-500/20">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-200 text-xs uppercase tracking-wider">Cảnh Báo Tự Động</h4>
                  <p className="text-slate-500 text-[11px] mt-1 leading-normal">
                    Tự động hóa cảnh báo hạn hán, bão lũ và sâu bệnh qua SMS đến từng hộ nông dân.
                  </p>
                </div>
              </div>

            </div>
          </div>

          {/* Right Column: Elegant Login Box with Demo user list */}
          <div className="lg:col-span-5 flex flex-col justify-center">
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl shadow-indigo-950/40 backdrop-blur-md relative overflow-hidden">
              <div className="space-y-1">
                <h3 className="text-slate-100 font-extrabold text-2xl tracking-tight">Đăng nhập</h3>
                <p className="text-slate-400 text-xs font-semibold">Sử dụng email được cấp để truy cập hệ thống</p>
              </div>

              {errorMsg && (
                <div className="bg-rose-950/30 border border-rose-900/50 p-3 rounded-xl flex items-center gap-2 text-rose-300 text-xs">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Form Input fields */}
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-slate-400 text-[10px] font-black uppercase tracking-widest block">Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="email@agrismart.vn"
                    className="w-full bg-slate-950 border border-slate-800/80 rounded-xl px-4 py-3 text-xs text-slate-200 font-semibold focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all placeholder:text-slate-700"
                  />
                </div>

                <div className="space-y-1.5 relative">
                  <label className="text-slate-400 text-[10px] font-black uppercase tracking-widest block">Mật khẩu</label>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-slate-950 border border-slate-800/80 rounded-xl pl-4 pr-10 py-3 text-xs text-slate-200 font-semibold focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-600 hover:text-slate-400 transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoggingIn}
                  className="w-full bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-slate-100 font-bold py-3 px-4 rounded-xl transition-all duration-300 disabled:opacity-50 text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-indigo-950/50 cursor-pointer active:scale-[0.98]"
                >
                  {isLoggingIn ? (
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>Đăng nhập</span>
                      <ChevronRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>

              {/* Demo users list mimicking screen reference */}
              <div className="border-t border-slate-800/80 pt-5 space-y-3.5">
                <div className="flex items-center gap-1 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                  <ShieldCheck className="w-3.5 h-3.5 text-indigo-500" />
                  <span>ẤN TÀI KHOẢN DEMO</span>
                </div>

                <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                  {mergedUsers.map((user) => {
                    const isSelected = email === user.email;
                    return (
                      <div
                        key={user.email}
                        onClick={() => handleDemoClick(user)}
                        className={`p-3 rounded-xl border transition-all flex items-center justify-between cursor-pointer group ${
                          isSelected
                            ? "bg-indigo-950/40 border-indigo-500/50"
                            : "bg-slate-950/60 border-slate-800/80 hover:border-slate-700/80 hover:bg-slate-950"
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <div className={`p-1.5 rounded-lg shrink-0 ${
                            isSelected ? "bg-indigo-500/20 text-indigo-400" : "bg-slate-900 text-slate-500 group-hover:text-slate-300"
                          }`}>
                            <User className="w-3.5 h-3.5" />
                          </div>
                          <div>
                            <h5 className="font-bold text-[11px] text-slate-200 tracking-wide">{user.name}</h5>
                            <span className="text-[9px] text-slate-500 font-medium block">{user.email}</span>
                          </div>
                        </div>

                        <span className={`text-[8px] px-2 py-0.5 rounded-full font-extrabold tracking-wider ${
                          user.roleTag === "SYSTEM ADMIN"
                            ? "bg-indigo-950/60 text-indigo-400 border border-indigo-900/40"
                            : user.roleTag === "DATA ANALYST"
                            ? "bg-sky-950/60 text-sky-400 border border-sky-900/40"
                            : user.roleTag === "FARMER COOP"
                            ? "bg-emerald-950/60 text-emerald-400 border border-emerald-900/40"
                            : "bg-amber-950/60 text-amber-400 border border-amber-900/40"
                        }`}>
                          {user.roleTag}
                        </span>
                      </div>
                    );
                  })}
                </div>
                <p className="text-[10px] text-slate-500 text-center font-medium">Click để chọn tài khoản — Bấm "Đăng nhập" để truy cập</p>
              </div>

            </div>
          </div>

        </div>

      </div>

      {/* Footer credits row */}
      <div className="border-t border-slate-900 py-6 text-center text-[10px] text-slate-600 font-bold tracking-widest uppercase shrink-0">
        AGRISMART HUB V2.0 • ENTERPRISE ANALYTICS & PREDICTION SYSTEM
      </div>
    </div>
  );
}
