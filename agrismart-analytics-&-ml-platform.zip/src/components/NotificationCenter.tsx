import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Bell, 
  Check, 
  Trash2, 
  ShieldAlert, 
  Clock, 
  Sparkles, 
  X, 
  Activity, 
  CloudRain, 
  CheckCircle,
  RefreshCw,
  Send,
  Terminal,
  Info
} from "lucide-react";
import { useSyncListener, pushToServer } from "../utils/sync";

export interface AppNotification {
  id: string;
  title: string;
  category: string;
  description: string;
  detailedDescription?: string;
  time: string;
  type: "warning" | "info" | "success";
  read: boolean;
  metrics?: { label: string; value: string; isAlert?: boolean }[];
  actionLabel?: string;
  actionSuccessMessage?: string;
  actionTriggered?: boolean;
}

const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: "notif-1",
    title: "Cảnh báo sâu bệnh sớm",
    category: "CẢM BIẾN IOT MẶT ĐẤT",
    description: "Độ ẩm Đắk Lắk giảm sút đột ngột dưới 50%. Nguy cơ rầy phấn trắng tăng cao trên sầu riêng.",
    detailedDescription: "Hệ thống giám sát vi khí hậu mặt đất ghi nhận độ ẩm tương đối của không khí tại phân vùng sầu riêng liên kết số 3 (Đắk Lắk) đã giảm sâu liên tục trong 3 giờ qua, chạm mức báo động đỏ 48.5%. Điều kiện hanh khô cục bộ này cực kỳ thuận lợi cho bọ trĩ và rầy phấn hại bông phát triển bùng phát.",
    time: "5 phút trước",
    type: "warning",
    read: false,
    metrics: [
      { label: "Độ ẩm hiện tại", value: "48.5% (Báo động)", isAlert: true },
      { label: "Nhiệt độ môi trường", value: "33.8°C", isAlert: false },
      { label: "Mã trạm cảm biến", value: "IoT-KRONGPAC-03", isAlert: false },
      { label: "Mức độ rủi ro rầy", value: "Cao (Cấp độ 3)", isAlert: true },
    ],
    actionLabel: "Kích hoạt phun sương giữ ẩm",
    actionSuccessMessage: "Đã gửi tín hiệu sóng LoRa kích hoạt hệ thống phun sương tự động thành công tại Krông Pắc!",
  },
  {
    id: "notif-2",
    title: "Đã tối ưu hóa thuật toán ML",
    category: "TRÍ TUỆ NHÂN TẠO / HỌC MÁY",
    description: "Huấn luyện lại mô hình dự báo sản lượng đạt độ chính xác R² = 0.94 vượt trội.",
    detailedDescription: "Thuật toán học máy dự đoán sản lượng thu hoạch sầu riêng vừa hoàn thành chu kỳ tối ưu hóa siêu tham số (Hyperparameter Tuning). Nhờ tích hợp thêm lớp dữ liệu mới về chỉ số phát triển lá NDVI từ vệ tinh đa phổ, mô hình đạt độ chính xác R² = 0.94 vượt trội, giúp tối ưu hóa kế hoạch logistics thu mua liên vùng.",
    time: "42 phút trước",
    type: "success",
    read: false,
    metrics: [
      { label: "Độ chính xác R²", value: "0.942 (Xuất sắc)", isAlert: false },
      { label: "Sai số MAPE", value: "3.8%", isAlert: false },
      { label: "Thời gian chạy máy", value: "480 giây (A100 GPU)", isAlert: false },
      { label: "Kích thước tập mẫu", value: "12,450 bản ghi thực địa", isAlert: false },
    ],
    actionLabel: "Triển khai mô hình lên Cloud",
    actionSuccessMessage: "Đã chuyển đổi mô hình ML v2.4 sang trạng thái hoạt động chính thành công!",
  },
  {
    id: "notif-3",
    title: "Thời tiết thay đổi liên vùng",
    category: "HỆ THỐNG KHÍ TƯỢNG VỆ TINH",
    description: "Hệ thống dự báo ghi nhận khả năng mưa giông lớn tại Lâm Đồng vào chiều tối nay.",
    detailedDescription: "Dữ liệu ảnh radar thời tiết mây đối lưu tích điện lớn phát hiện luồng mây giông di chuyển nhanh từ phía Nam về vùng cao nguyên Lâm Đồng (đặc biệt là khu vực canh tác Di Linh). Dự kiến có mưa lớn kèm dông giật mạnh từ cấp 6 đến cấp 8.",
    time: "2 giờ trước",
    type: "info",
    read: false,
    metrics: [
      { label: "Xác suất mưa dông", value: "85%", isAlert: true },
      { label: "Lượng mưa dự tính", value: "40 - 60 mm", isAlert: false },
      { label: "Thời gian mây tiếp cận", value: "16:45 chiều nay", isAlert: false },
      { label: "Tốc độ gió giật", value: "14.2 m/s (Cấp 7)", isAlert: true },
    ],
    actionLabel: "Gửi SMS cảnh báo chủ hộ liên kết",
    actionSuccessMessage: "Hệ thống đã tự động gửi tin nhắn SMS cảnh báo giông gió đến 156 chủ hộ tại Di Linh!",
  },
  {
    id: "notif-4",
    title: "Kiểm duyệt công tác trực nhật",
    category: "GIÁM SÁT HIỆN TRƯỜNG",
    description: "Cộng tác viên Lê Hoàng Anh đã hoàn thành khảo sát thực địa sầu riêng.",
    detailedDescription: "Nhật ký kiểm tra thực địa của khảo sát viên Lê Hoàng Anh đã hoàn thành đầy đủ các tiêu chí: đo độ pH đất, chụp ảnh hình thái lá và gửi báo cáo từ ứng dụng di động. Toàn bộ hình ảnh đã được kiểm định qua hệ thống AI Vision tự động phân loại, không phát hiện sâu nấm phá hoại rễ.",
    time: "4 giờ trước",
    type: "success",
    read: true,
    metrics: [
      { label: "Tên nhân viên", value: "Lê Hoàng Anh", isAlert: false },
      { label: "Số lượng báo cáo tải lên", value: "6 ảnh chất lượng cao", isAlert: false },
      { label: "Kiểm định bởi AI Vision", value: "An toàn (99%)", isAlert: false },
      { label: "Vị trí Check-in", value: "Krông Pắc, Đắk Lắk", isAlert: false },
    ],
    actionLabel: "Phê duyệt nhật ký khảo sát",
    actionSuccessMessage: "Công tác khảo sát đã được phê duyệt. Hệ thống đã ghi nhận 1 lượt hoạt động thực địa thành công cho Lê Hoàng Anh!",
  },
];

interface NotificationCenterProps {
  isDarkMode?: boolean;
}

export default function NotificationCenter({ isDarkMode = true }: NotificationCenterProps) {
  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    const saved = localStorage.getItem("agrismart_notifs");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Seamlessly merge to populate rich metadata fields if not present
        return parsed.map((savedNotif: any) => {
          const matched = INITIAL_NOTIFICATIONS.find((init) => init.id === savedNotif.id);
          return matched ? { ...matched, read: savedNotif.read, actionTriggered: savedNotif.actionTriggered } : savedNotif;
        });
      } catch (e) {
        return INITIAL_NOTIFICATIONS;
      }
    }
    return INITIAL_NOTIFICATIONS;
  });

  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [selectedNotifId, setSelectedNotifId] = useState<string | null>(null);
  const [actionProcessingId, setActionProcessingId] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  // Sync state to local storage and trigger network push
  useEffect(() => {
    try {
      localStorage.setItem("agrismart_notifs", JSON.stringify(notifications));
    } catch (e) {
      console.error(e);
    }
  }, [notifications]);

  // Real-time synchronization listener
  useSyncListener<AppNotification[]>("agrismart_notifs", (newData) => {
    if (newData && Array.isArray(newData)) {
      setNotifications(newData);
    }
  });

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleSelectNotification = (id: string) => {
    setSelectedNotifId(id);
    setActionMessage(null);
    setIsDropdownOpen(false); // Close dropdown when opening full detail view

    // Automatically mark as read
    const updated = notifications.map((n) => (n.id === id ? { ...n, read: true } : n));
    setNotifications(updated);
    pushToServer("agrismart_notifs", updated);
  };

  const handleMarkAllRead = (e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = notifications.map((n) => ({ ...n, read: true }));
    setNotifications(updated);
    pushToServer("agrismart_notifs", updated);
  };

  const handleClearAll = (e: React.MouseEvent) => {
    e.stopPropagation();
    setNotifications([]);
    pushToServer("agrismart_notifs", []);
  };

  const handleTriggerAction = (notif: AppNotification) => {
    if (actionProcessingId) return;
    setActionProcessingId(notif.id);
    setActionMessage(null);

    // Simulate action execution delay
    setTimeout(() => {
      const updated = notifications.map((n) => {
        if (n.id === notif.id) {
          return { ...n, read: true, actionTriggered: true };
        }
        return n;
      });
      setNotifications(updated);
      pushToServer("agrismart_notifs", updated);
      setActionProcessingId(null);
      if (notif.actionSuccessMessage) {
        setActionMessage(notif.actionSuccessMessage);
      }
    }, 1200);
  };

  const selectedNotif = notifications.find((n) => n.id === selectedNotifId);

  return (
    <div className="relative inline-block text-left z-50">
      {/* 1. Primary Bell Icon Trigger Button */}
      <button
        id="btn-bell-notification"
        onClick={() => setIsDropdownOpen(!isDropdownOpen)}
        className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-sky-400 transition-all shadow-md cursor-pointer flex items-center justify-center shrink-0 relative"
        title="Thông báo hệ thống"
      >
        <Bell className="w-4 h-4" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-500 text-[9px] font-black text-white ring-2 ring-slate-950 animate-bounce">
            {unreadCount}
          </span>
        )}
      </button>

      {/* 2. Floating Dropdown Popover */}
      <AnimatePresence>
        {isDropdownOpen && (
          <>
            {/* Transparent click-away overlay to close dropdown */}
            <div 
              id="dropdown-overlay"
              className="fixed inset-0 z-40 bg-transparent cursor-default" 
              onClick={() => setIsDropdownOpen(false)}
            />
            
            <motion.div
              id="notification-dropdown-popup"
              initial={{ opacity: 0, y: -10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.95 }}
              transition={{ duration: 0.15 }}
              className="absolute right-0 lg:-left-12 mt-2 w-80 sm:w-[350px] bg-slate-950/95 border border-slate-850 rounded-2xl shadow-2xl z-50 flex flex-col p-4 backdrop-blur-md"
            >
              {/* Dropdown Header */}
              <div className="flex items-center justify-between border-b border-slate-850 pb-2.5 mb-2 select-none">
                <span className="text-xs font-black text-slate-100 uppercase tracking-wider flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-sky-400" />
                  Hộp Thư Thông Báo
                </span>
                <div className="flex items-center gap-1.5">
                  {unreadCount > 0 && (
                    <button
                      id="btn-mark-all-read"
                      onClick={handleMarkAllRead}
                      className="text-[9px] font-black text-sky-400 hover:text-sky-300 transition-colors uppercase tracking-wider cursor-pointer"
                    >
                      Đọc tất cả
                    </button>
                  )}
                  {notifications.length > 0 && (
                    <button
                      id="btn-clear-all"
                      onClick={handleClearAll}
                      className="p-1 text-slate-500 hover:text-rose-400 rounded transition-colors cursor-pointer"
                      title="Xóa hết"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Notifications List Container */}
              <div className="max-h-80 overflow-y-auto custom-scrollbar divide-y divide-slate-900/60 space-y-1.5 py-1">
                {notifications.length > 0 ? (
                  notifications.map((notif) => {
                    let typeIcon = <Info className="w-3.5 h-3.5 text-sky-400" />;
                    let iconBg = "bg-sky-500/10 border-sky-500/20";
                    let leftBorder = "border-l-2 border-l-sky-500";

                    if (notif.type === "warning") {
                      typeIcon = <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />;
                      iconBg = "bg-rose-500/10 border-rose-500/20";
                      leftBorder = "border-l-2 border-l-rose-500";
                    } else if (notif.type === "success") {
                      typeIcon = <Sparkles className="w-3.5 h-3.5 text-emerald-400" />;
                      iconBg = "bg-emerald-500/10 border-emerald-500/20";
                      leftBorder = "border-l-2 border-l-emerald-500";
                    }

                    return (
                      <div
                        id={`dropdown-item-${notif.id}`}
                        key={notif.id}
                        onClick={() => handleSelectNotification(notif.id)}
                        className={`p-2.5 rounded-xl border border-slate-900 bg-slate-900/30 hover:bg-slate-900/70 transition-all cursor-pointer flex gap-2.5 relative ${leftBorder}`}
                      >
                        {!notif.read && (
                          <span className="absolute top-2 right-2 w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse" />
                        )}

                        <div className={`p-1.5 rounded-lg border shrink-0 flex items-center justify-center self-start mt-0.5 ${iconBg}`}>
                          {typeIcon}
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-1 mb-0.5">
                            <span className="font-mono text-[7.5px] font-bold text-slate-500 uppercase tracking-wider truncate">
                              {notif.category}
                            </span>
                            <span className="text-[7.5px] text-slate-500 font-mono shrink-0">
                              {notif.time}
                            </span>
                          </div>
                          <h4 className="text-[11.5px] font-bold text-slate-100 leading-tight truncate mb-0.5">
                            {notif.title}
                          </h4>
                          <p className="text-[10px] text-slate-400 font-semibold line-clamp-2 leading-relaxed">
                            {notif.description}
                          </p>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="py-10 text-center space-y-2 select-none">
                    <div className="w-8 h-8 rounded-full bg-slate-900 border border-slate-850 flex items-center justify-center mx-auto">
                      <Check className="w-4 h-4 text-emerald-400" />
                    </div>
                    <div>
                      <span className="font-bold text-xs text-slate-300 block">Không có thông báo mới</span>
                      <p className="text-[10px] text-slate-500 max-w-[200px] mx-auto leading-relaxed">
                        Hệ thống hoạt động ổn định, chưa ghi nhận bất kỳ sự cố bất thường nào.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* 3. Sliding Detail Drawer Portal - Slides from Right Side of Page */}
      <AnimatePresence>
        {selectedNotif && (
          <>
            {/* Dark blur overlay behind the detail slide-out */}
            <motion.div
              id="detail-panel-overlay"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-[9999]"
              onClick={() => setSelectedNotifId(null)}
            />

            <motion.div
              id="detail-panel-drawer"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className="fixed top-0 right-0 h-full w-full sm:w-[450px] bg-slate-950/95 border-l border-slate-850 z-[10000] flex flex-col shadow-2xl backdrop-blur-md text-slate-200"
            >
              {/* Detailed Header */}
              <div className="px-6 py-4.5 bg-slate-900/80 border-b border-slate-850 flex items-center justify-between select-none shrink-0">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-xl">
                    <Terminal className="w-4 h-4 animate-pulse" />
                  </div>
                  <div>
                    <h2 className="text-xs font-black text-slate-100 uppercase tracking-wider">Hành Lang Giám Sát Chi Tiết</h2>
                    <span className="text-[9.5px] font-mono text-slate-500 block -mt-0.5">AI Telemetry Control</span>
                  </div>
                </div>
                <button
                  id="btn-close-detail"
                  onClick={() => setSelectedNotifId(null)}
                  className="p-1.5 bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-slate-100 border border-slate-800 rounded-lg cursor-pointer flex items-center justify-center transition-all w-7 h-7"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Detailed Body Scrollable */}
              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                
                {/* Title and Category */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span className={`px-2.5 py-1 text-[9px] font-black font-mono tracking-widest rounded-md uppercase border ${
                      selectedNotif.type === "warning"
                        ? "bg-rose-500/10 border-rose-500/20 text-rose-400"
                        : selectedNotif.type === "success"
                        ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400"
                        : "bg-amber-500/10 border-amber-500/20 text-amber-400"
                    }`}>
                      {selectedNotif.category}
                    </span>
                    <span className="text-slate-500 text-xs font-mono">• {selectedNotif.time}</span>
                  </div>

                  <h3 className="text-base md:text-lg font-black text-slate-100 leading-tight tracking-tight">
                    {selectedNotif.title}
                  </h3>

                  <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 border-b border-slate-900 pb-4">
                    <span>Trạng thái sự kiện:</span>
                    <span className="flex items-center gap-1 text-emerald-400 font-extrabold text-[10.5px]">
                      <CheckCircle className="w-3.5 h-3.5" /> Đã tiếp nhận & ghi nhận
                    </span>
                  </div>
                </div>

                {/* Description Text */}
                <div className="bg-slate-950/40 border border-slate-900/60 p-4 rounded-2xl space-y-2">
                  <span className="text-[9px] font-black text-slate-500 tracking-wider block uppercase">Nội dung báo cáo chi tiết:</span>
                  <p className="text-xs text-slate-300 leading-relaxed font-semibold">
                    {selectedNotif.detailedDescription || selectedNotif.description}
                  </p>
                </div>

                {/* Metrics Grid */}
                {selectedNotif.metrics && selectedNotif.metrics.length > 0 && (
                  <div className="space-y-2.5 select-none">
                    <span className="text-[9px] font-black text-slate-500 tracking-wider block uppercase">Dữ liệu Telemetry cảm biến:</span>
                    
                    <div className="grid grid-cols-2 gap-3">
                      {selectedNotif.metrics.map((m, idx) => (
                        <div 
                          key={`metric-${idx}`} 
                          className={`p-3 rounded-xl border bg-slate-950/60 ${
                            m.isAlert 
                              ? "border-rose-500/20 text-rose-400" 
                              : "border-slate-900 text-slate-300"
                          }`}
                        >
                          <span className="text-[10px] text-slate-500 block font-bold mb-1">{m.label}</span>
                          <span className="text-xs font-mono font-black">{m.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* AI Recommendations */}
                <div className="bg-gradient-to-tr from-indigo-950/20 via-slate-950/60 to-sky-950/10 border border-indigo-500/20 p-5 rounded-2xl space-y-3 relative overflow-hidden">
                  <div className="absolute -top-12 -right-12 w-28 h-28 bg-indigo-500/5 rounded-full blur-2xl pointer-events-none" />
                  
                  <div className="flex items-center gap-2 text-indigo-400">
                    <Sparkles className="w-4 h-4" />
                    <span className="text-[10px] font-mono font-black uppercase tracking-wider">Khuyến nghị điều phối AI AgriSmart:</span>
                  </div>

                  <div className="text-xs text-slate-300 space-y-2 font-medium leading-relaxed">
                    {selectedNotif.type === "warning" ? (
                      <p>
                        Hệ thống đề xuất gửi ngay lệnh điều phối vô tuyến <strong>kích hoạt vòi phun sương làm mát</strong> để kịp thời bảo vệ diện tích hoa và lá non khỏi khô héo do độ ẩm tụt thấp dưới ngưỡng sinh học.
                      </p>
                    ) : selectedNotif.type === "success" ? (
                      <p>
                        Chu kỳ tối ưu hóa mạng nơ-ron hoàn tất không phát hiện dị thường. Đề xuất <strong>áp dụng cập nhật trọng số mô hình</strong> để nâng cao chất lượng ước tính phân bổ logistics sầu riêng.
                      </p>
                    ) : (
                      <p>
                        Hệ mây dông tích tụ năng lượng cao di chuyển tương đối phức tạp. Khuyên người dùng <strong>kiểm tra độ nghiêng của giàn giá đỡ sầu riêng</strong> và dọn thoát nước trước giờ G.
                      </p>
                    )}
                  </div>
                </div>

                {/* Interactive Action Button */}
                {selectedNotif.actionLabel && (
                  <div className="pt-2 border-t border-slate-900 flex flex-col gap-3">
                    {actionMessage ? (
                      <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-2xl flex gap-3 items-center text-xs font-semibold animate-fadeIn">
                        <Check className="w-4 h-4 shrink-0 p-0.5 bg-emerald-500 text-slate-950 rounded-full" />
                        <p className="leading-snug">{actionMessage}</p>
                      </div>
                    ) : (
                      <button
                        id="btn-trigger-action"
                        disabled={actionProcessingId !== null || selectedNotif.actionTriggered}
                        onClick={() => handleTriggerAction(selectedNotif)}
                        className={`w-full py-3 px-4 rounded-xl font-black text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer shadow ${
                          selectedNotif.actionTriggered
                            ? "bg-slate-950 text-slate-500 border border-slate-900 cursor-not-allowed"
                            : "bg-indigo-600 hover:bg-indigo-500 active:scale-98 text-white shadow-indigo-950/30"
                        }`}
                      >
                        {actionProcessingId === selectedNotif.id ? (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                            Đang truyền phát lệnh điều phối...
                          </>
                        ) : selectedNotif.actionTriggered ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            Đã chấp hành hoàn tất
                          </>
                        ) : (
                          <>
                            <Send className="w-3.5 h-3.5" />
                            {selectedNotif.actionLabel}
                          </>
                        )}
                      </button>
                    )}
                  </div>
                )}

              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
