import React, { useState, useMemo } from "react";
import { parseCSV } from "../utils/csvParser";
import { farmerCSV } from "../data/datasets";
import { useSyncListener, pushToServer } from "../utils/sync";
import {
  Users,
  Search,
  Filter,
  ArrowUpDown,
  FileSpreadsheet,
  Plus,
  Eye,
  CheckCircle2,
  XCircle,
  TrendingUp,
  MapPin,
  Leaf,
  Layers,
  Sparkles,
  UserPlus,
  ShieldCheck,
  Mail,
  Phone,
  Briefcase,
  Check,
  Clock,
  Pencil,
} from "lucide-react";

interface FarmerData {
  Farmer_ID: string;
  Farmer_Name: string;
  Province: string;
  Main_Crop: string;
  Farm_Size_Ha: number;
  Annual_Yield_Tons: number;
  Annual_Revenue_M_VND: number;
  Annual_Cost_M_VND: number;
  Adopts_Organic: string;
  Uses_IoT_Sensors: string;
}

interface Collaborator {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: string;
  region: string;
  crop: string;
  status: "Đang hoạt động" | "Ngoại tuyến" | "Đang bận";
  surveyCount: number;
}

const INITIAL_COLLABORATORS: Collaborator[] = [
  {
    id: "CTV001",
    name: "Lê Hoàng Anh",
    email: "anhlh@agrismart.vn",
    phone: "0903.112.233",
    role: "Cộng tác viên khảo sát",
    region: "Đắk Lắk",
    crop: "Tiêu lốt",
    status: "Đang hoạt động",
    surveyCount: 18,
  },
  {
    id: "CTV002",
    name: "Trần Văn Hùng",
    email: "hungtv@agrismart.vn",
    phone: "0918.456.789",
    role: "Cộng tác viên Sầu riêng",
    region: "Bến Tre",
    crop: "Sầu riêng Ri6",
    status: "Đang hoạt động",
    surveyCount: 24,
  },
  {
    id: "CTV003",
    name: "Nguyễn Thị Mai",
    email: "maint@agrismart.vn",
    phone: "0932.789.012",
    role: "Cộng tác viên Thu hoạch",
    region: "Tiền Giang",
    crop: "Xoài Cát Hòa Lộc",
    status: "Đang hoạt động",
    surveyCount: 15,
  },
  {
    id: "CTV004",
    name: "Vương Đình Trung",
    email: "trungvd@agrismart.vn",
    phone: "0989.111.222",
    role: "Kỹ thuật viên sinh học",
    region: "Cần Thơ",
    crop: "Lúa mùa cao sản",
    status: "Ngoại tuyến",
    surveyCount: 31,
  },
];

export default function ContributorScreen() {
  const [activeSubTab, setActiveSubTab] = useState<"ctv" | "nongdan">("ctv");
  
  // Collaborators List State
  const [collaborators, setCollaborators] = useState<Collaborator[]>([]);
  const [ctvSearch, setCtvSearch] = useState("");
  const [ctvRoleFilter, setCtvRoleFilter] = useState("Tất cả");
  const [selectedCollaborator, setSelectedCollaborator] = useState<Collaborator | null>(null);

  // Form State for creating a new Collaborator
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newCtvName, setNewCtvName] = useState("");
  const [newCtvEmail, setNewCtvEmail] = useState("");
  const [newCtvPhone, setNewCtvPhone] = useState("");
  const [newCtvRole, setNewCtvRole] = useState("Cộng tác viên khảo sát");
  const [newCtvRegion, setNewCtvRegion] = useState("Đắk Lắk");
  const [newCtvCrop, setNewCtvCrop] = useState("Sầu riêng Ri6");
  const [successAccount, setSuccessAccount] = useState<{ email: string; name: string; role: string } | null>(null);

  // Form State for editing an existing Collaborator
  const [editingCollaborator, setEditingCollaborator] = useState<Collaborator | null>(null);
  const [editCtvName, setEditCtvName] = useState("");
  const [editCtvEmail, setEditCtvEmail] = useState("");
  const [editCtvPhone, setEditCtvPhone] = useState("");
  const [editCtvRole, setEditCtvRole] = useState("");
  const [editCtvRegion, setEditCtvRegion] = useState("");
  const [editCtvCrop, setEditCtvCrop] = useState("");
  const [editCtvStatus, setEditCtvStatus] = useState<"Đang hoạt động" | "Ngoại tuyến" | "Đang bận">("Đang hoạt động");
  const [editCtvSurveyCount, setEditCtvSurveyCount] = useState(0);

  // Farmers List State
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCrop, setSelectedCrop] = useState("Tất cả");
  const [selectedProvince, setSelectedProvince] = useState("Tất cả");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedFarmer, setSelectedFarmer] = useState<FarmerData | null>(null);
  const [sortConfig, setSortConfig] = useState<{ key: keyof FarmerData; direction: "asc" | "desc" } | null>(null);

  // Initialize Collaborators from LocalStorage
  React.useEffect(() => {
    try {
      const storedList = localStorage.getItem("agrismart_collaborators_list");
      if (storedList) {
        setCollaborators(JSON.parse(storedList));
      } else {
        localStorage.setItem("agrismart_collaborators_list", JSON.stringify(INITIAL_COLLABORATORS));
        setCollaborators(INITIAL_COLLABORATORS);
      }
    } catch (err) {
      console.error("Error parsing collaborators:", err);
      setCollaborators(INITIAL_COLLABORATORS);
    }
  }, []);

  // Real-time sync listener for collaborators
  useSyncListener<Collaborator[]>("agrismart_collaborators_list", (newData) => {
    if (newData && Array.isArray(newData)) {
      setCollaborators(newData);
    }
  });

  // Parse farmers data
  const rawFarmers: FarmerData[] = useMemo(() => {
    const parsed = parseCSV(farmerCSV);
    return parsed.map((row) => {
      const adoptsOrganic = row.Blockchain === true || row.Blockchain === "Yes" ? "Yes" : "No";
      const usesIoT = row.IoT_Device === true || row.IoT_Device === "Yes" ? "Yes" : "No";
      const crop = row.Crop || "Lúa";
      const size = Number(row.Area_Ha) || 0;
      return {
        Farmer_ID: String(row.Farmer_ID || ""),
        Farmer_Name: String(row.Farmer_Name || ""),
        Province: String(row.Province || ""),
        Main_Crop: crop,
        Farm_Size_Ha: size,
        Annual_Yield_Tons: Math.round(size * 4.8),
        Annual_Revenue_M_VND: Number(row.Revenue_Million_VND) || 0,
        Annual_Cost_M_VND: Number(row.Cost_Million_VND) || 0,
        Adopts_Organic: adoptsOrganic,
        Uses_IoT_Sensors: usesIoT,
      };
    });
  }, []);

  const provinces = useMemo(() => {
    const list = new Set(rawFarmers.map((f) => f.Province));
    return ["Tất cả", ...Array.from(list)];
  }, [rawFarmers]);

  const crops = useMemo(() => {
    const list = new Set(rawFarmers.map((f) => f.Main_Crop));
    return ["Tất cả", ...Array.from(list)];
  }, [rawFarmers]);

  const handleSort = (key: keyof FarmerData) => {
    let direction: "asc" | "desc" = "asc";
    if (sortConfig && sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc";
    }
    setSortConfig({ key, direction });
    setCurrentPage(1);
  };

  const sortedFarmers = useMemo(() => {
    const items = [...rawFarmers];
    if (sortConfig) {
      items.sort((a, b) => {
        const aVal = a[sortConfig.key];
        const bVal = b[sortConfig.key];
        
        if (typeof aVal === "number" && typeof bVal === "number") {
          return sortConfig.direction === "asc" ? aVal - bVal : bVal - aVal;
        }
        return sortConfig.direction === "asc"
          ? String(aVal).localeCompare(String(bVal))
          : String(bVal).localeCompare(String(aVal));
      });
    }
    return items;
  }, [rawFarmers, sortConfig]);

  const filteredFarmers = useMemo(() => {
    return sortedFarmers.filter((f) => {
      const matchesSearch = f.Farmer_Name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            f.Farmer_ID.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCrop = selectedCrop === "Tất cả" || f.Main_Crop === selectedCrop;
      const matchesProvince = selectedProvince === "Tất cả" || f.Province === selectedProvince;
      return matchesSearch && matchesCrop && matchesProvince;
    });
  }, [sortedFarmers, searchQuery, selectedCrop, selectedProvince]);

  // Farmers Pagination
  const rowsPerPage = 10;
  const totalPages = Math.ceil(filteredFarmers.length / rowsPerPage);
  const paginatedFarmers = useMemo(() => {
    const start = (currentPage - 1) * rowsPerPage;
    return filteredFarmers.slice(start, start + rowsPerPage);
  }, [filteredFarmers, currentPage]);

  const stats = useMemo(() => {
    const total = filteredFarmers.length;
    const totalHa = filteredFarmers.reduce((sum, f) => sum + (f.Farm_Size_Ha || 0), 0);
    const avgYield = total > 0 ? (filteredFarmers.reduce((sum, f) => sum + (f.Annual_Yield_Tons || 0), 0) / total) : 0;
    const organicCount = filteredFarmers.filter(f => f.Adopts_Organic === "Yes").length;
    return {
      total,
      totalHa: Math.round(totalHa),
      avgYield: Number(avgYield.toFixed(1)),
      organicPercent: total > 0 ? Math.round((organicCount / total) * 100) : 0
    };
  }, [filteredFarmers]);

  // Filtered Collaborators
  const filteredCollaborators = useMemo(() => {
    return collaborators.filter((c) => {
      const matchesSearch =
        c.name.toLowerCase().includes(ctvSearch.toLowerCase()) ||
        c.email.toLowerCase().includes(ctvSearch.toLowerCase()) ||
        c.id.toLowerCase().includes(ctvSearch.toLowerCase()) ||
        c.region.toLowerCase().includes(ctvSearch.toLowerCase());
      const matchesRole = ctvRoleFilter === "Tất cả" || c.role === ctvRoleFilter;
      return matchesSearch && matchesRole;
    });
  }, [collaborators, ctvSearch, ctvRoleFilter]);

  // Collaborator stats
  const ctvStats = useMemo(() => {
    const total = collaborators.length;
    const active = collaborators.filter(c => c.status === "Đang hoạt động").length;
    const totalSurveys = collaborators.reduce((sum, c) => sum + (c.surveyCount || 0), 0);
    const uniqueRegions = new Set(collaborators.map(c => c.region)).size;
    return { total, active, totalSurveys, uniqueRegions };
  }, [collaborators]);

  // Create Collaborator Account Logic
  const handleAddCollaboratorSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCtvName.trim() || !newCtvEmail.trim()) return;

    // Standardize email format
    let email = newCtvEmail.trim();
    if (!email.includes("@")) {
      email = `${email.toLowerCase()}@agrismart.vn`;
    }

    const newId = `CTV${String(collaborators.length + 1).padStart(3, "0")}`;
    const newCTV: Collaborator = {
      id: newId,
      name: newCtvName,
      email,
      phone: newCtvPhone || "09" + Math.floor(10000000 + Math.random() * 90000000),
      role: newCtvRole,
      region: newCtvRegion,
      crop: newCtvCrop,
      status: "Đang hoạt động",
      surveyCount: 0,
    };

    // 1. Save list to state and localStorage
    const updatedList = [...collaborators, newCTV];
    setCollaborators(updatedList);
    pushToServer("agrismart_collaborators_list", updatedList);

    // 2. Save credential to localStorage accounts
    const storedAccounts = localStorage.getItem("agrismart_collaborators_accounts");
    const currentAccounts = storedAccounts ? JSON.parse(storedAccounts) : [];
    const newAccount = {
      name: newCTV.name,
      email: newCTV.email,
      role: newCTV.role,
      roleTag: "CONTRIBUTOR",
    };
    const updatedAccounts = [...currentAccounts, newAccount];
    localStorage.setItem("agrismart_collaborators_accounts", JSON.stringify(updatedAccounts));

    // Also update unified user accounts list
    try {
      const storedUserAccounts = localStorage.getItem("agrismart_user_accounts");
      let userAccounts = [];
      if (storedUserAccounts) {
        userAccounts = JSON.parse(storedUserAccounts);
      } else {
        userAccounts = [
          { name: "Đặng Thị Thanh Vy", email: "admin@agrismart.vn", role: "Quản trị hệ thống", roleTag: "SYSTEM ADMIN" },
          { name: "Đỗ Thị Hà Thanh", email: "analyst@agrismart.vn", role: "Chuyên gia dữ liệu", roleTag: "DATA ANALYST" },
          { name: "Hồ Thủy Hương", email: "farmer@agrismart.vn", role: "Hợp tác xã sầu riêng", roleTag: "FARMER COOP" },
          { name: "Lê Dương Minh Anh", email: "buyer@agrismart.vn", role: "Doanh nghiệp thu mua", roleTag: "BUYER ENTERPRISE" },
          { name: "Lê Hoàng Anh", email: "anhlh@agrismart.vn", role: "Cộng tác viên khảo sát", roleTag: "CONTRIBUTOR" },
        ];
      }
      if (!userAccounts.some((ua: any) => ua.email.toLowerCase() === newAccount.email.toLowerCase())) {
        userAccounts.push(newAccount);
        pushToServer("agrismart_user_accounts", userAccounts);
      }
    } catch (err) {
      console.error("Error syncing to unified user accounts:", err);
    }

    // Set success state to show copyable credentials card
    setSuccessAccount({
      email: newCTV.email,
      name: newCTV.name,
      role: newCTV.role,
    });

    // Reset fields
    setNewCtvName("");
    setNewCtvEmail("");
    setNewCtvPhone("");
  };

  const handleCloseModal = () => {
    setIsAddModalOpen(false);
    setSuccessAccount(null);
  };

  const handleStartEdit = (c: Collaborator) => {
    setEditingCollaborator(c);
    setEditCtvName(c.name);
    setEditCtvEmail(c.email);
    setEditCtvPhone(c.phone);
    setEditCtvRole(c.role);
    setEditCtvRegion(c.region);
    setEditCtvCrop(c.crop);
    setEditCtvStatus(c.status);
    setEditCtvSurveyCount(c.surveyCount);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCollaborator) return;

    const updatedList = collaborators.map((c) => {
      if (c.id === editingCollaborator.id) {
        return {
          ...c,
          name: editCtvName,
          email: editCtvEmail,
          phone: editCtvPhone,
          role: editCtvRole,
          region: editCtvRegion,
          crop: editCtvCrop,
          status: editCtvStatus,
          surveyCount: Number(editCtvSurveyCount) || 0,
        };
      }
      return c;
    });

    setCollaborators(updatedList);
    pushToServer("agrismart_collaborators_list", updatedList);
    setEditingCollaborator(null);
  };

  const handleDeleteCollaborator = (id: string) => {
    if (!window.confirm("Bạn có chắc chắn muốn xóa cộng tác viên này? Hành động này không thể hoàn tác.")) {
      return;
    }
    const updatedList = collaborators.filter((c) => c.id !== id);
    setCollaborators(updatedList);
    pushToServer("agrismart_collaborators_list", updatedList);
    if (selectedCollaborator?.id === id) {
      setSelectedCollaborator(null);
    }
  };

  return (
    <div id="contributor-screen-root" className="space-y-6">
      {/* Header section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-sky-400 text-[10px] font-black uppercase tracking-widest block">Quản lý nhân lực</span>
          <h2 className="text-slate-100 font-black text-2xl tracking-tight">Hệ thống Điều phối Cộng tác viên & Hộ liên kết</h2>
          <p className="text-slate-400 text-xs mt-0.5">
            Quản lý danh sách cộng tác viên khảo sát thổ nhưỡng, kỹ thuật viên cảm biến, cấp phát tài khoản đăng nhập và theo dõi diện tích hộ trồng trọt.
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          {/* Sub-tab navigation selection */}
          <div className="bg-slate-950 p-1 rounded-xl border border-slate-850 flex items-center gap-1">
            <button
              onClick={() => setActiveSubTab("ctv")}
              className={`px-4 py-2 rounded-lg text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                activeSubTab === "ctv"
                  ? "bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 font-black"
                  : "text-slate-500 hover:text-slate-300 border border-transparent"
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Cộng tác viên ({collaborators.length})</span>
            </button>
            <button
              onClick={() => setActiveSubTab("nongdan")}
              className={`px-4 py-2 rounded-lg text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                activeSubTab === "nongdan"
                  ? "bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 font-black"
                  : "text-slate-500 hover:text-slate-300 border border-transparent"
              }`}
            >
              <Leaf className="w-4 h-4" />
              <span>Hộ liên kết ({rawFarmers.length})</span>
            </button>
          </div>
        </div>
      </div>

      {/* VIEW 1: COLLABORATORS LIST TAB (CTV) */}
      {activeSubTab === "ctv" && (
        <>
          {/* CTV Stats Block */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex items-center gap-4">
              <div className="p-3 bg-slate-950 text-indigo-400 rounded-xl border border-slate-800">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Tổng số Cộng tác viên</span>
                <span className="text-xl font-black text-slate-100 font-mono">{ctvStats.total} nhân sự</span>
              </div>
            </div>

            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex items-center gap-4">
              <div className="p-3 bg-slate-950 text-emerald-400 rounded-xl border border-slate-800">
                <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse inline-block mr-0.5"></div>
                <Clock className="w-4 h-4 text-emerald-400 inline-block" />
              </div>
              <div>
                <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Đang hoạt động</span>
                <span className="text-xl font-black text-emerald-400 font-mono">{ctvStats.active} nhân sự</span>
              </div>
            </div>

            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex items-center gap-4">
              <div className="p-3 bg-slate-950 text-sky-400 rounded-xl border border-slate-800">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Tổng lượt khảo sát</span>
                <span className="text-xl font-black text-sky-400 font-mono">{ctvStats.totalSurveys} lượt</span>
              </div>
            </div>

            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex items-center gap-4">
              <div className="p-3 bg-slate-950 text-amber-400 rounded-xl border border-slate-800">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Số tỉnh phủ sóng</span>
                <span className="text-xl font-black text-amber-400 font-mono">{ctvStats.uniqueRegions} khu vực</span>
              </div>
            </div>
          </div>

          {/* Table and Filter Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            
            {/* Left Filter and Account Action */}
            <div className="lg:col-span-1 space-y-6">
              <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-5 h-fit">
                <div className="flex items-center gap-1.5 border-b border-slate-800 pb-3">
                  <Filter className="w-4 h-4 text-sky-400" />
                  <h4 className="font-bold text-xs uppercase tracking-wider text-slate-200">Lọc Cộng Tác Viên</h4>
                </div>

                <div className="space-y-4 text-xs">
                  {/* Search Input */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider">Tìm kiếm tên / Email / Vùng</label>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600 w-3.5 h-3.5" />
                      <input
                        type="text"
                        value={ctvSearch}
                        onChange={(e) => setCtvSearch(e.target.value)}
                        placeholder="Ví dụ: Lê Hoàng Anh, Đắk Lắk..."
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-medium"
                      />
                    </div>
                  </div>

                  {/* Role Select */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block">Phân loại vai trò</label>
                    <div className="flex flex-col gap-1.5">
                      {["Tất cả", "Cộng tác viên khảo sát", "Cộng tác viên Sầu riêng", "Cộng tác viên Thu hoạch", "Kỹ thuật viên sinh học"].map((role) => (
                        <button
                          key={role}
                          onClick={() => setCtvRoleFilter(role)}
                          className={`w-full text-left px-3 py-2 rounded-xl text-[11px] font-bold border transition-all ${
                            ctvRoleFilter === role
                              ? "bg-indigo-950/80 text-indigo-400 border-indigo-800"
                              : "bg-slate-950 text-slate-500 border-slate-850 hover:border-slate-800 hover:text-slate-300"
                          }`}
                        >
                          {role}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Action: Create Login Account Box */}
              <div className="bg-gradient-to-br from-indigo-950/40 to-slate-900 border border-indigo-500/20 p-5 rounded-2xl space-y-4">
                <div className="space-y-1">
                  <span className="text-[9px] bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 font-black px-2 py-0.5 rounded-full uppercase tracking-wider inline-block">
                    Hành động
                  </span>
                  <h4 className="font-extrabold text-slate-200 text-sm">Cấp & Tạo tài khoản</h4>
                  <p className="text-slate-400 text-[11px] leading-relaxed">
                    Đăng ký cộng tác viên khảo sát thổ nhưỡng mới và tự động cấp tài khoản đăng nhập tương ứng trên AgriSmart Hub.
                  </p>
                </div>

                <button
                  onClick={() => setIsAddModalOpen(true)}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 text-slate-100 font-black py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg shadow-indigo-950/50"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Tạo tài khoản CTV mới</span>
                </button>
              </div>
            </div>

            {/* Right Collaborators Table */}
            <div className="lg:col-span-3">
              <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-800 bg-slate-950/40 text-[10px] font-black text-slate-400 uppercase tracking-wider">
                        <th className="py-3.5 px-4">Mã số</th>
                        <th className="py-3.5 px-4">Thông tin CTV</th>
                        <th className="py-3.5 px-4">Vai trò kỹ thuật</th>
                        <th className="py-3.5 px-4">Khu vực phụ trách</th>
                        <th className="py-3.5 px-4 text-center">Khảo sát</th>
                        <th className="py-3.5 px-4 text-center">Trạng thái</th>
                        <th className="py-3.5 px-4 text-right">Hành động</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 text-xs text-slate-300">
                      {filteredCollaborators.length > 0 ? (
                        filteredCollaborators.map((c) => (
                          <tr key={c.id} className="hover:bg-slate-800/30 transition-colors">
                            <td className="py-3.5 px-4 font-mono font-bold text-indigo-400">{c.id}</td>
                            <td className="py-3.5 px-4">
                              <div className="font-bold text-slate-200">{c.name}</div>
                              <div className="text-[10px] text-slate-500 font-mono mt-0.5">{c.email}</div>
                              <div className="text-[10px] text-slate-500 font-mono">{c.phone}</div>
                            </td>
                            <td className="py-3.5 px-4">
                              <span className="flex items-center gap-1.5">
                                <Briefcase className="w-3.5 h-3.5 text-slate-500" />
                                <span className="font-semibold text-slate-300">{c.role}</span>
                              </span>
                            </td>
                            <td className="py-3.5 px-4">
                              <div className="flex items-center gap-1 text-slate-400">
                                <MapPin className="w-3.5 h-3.5 text-slate-500" />
                                <span>{c.region}</span>
                              </div>
                              <span className="text-[9px] bg-slate-950 border border-slate-850 text-slate-500 px-1.5 py-0.5 rounded font-bold block w-fit mt-1">
                                {c.crop}
                              </span>
                            </td>
                            <td className="py-3.5 px-4 text-center font-mono font-bold text-sky-400">
                              {c.surveyCount} ca
                            </td>
                            <td className="py-3.5 px-4 text-center">
                              {c.status === "Đang hoạt động" ? (
                                <span className="inline-flex items-center gap-1 text-[9px] px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-900/40 rounded-full font-extrabold uppercase">
                                  ● HOẠT ĐỘNG
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-[9px] px-2 py-0.5 bg-slate-950 text-slate-500 border border-slate-850 rounded-full font-extrabold uppercase">
                                  NGOẠI TUYẾN
                                </span>
                              )}
                            </td>
                            <td className="py-3.5 px-4 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  onClick={() => setSelectedCollaborator(c)}
                                  className="text-sky-400 hover:text-sky-300 p-1.5 bg-sky-500/5 hover:bg-sky-500/10 rounded-lg transition-all cursor-pointer inline-flex items-center gap-1"
                                  title="Xem chi tiết"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                  <span className="text-[10px] font-bold">Xem</span>
                                </button>
                                <button
                                  onClick={() => handleStartEdit(c)}
                                  className="text-amber-400 hover:text-amber-300 p-1.5 bg-amber-500/5 hover:bg-amber-500/10 rounded-lg transition-all cursor-pointer inline-flex items-center gap-1"
                                  title="Chỉnh sửa"
                                >
                                  <Pencil className="w-3.5 h-3.5" />
                                  <span className="text-[10px] font-bold">Sửa</span>
                                </button>
                                <button
                                  onClick={() => handleDeleteCollaborator(c.id)}
                                  className="text-rose-400 hover:text-rose-300 p-1.5 bg-rose-500/5 hover:bg-rose-500/10 rounded-lg transition-all cursor-pointer inline-flex items-center gap-1"
                                  title="Xóa"
                                >
                                  <XCircle className="w-3.5 h-3.5" />
                                  <span className="text-[10px] font-bold">Xóa</span>
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={7} className="text-center py-12 text-slate-500 font-medium">
                            Không tìm thấy cộng tác viên nào đáp ứng tiêu chí lọc.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

          </div>
        </>
      )}

      {/* VIEW 2: FAMERS LIST TAB (NONGDAN) */}
      {activeSubTab === "nongdan" && (
        <>
          {/* KPI Stats block */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex items-center gap-4">
              <div className="p-3 bg-slate-950 text-indigo-400 rounded-xl border border-slate-800">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Tổng số hộ hiển thị</span>
                <span className="text-xl font-black text-slate-100 font-mono">{stats.total} hộ</span>
              </div>
            </div>

            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex items-center gap-4">
              <div className="p-3 bg-slate-950 text-sky-400 rounded-xl border border-slate-800">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Diện tích canh tác</span>
                <span className="text-xl font-black text-sky-400 font-mono">{stats.totalHa} Ha</span>
              </div>
            </div>

            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex items-center gap-4">
              <div className="p-3 bg-slate-950 text-emerald-400 rounded-xl border border-slate-800">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Sản lượng TB năm</span>
                <span className="text-xl font-black text-emerald-400 font-mono">{stats.avgYield} Tấn</span>
              </div>
            </div>

            <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex items-center gap-4">
              <div className="p-3 bg-slate-950 text-teal-400 rounded-xl border border-slate-800">
                <Leaf className="w-5 h-5" />
              </div>
              <div>
                <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Tỷ lệ canh tác hữu cơ</span>
                <span className="text-xl font-black text-teal-400 font-mono">{stats.organicPercent}%</span>
              </div>
            </div>
          </div>

          {/* Main filter & table columns layout */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Left filter side-panel */}
            <div className="lg:col-span-1 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-5 h-fit">
              <div className="flex items-center gap-1.5 border-b border-slate-800 pb-3">
                <Filter className="w-4 h-4 text-sky-400" />
                <h4 className="font-bold text-xs uppercase tracking-wider text-slate-200">Bộ lọc thông minh</h4>
              </div>

              <div className="space-y-4">
                {/* Search Input */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider">Tìm kiếm tên / Mã hộ</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600 w-3.5 h-3.5" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                      placeholder="Ví dụ: Nông hộ 12, F012..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>

                {/* Crop Select */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block">Phân loại Cây trồng</label>
                  <div className="flex flex-wrap gap-1.5">
                    {crops.map((crop) => (
                      <button
                        key={crop}
                        onClick={() => { setSelectedCrop(crop); setCurrentPage(1); }}
                        className={`px-2.5 py-1.5 rounded-lg text-[10px] font-bold border transition-all ${
                          selectedCrop === crop
                            ? "bg-sky-950/80 text-sky-400 border-sky-800"
                            : "bg-slate-950 text-slate-500 border-slate-850 hover:border-slate-800 hover:text-slate-300"
                        }`}
                      >
                        {crop}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Province Select */}
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider block">Khu vực địa lý</label>
                  <select
                    value={selectedProvince}
                    onChange={(e) => { setSelectedProvince(e.target.value); setCurrentPage(1); }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500 font-semibold"
                  >
                    {provinces.map((prov) => (
                      <option key={prov} value={prov}>{prov}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Right main table column */}
            <div className="lg:col-span-3 space-y-4">
              <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-800 bg-slate-950/40 text-[10px] font-black text-slate-400 uppercase tracking-wider">
                        <th className="py-3.5 px-4 cursor-pointer hover:bg-slate-900/60 transition-colors" onClick={() => handleSort("Farmer_ID")}>
                          <span className="flex items-center gap-1.5">Mã hộ <ArrowUpDown className="w-3 h-3" /></span>
                        </th>
                        <th className="py-3.5 px-4 cursor-pointer hover:bg-slate-900/60 transition-colors" onClick={() => handleSort("Farmer_Name")}>
                          <span className="flex items-center gap-1.5">Tên chủ hộ <ArrowUpDown className="w-3 h-3" /></span>
                        </th>
                        <th className="py-3.5 px-4">Khu vực</th>
                        <th className="py-3.5 px-4">Diện tích (Ha)</th>
                        <th className="py-3.5 px-4">Sản phẩm chính</th>
                        <th className="py-3.5 px-4 text-center">IoT Cảm Biến</th>
                        <th className="py-3.5 px-4 text-right">Chi tiết</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 text-xs text-slate-300">
                      {paginatedFarmers.length > 0 ? (
                        paginatedFarmers.map((f) => (
                          <tr key={f.Farmer_ID} className="hover:bg-slate-800/30 transition-colors">
                            <td className="py-3.5 px-4 font-mono font-bold text-indigo-400">{f.Farmer_ID}</td>
                            <td className="py-3.5 px-4 font-bold text-slate-200">{f.Farmer_Name}</td>
                            <td className="py-3.5 px-4">
                              <span className="flex items-center gap-1">
                                <MapPin className="w-3 h-3 text-slate-500" />
                                {f.Province}
                              </span>
                            </td>
                            <td className="py-3.5 px-4 font-mono font-semibold">{f.Farm_Size_Ha} ha</td>
                            <td className="py-3.5 px-4">
                              <span className={`inline-block px-2 py-0.5 rounded text-[9px] font-extrabold tracking-wider ${
                                f.Main_Crop === "Sầu riêng"
                                  ? "bg-amber-950 text-amber-400 border border-amber-900/30"
                                  : f.Main_Crop === "Cà phê"
                                  ? "bg-amber-900/20 text-orange-400 border border-orange-900/30"
                                  : f.Main_Crop === "Lúa"
                                  ? "bg-emerald-950 text-emerald-400 border border-emerald-900/30"
                                  : "bg-sky-950 text-sky-400 border border-sky-900/30"
                              }`}>
                                {f.Main_Crop.toUpperCase()}
                              </span>
                            </td>
                            <td className="py-3.5 px-4 text-center">
                              {f.Uses_IoT_Sensors === "Yes" ? (
                                <span className="inline-flex items-center gap-1 text-[9px] px-2 py-0.5 bg-teal-950/80 text-teal-400 border border-teal-900/40 rounded-full font-bold">
                                  ● HOẠT ĐỘNG
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-[9px] px-2 py-0.5 bg-slate-950 text-slate-500 border border-slate-850 rounded-full font-bold">
                                  NGOẠI TUYẾN
                                </span>
                              )}
                            </td>
                            <td className="py-3.5 px-4 text-right">
                              <button
                                onClick={() => setSelectedFarmer(f)}
                                className="text-sky-400 hover:text-sky-300 p-1.5 bg-sky-500/5 hover:bg-sky-500/10 rounded-lg transition-all cursor-pointer"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={7} className="text-center py-12 text-slate-500 font-medium">
                            Không tìm thấy nông hộ liên kết nào đáp ứng tiêu chí lọc.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Pagination footer block */}
                {totalPages > 1 && (
                  <div className="bg-slate-950/40 px-4 py-3 border-t border-slate-800 flex justify-between items-center text-xs">
                    <span className="text-slate-500">Hiển thị {paginatedFarmers.length} trên tổng số {filteredFarmers.length} hộ</span>
                    <div className="flex gap-1">
                      <button
                        disabled={currentPage === 1}
                        onClick={() => setCurrentPage(currentPage - 1)}
                        className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 disabled:opacity-40 transition-colors cursor-pointer"
                      >
                        Trước
                      </button>
                      <span className="px-3 py-1 bg-slate-800 rounded font-bold text-slate-200">{currentPage} / {totalPages}</span>
                      <button
                        disabled={currentPage === totalPages}
                        onClick={() => setCurrentPage(currentPage + 1)}
                        className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 disabled:opacity-40 transition-colors cursor-pointer"
                      >
                        Sau
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </>
      )}

      {/* DETAIL DIALOG: COLLABORATOR */}
      {selectedCollaborator && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 max-w-lg w-full space-y-6 shadow-2xl relative">
            <div className="flex justify-between items-start">
              <div>
                <span className="font-mono text-indigo-400 font-black text-[10px] tracking-widest block">MÃ SỐ CTV: {selectedCollaborator.id}</span>
                <h3 className="font-black text-slate-100 text-xl leading-tight">{selectedCollaborator.name}</h3>
                <p className="text-slate-400 text-xs mt-0.5 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-500" />
                  Khu vực: <strong className="text-slate-200">{selectedCollaborator.region}</strong>
                </p>
              </div>
              <button
                onClick={() => setSelectedCollaborator(null)}
                className="p-1.5 hover:bg-slate-850 rounded-lg text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <hr className="border-slate-800" />

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-850 space-y-1">
                <span className="text-slate-500 font-bold block uppercase text-[9px] tracking-wider">Thông tin liên lạc</span>
                <span className="text-slate-200 block truncate font-medium">{selectedCollaborator.email}</span>
                <span className="text-slate-400 font-mono block">{selectedCollaborator.phone}</span>
              </div>

              <div className="p-4 bg-slate-950 rounded-xl border border-slate-850 space-y-1">
                <span className="text-slate-500 font-bold block uppercase text-[9px] tracking-wider">Chức vụ & Nhiệm vụ</span>
                <span className="text-indigo-400 font-bold block">{selectedCollaborator.role}</span>
                <span className="text-slate-400 block">Sản phẩm chính: {selectedCollaborator.crop}</span>
              </div>
            </div>

            <div className="space-y-3.5 text-xs">
              <h4 className="font-black text-[10px] uppercase text-slate-400 tracking-widest block">Hiệu năng & Hoạt động</h4>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-slate-950/50 rounded-xl border border-slate-850 flex items-center justify-between">
                  <span className="text-slate-400">Số đợt khảo sát hoàn thành</span>
                  <span className="text-sky-400 font-black font-mono text-base">{selectedCollaborator.surveyCount}</span>
                </div>
                <div className="p-3 bg-slate-950/50 rounded-xl border border-slate-850 flex items-center justify-between">
                  <span className="text-slate-400">Trạng thái kết nối</span>
                  <span className={`font-bold ${selectedCollaborator.status === "Đang hoạt động" ? "text-emerald-400" : "text-slate-500"}`}>
                    {selectedCollaborator.status.toUpperCase()}
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-indigo-950/20 p-4 rounded-xl border border-indigo-900/30 text-[11px] leading-relaxed text-slate-400 flex items-start gap-2.5">
              <ShieldCheck className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-indigo-300 block mb-1">Cấu hình bảo mật tài khoản:</strong>
                Tài khoản này được cấp quyền truy cập để ghi nhận dữ liệu thổ nhưỡng, cập nhật IoT thông qua định dạng mã băm chuỗi khối (Blockchain) để đảm bảo tính bất biến của nhật ký đồng ruộng.
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => {
                  const c = selectedCollaborator;
                  setSelectedCollaborator(null);
                  handleStartEdit(c);
                }}
                className="w-1/2 bg-amber-600 hover:bg-amber-500 text-slate-100 font-bold py-2.5 rounded-xl transition-colors text-xs cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Pencil className="w-3.5 h-3.5" />
                <span>Chỉnh sửa</span>
              </button>
              <button
                onClick={() => setSelectedCollaborator(null)}
                className="w-1/2 bg-slate-950 border border-slate-850 text-slate-400 hover:text-slate-200 font-bold py-2.5 rounded-xl transition-colors text-xs cursor-pointer"
              >
                Đóng chi tiết
              </button>
            </div>
          </div>
        </div>
      )}

      {/* EDIT DIALOG: COLLABORATOR */}
      {editingCollaborator && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 max-w-lg w-full space-y-4 shadow-2xl relative">
            <div className="flex justify-between items-start">
              <div>
                <span className="font-mono text-amber-400 font-black text-[10px] tracking-widest block">CHỈNH SỬA CỘNG TÁC VIÊN</span>
                <h3 className="font-black text-slate-100 text-xl leading-tight">Mã số: {editingCollaborator.id}</h3>
              </div>
              <button
                onClick={() => setEditingCollaborator(null)}
                className="p-1.5 hover:bg-slate-850 rounded-lg text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <hr className="border-slate-800" />

            <form onSubmit={handleSaveEdit} className="space-y-4 text-xs">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Họ và tên</label>
                <input
                  type="text"
                  required
                  value={editCtvName}
                  onChange={(e) => setEditCtvName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-200 focus:outline-none focus:border-indigo-500 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Email</label>
                  <input
                    type="email"
                    required
                    value={editCtvEmail}
                    onChange={(e) => setEditCtvEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-200 focus:outline-none focus:border-indigo-500 font-medium"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Số điện thoại</label>
                  <input
                    type="text"
                    required
                    value={editCtvPhone}
                    onChange={(e) => setEditCtvPhone(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-200 focus:outline-none focus:border-indigo-500 font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Vai trò kĩ thuật</label>
                  <select
                    value={editCtvRole}
                    onChange={(e) => setEditCtvRole(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-300 focus:outline-none focus:border-indigo-500 font-semibold"
                  >
                    <option value="Cộng tác viên khảo sát">Cộng tác viên khảo sát</option>
                    <option value="Cộng tác viên Sầu riêng">Cộng tác viên Sầu riêng</option>
                    <option value="Cộng tác viên Thu hoạch">Cộng tác viên Thu hoạch</option>
                    <option value="Kỹ thuật viên sinh học">Kỹ thuật viên sinh học</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Khu vực phụ trách</label>
                  <select
                    value={editCtvRegion}
                    onChange={(e) => setEditCtvRegion(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-300 focus:outline-none focus:border-indigo-500 font-semibold"
                  >
                    <option value="Đắk Lắk">Đắk Lắk</option>
                    <option value="Lâm Đồng">Lâm Đồng</option>
                    <option value="Gia Lai">Gia Lai</option>
                    <option value="Bến Tre">Bến Tre</option>
                    <option value="Tiền Giang">Tiền Giang</option>
                    <option value="Cần Thơ">Cần Thơ</option>
                    <option value="Đồng Tháp">Đồng Tháp</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Sản phẩm chính</label>
                  <input
                    type="text"
                    required
                    value={editCtvCrop}
                    onChange={(e) => setEditCtvCrop(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-200 focus:outline-none focus:border-indigo-500 font-medium"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Số ca khảo sát hoàn thành</label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={editCtvSurveyCount}
                    onChange={(e) => setEditCtvSurveyCount(Number(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-200 focus:outline-none focus:border-indigo-500 font-medium"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Trạng thái kết nối</label>
                <div className="grid grid-cols-3 gap-2">
                  {(["Đang hoạt động", "Ngoại tuyến", "Đang bận"] as const).map((status) => (
                    <button
                      key={status}
                      type="button"
                      onClick={() => setEditCtvStatus(status)}
                      className={`py-2 rounded-xl text-[11px] font-bold border transition-all ${
                        editCtvStatus === status
                          ? "bg-indigo-950/80 text-indigo-400 border-indigo-800"
                          : "bg-slate-950 text-slate-500 border-slate-850 hover:border-slate-800 hover:text-slate-300"
                      }`}
                    >
                      {status}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingCollaborator(null)}
                  className="w-1/2 bg-slate-950 border border-slate-850 text-slate-400 hover:text-slate-200 font-bold py-2.5 rounded-xl transition-all cursor-pointer"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  className="w-1/2 bg-indigo-600 hover:bg-indigo-500 text-slate-100 font-black py-2.5 rounded-xl transition-all cursor-pointer shadow-lg shadow-indigo-950/50"
                >
                  Lưu thay đổi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DETAIL DIALOG: FARMER */}
      {selectedFarmer && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 max-w-lg w-full space-y-6 shadow-2xl relative">
            <div className="flex justify-between items-start">
              <div>
                <span className="font-mono text-indigo-400 font-black text-[10px] tracking-widest block">MÃ ĐĂNG KÝ: {selectedFarmer.Farmer_ID}</span>
                <h3 className="font-black text-slate-100 text-xl leading-tight">{selectedFarmer.Farmer_Name}</h3>
                <p className="text-slate-400 text-xs mt-0.5 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-500" />
                  Khu vực liên kết: <strong className="text-slate-200">{selectedFarmer.Province}</strong>
                </p>
              </div>
              <button
                onClick={() => setSelectedFarmer(null)}
                className="p-1.5 hover:bg-slate-850 rounded-lg text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <hr className="border-slate-800" />

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/40 space-y-1">
                <span className="text-slate-500 font-semibold block">Sản phẩm sản lượng</span>
                <span className="text-sm font-extrabold text-sky-400 block">{selectedFarmer.Main_Crop}</span>
                <span className="text-[10px] text-slate-400 font-mono">Quy mô: {selectedFarmer.Farm_Size_Ha} Ha • Sản lượng: {selectedFarmer.Annual_Yield_Tons} Tấn</span>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/40 space-y-1">
                <span className="text-slate-500 font-semibold block">Hiệu suất tài chính</span>
                <span className="text-sm font-extrabold text-emerald-400 block">{selectedFarmer.Annual_Revenue_M_VND} Triệu VND</span>
                <span className="text-[10px] text-slate-400 font-mono">Chi phí: {selectedFarmer.Annual_Cost_M_VND} Tr • Lợi nhuận: {Math.round(selectedFarmer.Annual_Revenue_M_VND - selectedFarmer.Annual_Cost_M_VND)} Tr</span>
              </div>
            </div>

            <div className="space-y-3.5 text-xs">
              <h4 className="font-black text-[10px] uppercase text-slate-400 tracking-widest block">Chỉ số canh tác bền vững (ESG)</h4>
              
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 flex items-center gap-1.5">
                    <Leaf className="w-4 h-4 text-emerald-400" />
                    Canh tác sinh học Organic
                  </span>
                  {selectedFarmer.Adopts_Organic === "Yes" ? (
                    <span className="text-emerald-400 flex items-center gap-1 font-bold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" /> Đạt chuẩn
                    </span>
                  ) : (
                    <span className="text-slate-500 flex items-center gap-1 font-bold">
                      <XCircle className="w-4 h-4 text-slate-600" /> Chưa Đạt
                    </span>
                  )}
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-slate-400 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-sky-400" />
                    Tích hợp trạm thông minh IoT
                  </span>
                  {selectedFarmer.Uses_IoT_Sensors === "Yes" ? (
                    <span className="text-sky-400 flex items-center gap-1 font-bold">
                      <CheckCircle2 className="w-4 h-4 text-sky-500" /> Hoạt động
                    </span>
                  ) : (
                    <span className="text-slate-500 flex items-center gap-1 font-bold">
                      <XCircle className="w-4 h-4 text-slate-600" /> Chưa có
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-[11px] leading-relaxed text-slate-400">
              <strong className="text-slate-200 block mb-1">💡 Đề xuất tối ưu hóa nông nghiệp bằng AI:</strong>
              {selectedFarmer.Main_Crop === "Sầu riêng"
                ? "Khuyên dùng mô hình Random Forest dự đoán lượng tưới, tăng cường bón vi sinh gốc hữu cơ để duy trì chuẩn xuất khẩu xuất khẩu thị trường Châu Âu."
                : selectedFarmer.Main_Crop === "Cà phê"
                ? "Dự kiến độ mặn vùng trồng thấp. Cần giám sát mốc lượng mưa và sử dụng bẫy côn trùng tự động để giảm thiểu rủi ro nấm lá rỉ sắt."
                : "Ứng dụng cảm biến mực nước IoT thông minh để duy trì chuẩn ướt-khô xen kẽ (AWD), cắt giảm lượng khí phát thải nhà kính đạt chỉ số Carbon Credit cao."}
            </div>

            <button
              onClick={() => setSelectedFarmer(null)}
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-slate-100 font-bold py-2.5 rounded-xl transition-colors text-xs cursor-pointer"
            >
              Hoàn tất kiểm tra
            </button>
          </div>
        </div>
      )}

      {/* MODAL: ADD COLLABORATOR & CREATE LOGIN ACCOUNT */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl relative overflow-hidden space-y-5">
            
            <div className="flex justify-between items-start">
              <div>
                <span className="text-sky-400 text-[9px] font-black uppercase tracking-widest block">Thao tác hệ thống</span>
                <h3 className="text-slate-100 font-extrabold text-lg">Đăng ký & Cấp tài khoản</h3>
                <p className="text-slate-400 text-xs mt-0.5">Tạo hồ sơ cộng tác viên mới và cấp thông tin đăng nhập demo.</p>
              </div>
              <button
                onClick={handleCloseModal}
                className="p-1.5 bg-slate-950 hover:bg-slate-850 text-slate-500 hover:text-slate-300 border border-slate-850 rounded-xl transition-all cursor-pointer text-xs"
              >
                ✕
              </button>
            </div>

            <hr className="border-slate-850" />

            {/* If successful registration, show account card */}
            {successAccount ? (
              <div className="space-y-4">
                <div className="p-4 bg-emerald-950/30 border border-emerald-500/20 rounded-2xl space-y-3.5 text-center">
                  <div className="mx-auto w-10 h-10 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full flex items-center justify-center">
                    <Check className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-slate-200 text-sm">ĐÃ KÍCH HOẠT TÀI KHOẢN THÀNH CÔNG!</h4>
                    <p className="text-slate-500 text-[11px] mt-1">Cộng tác viên hiện đã có thể truy cập hệ thống qua danh mục Demo tại màn hình đăng nhập.</p>
                  </div>
                </div>

                <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-2.5 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Họ tên CTV:</span>
                    <strong className="text-slate-300">{successAccount.name}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Email đăng nhập:</span>
                    <strong className="text-indigo-400 font-mono select-all">{successAccount.email}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Mật khẩu mặc định:</span>
                    <strong className="text-emerald-400 font-mono">agrismart2026</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Vai trò:</span>
                    <span className="text-xs text-sky-400 font-bold">{successAccount.role}</span>
                  </div>
                </div>

                <div className="text-[10px] text-slate-500 leading-normal bg-slate-950/50 p-3 rounded-lg border border-slate-900">
                  💡 <strong>Hướng dẫn sử dụng:</strong> Quay về màn hình đăng nhập chính (bằng cách ấn nút "Thoát" ở sidebar hoặc tải lại trang). Tài khoản mới này sẽ tự động xuất hiện ở phần <strong>"ẤN TÀI KHOẢN DEMO"</strong> để bạn click và đăng nhập trải nghiệm ngay lập tức!
                </div>

                <button
                  onClick={handleCloseModal}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 text-slate-100 font-black py-2.5 rounded-xl transition-all text-xs cursor-pointer"
                >
                  Hoàn tất và quay lại danh sách
                </button>
              </div>
            ) : (
              /* Input Form */
              <form onSubmit={handleAddCollaboratorSubmit} className="space-y-4 text-xs">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Họ và tên cộng tác viên</label>
                  <input
                    type="text"
                    required
                    value={newCtvName}
                    onChange={(e) => setNewCtvName(e.target.value)}
                    placeholder="Ví dụ: Hoàng Minh Trí"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 placeholder:text-slate-700 font-semibold"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Email prefix (Tự động thêm @agrismart.vn)</label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={newCtvEmail}
                      onChange={(e) => setNewCtvEmail(e.target.value)}
                      placeholder="Ví dụ: trihm"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-3.5 pr-32 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 placeholder:text-slate-700 font-mono font-semibold"
                    />
                    <div className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-bold font-mono pointer-events-none text-[11px]">
                      @agrismart.vn
                    </div>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Số điện thoại liên hệ</label>
                  <input
                    type="text"
                    value={newCtvPhone}
                    onChange={(e) => setNewCtvPhone(e.target.value)}
                    placeholder="Ví dụ: 0987123456 (Để trống tự động tạo)"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 placeholder:text-slate-700 font-semibold"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Vai trò nghiệp vụ</label>
                  <select
                    value={newCtvRole}
                    onChange={(e) => setNewCtvRole(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500 font-semibold"
                  >
                    <option value="Cộng tác viên khảo sát">Cộng tác viên khảo sát</option>
                    <option value="Cộng tác viên Sầu riêng">Cộng tác viên Sầu riêng</option>
                    <option value="Cộng tác viên Thu hoạch">Cộng tác viên Thu hoạch</option>
                    <option value="Kỹ thuật viên sinh học">Kỹ thuật viên sinh học</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Khu vực phụ trách</label>
                    <input
                      type="text"
                      required
                      value={newCtvRegion}
                      onChange={(e) => setNewCtvRegion(e.target.value)}
                      placeholder="Lâm Đồng, Bến Tre..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-semibold"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Sản phẩm phụ trách</label>
                    <input
                      type="text"
                      required
                      value={newCtvCrop}
                      onChange={(e) => setNewCtvCrop(e.target.value)}
                      placeholder="Sầu riêng Ri6, Cà phê..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-semibold"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-slate-100 font-extrabold py-3 rounded-xl transition-all uppercase tracking-wide cursor-pointer text-xs flex items-center justify-center gap-2 mt-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Kích hoạt & Cấp tài khoản</span>
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
