import React, { useState, useEffect, useMemo } from "react";
import { DemoUser } from "./LoginScreen";
import { useSyncListener, pushToServer } from "../utils/sync";
import {
  User,
  Shield,
  KeyRound,
  History,
  CheckCircle2,
  Lock,
  Smartphone,
  Globe,
  Plus,
  Edit2,
  Trash2,
  Search,
  UserPlus,
  Check,
  X,
  AlertCircle,
  RefreshCw,
  Mail,
  Sliders,
} from "lucide-react";

interface AccountScreenProps {
  user: DemoUser;
  onUpdateUser?: (user: DemoUser) => void;
}

const DEFAULT_DEMO_USERS: DemoUser[] = [
  { name: "Đặng Thị Thanh Vy", email: "admin@agrismart.vn", role: "Quản trị hệ thống", roleTag: "SYSTEM ADMIN" },
  { name: "Đỗ Thị Hà Thanh", email: "analyst@agrismart.vn", role: "Chuyên gia dữ liệu", roleTag: "DATA ANALYST" },
  { name: "Hồ Thủy Hương", email: "farmer@agrismart.vn", role: "Hợp tác xã sầu riêng", roleTag: "FARMER COOP" },
  { name: "Lê Dương Minh Anh", email: "buyer@agrismart.vn", role: "Doanh nghiệp thu mua", roleTag: "BUYER ENTERPRISE" },
  { name: "Lê Hoàng Anh", email: "anhlh@agrismart.vn", role: "Cộng tác viên khảo sát", roleTag: "CONTRIBUTOR" },
];

const ROLE_TAG_MAP: Record<string, string> = {
  "Quản trị hệ thống": "SYSTEM ADMIN",
  "Chuyên gia dữ liệu": "DATA ANALYST",
  "Hợp tác xã sầu riêng": "FARMER COOP",
  "Doanh nghiệp thu mua": "BUYER ENTERPRISE",
  "Cộng tác viên khảo sát": "CONTRIBUTOR",
  "Khách mời trải nghiệm": "GUEST",
};

export default function AccountScreen({ user, onUpdateUser }: AccountScreenProps) {
  const [activeSubTab, setActiveSubTab] = useState<"profile" | "accounts">("profile");
  const [accounts, setAccounts] = useState<DemoUser[]>([]);
  
  // Profile Form State
  const [profileName, setProfileName] = useState(user.name);
  const [profileEmail, setProfileEmail] = useState(user.email);
  
  // Create Account State
  const [newName, setNewName] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [newRole, setNewRole] = useState("Cộng tác viên khảo sát");
  
  // Edit Account State
  const [editingAccount, setEditingAccount] = useState<DemoUser | null>(null);
  const [editName, setEditName] = useState("");
  const [editEmail, setEditEmail] = useState("");
  const [editRole, setEditRole] = useState("");

  // Filter States
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("Tất cả");

  // Notification States
  const [notification, setNotification] = useState<{ type: "success" | "error"; message: string } | null>(null);

  // Load accounts database
  useEffect(() => {
    try {
      const stored = localStorage.getItem("agrismart_user_accounts");
      if (stored) {
        setAccounts(JSON.parse(stored));
      } else {
        localStorage.setItem("agrismart_user_accounts", JSON.stringify(DEFAULT_DEMO_USERS));
        setAccounts(DEFAULT_DEMO_USERS);
      }
    } catch (err) {
      console.error("Error loading accounts:", err);
      setAccounts(DEFAULT_DEMO_USERS);
    }
  }, []);

  // Listen to real-time sync updates for accounts
  useSyncListener<DemoUser[]>("agrismart_user_accounts", (newData) => {
    if (newData && Array.isArray(newData)) {
      setAccounts(newData);
    }
  });

  // Update form if current user changes
  useEffect(() => {
    setProfileName(user.name);
    setProfileEmail(user.email);
  }, [user]);

  const triggerNotification = (type: "success" | "error", message: string) => {
    setNotification({ type, message });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  // Profile Update Logic
  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileName.trim() || !profileEmail.trim()) {
      triggerNotification("error", "Họ tên và Email không được để trống!");
      return;
    }

    try {
      const updatedAccounts = accounts.map((acc) => {
        if (acc.email.toLowerCase() === user.email.toLowerCase()) {
          return { ...acc, name: profileName.trim(), email: profileEmail.trim() };
        }
        return acc;
      });

      pushToServer("agrismart_user_accounts", updatedAccounts);
      setAccounts(updatedAccounts);

      const updatedUser: DemoUser = {
        ...user,
        name: profileName.trim(),
        email: profileEmail.trim(),
      };

      if (onUpdateUser) {
        onUpdateUser(updatedUser);
      }

      triggerNotification("success", "Cập nhật hồ sơ cá nhân thành công!");
    } catch (err) {
      console.error(err);
      triggerNotification("error", "Không thể lưu thông tin hồ sơ!");
    }
  };

  // Create Account Logic
  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newEmail.trim()) {
      triggerNotification("error", "Vui lòng nhập đầy đủ Họ tên và Email!");
      return;
    }

    const emailFormatted = newEmail.trim().toLowerCase();
    
    // Check if email already exists
    if (accounts.some((acc) => acc.email.toLowerCase() === emailFormatted)) {
      triggerNotification("error", "Email này đã được đăng ký trên hệ thống!");
      return;
    }

    const tag = ROLE_TAG_MAP[newRole] || "GUEST";
    const newAcc: DemoUser = {
      name: newName.trim(),
      email: emailFormatted,
      role: newRole,
      roleTag: tag,
    };

    const updatedList = [...accounts, newAcc];
    pushToServer("agrismart_user_accounts", updatedList);
    setAccounts(updatedList);

    // If contributor, keep collaborators_accounts in sync too
    if (tag === "CONTRIBUTOR") {
      try {
        const storedCollaborators = localStorage.getItem("agrismart_collaborators_accounts");
        const extraColl = storedCollaborators ? JSON.parse(storedCollaborators) : [];
        if (!extraColl.some((c: any) => c.email.toLowerCase() === emailFormatted)) {
          localStorage.setItem(
            "agrismart_collaborators_accounts",
            JSON.stringify([...extraColl, { name: newAcc.name, email: newAcc.email, role: newAcc.role, roleTag: tag }])
          );
        }
      } catch (err) {
        console.error("Sync error:", err);
      }
    }

    setNewName("");
    setNewEmail("");
    triggerNotification("success", `Tài khoản '${newAcc.name}' đã được tạo thành công!`);
  };

  // Start Editing Account
  const handleStartEdit = (acc: DemoUser) => {
    setEditingAccount(acc);
    setEditName(acc.name);
    setEditEmail(acc.email);
    setEditRole(acc.role);
  };

  // Save Account Edit
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAccount) return;
    if (!editName.trim() || !editEmail.trim()) {
      triggerNotification("error", "Họ tên và Email không được để trống!");
      return;
    }

    const oldEmail = editingAccount.email.toLowerCase();
    const newEmailFormatted = editEmail.trim().toLowerCase();

    // Prevent duplicate email with OTHER accounts
    if (
      newEmailFormatted !== oldEmail &&
      accounts.some((acc) => acc.email.toLowerCase() === newEmailFormatted)
    ) {
      triggerNotification("error", "Email mới trùng khớp với tài khoản khác!");
      return;
    }

    const tag = ROLE_TAG_MAP[editRole] || "GUEST";
    const updatedAccounts = accounts.map((acc) => {
      if (acc.email.toLowerCase() === oldEmail) {
        return { name: editName.trim(), email: newEmailFormatted, role: editRole, roleTag: tag };
      }
      return acc;
    });

    pushToServer("agrismart_user_accounts", updatedAccounts);
    setAccounts(updatedAccounts);

    // If editing currently logged in user, update app context
    if (oldEmail === user.email.toLowerCase()) {
      const updatedMe = { name: editName.trim(), email: newEmailFormatted, role: editRole, roleTag: tag };
      if (onUpdateUser) {
        onUpdateUser(updatedMe);
      }
    }

    setEditingAccount(null);
    triggerNotification("success", "Cập nhật tài khoản thành công!");
  };

  // Delete Account
  const handleDeleteAccount = (accToDelete: DemoUser) => {
    if (accToDelete.email.toLowerCase() === user.email.toLowerCase()) {
      triggerNotification("error", "Bạn không thể tự xóa tài khoản của chính mình!");
      return;
    }

    const confirmed = window.confirm(`Bạn có chắc chắn muốn xóa tài khoản '${accToDelete.name}'?`);
    if (!confirmed) return;

    const updated = accounts.filter((acc) => acc.email.toLowerCase() !== accToDelete.email.toLowerCase());
    pushToServer("agrismart_user_accounts", updated);
    setAccounts(updated);
    triggerNotification("success", "Đã xóa tài khoản thành công!");
  };

  // Filtered list
  const filteredAccounts = useMemo(() => {
    return accounts.filter((acc) => {
      const matchesSearch =
        acc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        acc.email.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesRole = roleFilter === "Tất cả" || acc.role === roleFilter;
      return matchesSearch && matchesRole;
    });
  }, [accounts, searchQuery, roleFilter]);

  return (
    <div id="account-screen-root" className="space-y-6">
      
      {/* Dynamic Toast Notice */}
      {notification && (
        <div
          className={`fixed bottom-6 right-6 px-4 py-3 rounded-2xl border flex items-center gap-2.5 z-50 text-xs font-bold shadow-2xl animate-bounce ${
            notification.type === "success"
              ? "bg-emerald-950 text-emerald-400 border-emerald-900/60"
              : "bg-rose-950 text-rose-400 border-rose-900/60"
          }`}
        >
          {notification.type === "success" ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
          <span>{notification.message}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-sky-400 text-[10px] font-black uppercase tracking-widest block">Cấu hình Hệ thống</span>
          <h2 className="text-slate-100 font-black text-2xl tracking-tight">Cấu hình & Quản lý Tài khoản Đăng nhập</h2>
          <p className="text-slate-400 text-xs mt-0.5">
            Quản lý thông tin cá nhân hiện hành, cấp tài khoản đăng nhập demo mới và thay đổi quyền truy cập của người dùng trên AgriSmart Hub.
          </p>
        </div>

        {/* Tab Selection */}
        <div className="bg-slate-950 p-1 rounded-xl border border-slate-850 flex items-center gap-1">
          <button
            onClick={() => setActiveSubTab("profile")}
            className={`px-4 py-2 rounded-lg text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === "profile"
                ? "bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 font-black"
                : "text-slate-500 hover:text-slate-300 border border-transparent"
            }`}
          >
            <User className="w-4 h-4" />
            <span>Thông tin cá nhân</span>
          </button>
          <button
            onClick={() => setActiveSubTab("accounts")}
            className={`px-4 py-2 rounded-lg text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === "accounts"
                ? "bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 font-black"
                : "text-slate-500 hover:text-slate-300 border border-transparent"
            }`}
          >
            <Shield className="w-4 h-4" />
            <span>Tài khoản Hệ thống ({accounts.length})</span>
          </button>
        </div>
      </div>

      {activeSubTab === "profile" ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Profile Details Block */}
          <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6 h-fit text-center">
            <div className="space-y-4">
              <div className="w-24 h-24 rounded-3xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center font-black text-3xl text-indigo-400 shrink-0 mx-auto select-none shadow-lg shadow-indigo-950/40 relative group">
                {user.name.split(' ').pop()?.charAt(0) || 'U'}
              </div>

              <div>
                <h3 className="font-extrabold text-slate-100 text-lg leading-tight">{user.name}</h3>
                <span className="text-xs text-indigo-400 font-semibold uppercase tracking-wider block mt-1">{user.role}</span>
                <p className="text-slate-500 text-xs font-mono mt-1">{user.email}</p>
              </div>
            </div>

            <hr className="border-slate-800/80" />

            <div className="space-y-3 text-xs text-left">
              <div className="flex justify-between items-center bg-slate-950/40 p-3 rounded-xl border border-slate-850">
                <span className="text-slate-500 font-medium">Vai trò hệ thống:</span>
                <span className="text-indigo-400 font-bold">{user.roleTag}</span>
              </div>

              <div className="flex justify-between items-center bg-slate-950/40 p-3 rounded-xl border border-slate-850">
                <span className="text-slate-500 font-medium">Chuẩn Xác thực:</span>
                <span className="text-slate-300 font-bold">Argon2 + JWT Token</span>
              </div>

              <div className="flex justify-between items-center bg-slate-950/40 p-3 rounded-xl border border-slate-850">
                <span className="text-slate-500 font-medium">Bảo mật thiết bị:</span>
                <span className="text-emerald-400 font-bold flex items-center gap-1">
                  <Shield className="w-3.5 h-3.5 text-emerald-500" /> Cực kỳ an toàn
                </span>
              </div>
            </div>
          </div>

          {/* Edit Profile Form */}
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 h-fit">
            <div className="space-y-1">
              <h4 className="font-extrabold text-slate-100 text-base flex items-center gap-2">
                <KeyRound className="w-5 h-5 text-indigo-400" />
                Cập nhật thông tin Hồ sơ của tôi
              </h4>
              <p className="text-slate-500 text-xs font-semibold">Thay đổi thông tin hiển thị cá nhân và email của phiên làm việc của bạn</p>
            </div>

            <hr className="border-slate-850" />

            <form onSubmit={handleUpdateProfile} className="space-y-4 text-xs">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Họ và Tên</label>
                <input
                  type="text"
                  value={profileName}
                  onChange={(e) => setProfileName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-slate-200 font-semibold focus:outline-none focus:border-indigo-500"
                  placeholder="Nhập họ và tên..."
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Địa chỉ Email</label>
                <input
                  type="email"
                  value={profileEmail}
                  onChange={(e) => setProfileEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-slate-200 font-semibold focus:outline-none focus:border-indigo-500 font-mono"
                  placeholder="Nhập địa chỉ email..."
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-500 text-slate-100 font-black py-2.5 px-6 rounded-xl transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-indigo-950/40"
                >
                  <Check className="w-4 h-4" />
                  <span>Lưu thay đổi hồ sơ</span>
                </button>
              </div>
            </form>
          </div>

        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Create Login Account Form */}
          <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6 h-fit">
            <div className="space-y-1">
              <span className="text-[9px] bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 font-black px-2 py-0.5 rounded-full uppercase tracking-wider inline-block">
                Hành động Admin
              </span>
              <h4 className="font-extrabold text-slate-100 text-base flex items-center gap-1.5">
                <UserPlus className="w-5 h-5 text-indigo-400" />
                Đăng ký Tài khoản mới
              </h4>
              <p className="text-slate-500 text-[11px] leading-relaxed">
                Tạo thêm tài khoản đăng nhập demo mới và cấp vai trò truy cập hệ thống phù hợp.
              </p>
            </div>

            <hr className="border-slate-850" />

            <form onSubmit={handleCreateAccount} className="space-y-4 text-xs">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Họ và Tên</label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                  placeholder="Ví dụ: Lê Thị Hồng"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Email Đăng nhập</label>
                <input
                  type="email"
                  required
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
                  placeholder="Ví dụ: honglt@agrismart.vn"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Phân vai trò truy cập</label>
                <select
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-300 focus:outline-none focus:border-indigo-500 font-semibold"
                >
                  <option value="Quản trị hệ thống">Quản trị hệ thống (SYSTEM ADMIN)</option>
                  <option value="Chuyên gia dữ liệu">Chuyên gia dữ liệu (DATA ANALYST)</option>
                  <option value="Hợp tác xã sầu riêng">Hợp tác xã sầu riêng (FARMER COOP)</option>
                  <option value="Doanh nghiệp thu mua">Doanh nghiệp thu mua (BUYER ENTERPRISE)</option>
                  <option value="Cộng tác viên khảo sát">Cộng tác viên khảo sát (CONTRIBUTOR)</option>
                </select>
              </div>

              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-slate-100 font-black py-2.5 rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-indigo-950/40"
              >
                <Plus className="w-4 h-4" />
                <span>Thêm tài khoản demo</span>
              </button>
            </form>
          </div>

          {/* Accounts List DB Table */}
          <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-0.5">
                <h4 className="font-extrabold text-slate-100 text-base">Cơ sở dữ liệu người dùng</h4>
                <p className="text-slate-500 text-xs font-semibold">Tất cả tài khoản đăng nhập có quyền truy cập ứng dụng</p>
              </div>

              {/* Filters */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-600 w-3.5 h-3.5" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-slate-950 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 w-36 sm:w-48 font-semibold"
                    placeholder="Tìm tên/email..."
                  />
                </div>

                <select
                  value={roleFilter}
                  onChange={(e) => setRoleFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-lg px-2 py-1.5 text-xs text-slate-300 focus:outline-none focus:border-indigo-500 font-semibold"
                >
                  <option value="Tất cả">Tất cả vai trò</option>
                  <option value="Quản trị hệ thống">Quản trị</option>
                  <option value="Chuyên gia dữ liệu">Data Analyst</option>
                  <option value="Hợp tác xã sầu riêng">Nông hộ</option>
                  <option value="Doanh nghiệp thu mua">Doanh nghiệp</option>
                  <option value="Cộng tác viên khảo sát">Cộng tác viên</option>
                </select>
              </div>
            </div>

            <hr className="border-slate-850" />

            {/* List Table */}
            <div className="overflow-x-auto rounded-xl border border-slate-850 bg-slate-950/40">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950/60 text-[10px] font-black text-slate-400 uppercase tracking-wider">
                    <th className="py-3 px-4">Tài khoản</th>
                    <th className="py-3 px-4">Quyền hạn / Role</th>
                    <th className="py-3 px-4 text-center">Tag bảo mật</th>
                    <th className="py-3 px-4 text-right">Tác vụ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-300 font-semibold">
                  {filteredAccounts.length > 0 ? (
                    filteredAccounts.map((acc) => {
                      const isCurrent = acc.email.toLowerCase() === user.email.toLowerCase();
                      return (
                        <tr key={acc.email} className="hover:bg-slate-800/20 transition-colors">
                          <td className="py-3.5 px-4">
                            <div className="flex items-center gap-2.5">
                              <div className="w-8 h-8 rounded-lg bg-indigo-950 border border-indigo-900/50 flex items-center justify-center font-black text-xs text-indigo-400 shrink-0 uppercase">
                                {acc.name.split(' ').pop()?.charAt(0) || 'U'}
                              </div>
                              <div>
                                <span className="font-extrabold text-slate-200 block">
                                  {acc.name}
                                  {isCurrent && (
                                    <span className="text-[9px] bg-indigo-500/10 border border-indigo-500/25 text-indigo-400 font-bold px-1.5 py-0.5 rounded-full ml-1.5">
                                      BẠN
                                    </span>
                                  )}
                                </span>
                                <span className="text-[10px] text-slate-500 font-mono font-medium block">{acc.email}</span>
                              </div>
                            </div>
                          </td>
                          <td className="py-3.5 px-4 text-slate-300">
                            {acc.role}
                          </td>
                          <td className="py-3.5 px-4 text-center">
                            <span className={`inline-block text-[9px] px-2 py-0.5 rounded-full font-black tracking-wide uppercase ${
                              acc.roleTag === "SYSTEM ADMIN"
                                ? "bg-red-950/60 text-red-400 border border-red-900/40"
                                : acc.roleTag === "DATA ANALYST"
                                ? "bg-purple-950/60 text-purple-400 border border-purple-900/40"
                                : acc.roleTag === "FARMER COOP"
                                ? "bg-emerald-950/60 text-emerald-400 border border-emerald-900/40"
                                : "bg-sky-950/60 text-sky-400 border border-sky-900/40"
                            }`}>
                              {acc.roleTag}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => handleStartEdit(acc)}
                                className="p-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-sky-400 rounded-lg transition-colors cursor-pointer"
                                title="Chỉnh sửa thông tin"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteAccount(acc)}
                                disabled={isCurrent}
                                className={`p-1.5 bg-slate-900 border border-slate-800 text-slate-400 hover:text-rose-400 rounded-lg transition-colors ${
                                  isCurrent ? "opacity-30 cursor-not-allowed" : "hover:bg-rose-950/20 cursor-pointer"
                                }`}
                                title="Xóa tài khoản"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td colSpan={4} className="text-center py-10 text-slate-500 font-medium">
                        Không tìm thấy tài khoản nào khớp với kết quả tìm kiếm.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* EDIT ACCOUNT DIALOG MODAL */}
      {editingAccount && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 rounded-3xl border border-slate-850 p-6 max-w-md w-full space-y-5 shadow-2xl relative">
            <div className="flex justify-between items-start">
              <div>
                <span className="font-mono text-indigo-400 font-black text-[10px] tracking-widest block">ADMIN PANEL</span>
                <h3 className="font-extrabold text-slate-100 text-lg">Chỉnh sửa Tài khoản</h3>
                <p className="text-slate-400 text-xs mt-0.5">Thay đổi thông tin truy cập hệ thống của tài khoản này.</p>
              </div>
              <button
                onClick={() => setEditingAccount(null)}
                className="p-1.5 hover:bg-slate-850 rounded-lg text-slate-500 hover:text-slate-300 transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <hr className="border-slate-850" />

            <form onSubmit={handleSaveEdit} className="space-y-4 text-xs">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Họ và Tên</label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Địa chỉ Email</label>
                <input
                  type="email"
                  required
                  value={editEmail}
                  onChange={(e) => setEditEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 focus:outline-none focus:border-indigo-500 font-mono"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Phân quyền vai trò</label>
                <select
                  value={editRole}
                  onChange={(e) => setEditRole(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-350 focus:outline-none focus:border-indigo-500 font-semibold"
                >
                  <option value="Quản trị hệ thống">Quản trị hệ thống (SYSTEM ADMIN)</option>
                  <option value="Chuyên gia dữ liệu">Chuyên gia dữ liệu (DATA ANALYST)</option>
                  <option value="Hợp tác xã sầu riêng">Hợp tác xã sầu riêng (FARMER COOP)</option>
                  <option value="Doanh nghiệp thu mua">Doanh nghiệp thu mua (BUYER ENTERPRISE)</option>
                  <option value="Cộng tác viên khảo sát">Cộng tác viên khảo sát (CONTRIBUTOR)</option>
                </select>
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={() => setEditingAccount(null)}
                  className="flex-1 bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-400 font-bold py-2 px-4 rounded-xl transition-colors cursor-pointer text-center"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-slate-100 font-black py-2 px-4 rounded-xl transition-all cursor-pointer text-center flex items-center justify-center gap-1.5 shadow-lg shadow-indigo-950/40"
                >
                  <Check className="w-4 h-4" />
                  <span>Cập nhật</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
