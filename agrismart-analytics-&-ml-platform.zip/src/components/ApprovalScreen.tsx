import React, { useState, useEffect, useRef } from "react";
import { 
  Check, 
  X, 
  AlertCircle, 
  ShieldAlert, 
  CheckCircle2, 
  UserCheck, 
  Activity, 
  Radio, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  Loader2, 
  Database, 
  Wifi, 
  Cpu
} from "lucide-react";

export interface PendingApproval {
  id: string;
  name: string;
  role: string;
  crop: string;
  avatar: string;
  issue: string;
  timeDetail: string;
  status: "pending" | "approved" | "rejected";
}

interface ApprovalScreenProps {
  approvals: PendingApproval[];
  onAction: (id: string, action: "approved" | "rejected") => void;
  onReset: () => void;
  onAddApproval?: (newApproval: PendingApproval) => void;
}

const SIMULATED_WORKERS = [
  { name: "Nguyễn Thị Mai", role: "Chủ hợp tác xã Xoài", crop: "Xoài Cát Hòa Lộc - Tiền Giang", avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150" },
  { name: "Vương Đình Trung", role: "Kỹ thuật viên sinh học", crop: "Lúa Thơm RVT - Sóc Trăng", avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150" },
  { name: "Phạm Văn Sơn", role: "Cộng tác viên thổ nhưỡng", crop: "Hồ tiêu Đắk Nông - Đắk Lắk", avatar: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150" },
  { name: "Trần Thị Bích", role: "Giám sát viên chất lượng", crop: "Bưởi Da Xanh - Bến Tre", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150" },
  { name: "Lâm Trường Giang", role: "Chuyên viên khảo sát hữu cơ", crop: "Thanh long đỏ - Bình Thuận", avatar: "https://images.unsplash.com/photo-1500048993953-d23a436266cf?w=150" }
];

const SIMULATED_ISSUES = [
  "Cảm biến ẩm báo lỗi chạm mạch nhiệt kế đột ngột ca sáng",
  "Yêu cầu bổ sung nhật ký bón phân phòng rầy nâu bị muộn",
  "Check-out thiếu quét mã QR ranh giới vùng trồng HTX",
  "Báo cáo độ ẩm đất vượt ngưỡng 90% nghi ngờ cảm biến ngập nước",
  "Check-in sớm 15 phút để chuẩn bị phun thuốc kịp đón mưa giông",
  "Chưa tải lên chứng từ kiểm nghiệm dư lượng thuốc trừ sâu theo chuẩn VietGAP"
];

export default function ApprovalScreen({ approvals, onAction, onReset, onAddApproval }: ApprovalScreenProps) {
  const pendingCount = approvals.filter((a) => a.status === "pending").length;
  
  // Real-time states
  const [isSoundEnabled, setIsSoundEnabled] = useState(true);
  const [isAutoStream, setIsAutoStream] = useState(false);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [processingAction, setProcessingAction] = useState<"approved" | "rejected" | null>(null);
  const [liveLogs, setLiveLogs] = useState<string[]>([
    "🚀 Hệ thống LiveSync đã được khởi động thành công.",
    "📡 Đang lắng nghe kênh sự kiện nông hộ AgriSmart...",
    "🟢 Ping kết nối máy chủ: 24ms (Mạng ổn định)"
  ]);

  const logContainerRef = useRef<HTMLDivElement>(null);

  // Auto scroll logs
  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [liveLogs]);

  // Audio synthesizer helper
  const playSound = (type: "success" | "warning" | "alert") => {
    if (!isSoundEnabled) return;
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      if (type === "success") {
        osc.type = "sine";
        osc.frequency.setValueAtTime(650, ctx.currentTime);
        osc.frequency.setValueAtTime(950, ctx.currentTime + 0.08);
        gain.gain.setValueAtTime(0.04, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.2);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.2);
      } else if (type === "warning") {
        osc.type = "triangle";
        osc.frequency.setValueAtTime(280, ctx.currentTime);
        osc.frequency.setValueAtTime(240, ctx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.04, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.25);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.25);
      } else if (type === "alert") {
        osc.type = "sine";
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        osc.frequency.setValueAtTime(550, ctx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.03, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.3);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.3);
      }
    } catch (e) {
      console.error("Audio synthesis failed", e);
    }
  };

  const addLog = (message: string) => {
    const time = new Date().toLocaleTimeString("vi-VN", { hour12: false });
    setLiveLogs((prev) => [...prev, `[${time}] ${message}`]);
  };

  // Simulate incoming request
  const handleSimulateRequest = () => {
    if (!onAddApproval) {
      addLog("⚠️ Tính năng mô phỏng yêu cầu mới chưa được liên kết.");
      return;
    }
    const randomWorker = SIMULATED_WORKERS[Math.floor(Math.random() * SIMULATED_WORKERS.length)];
    const randomIssue = SIMULATED_ISSUES[Math.floor(Math.random() * SIMULATED_ISSUES.length)];
    const id = "SIM-" + Date.now();
    
    const now = new Date();
    const timeDetail = `Hôm nay ${now.getHours().toString().padStart(2, "0")}:${now.getMinutes().toString().padStart(2, "0")} (Ca trực hiện hành)`;

    const newApproval: PendingApproval = {
      id,
      name: randomWorker.name,
      role: randomWorker.role,
      crop: randomWorker.crop,
      avatar: randomWorker.avatar,
      issue: randomIssue,
      timeDetail,
      status: "pending"
    };

    onAddApproval(newApproval);
    playSound("alert");
    addLog(`🔔 [THỜI GIAN THỰC] Nhận yêu cầu phê duyệt mới từ ${randomWorker.name} - ${randomWorker.role}.`);
  };

  // Auto stream simulation
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isAutoStream) {
      addLog("🔄 Đã kích hoạt chế độ tự động tạo yêu cầu nông nghiệp (45 giây/lần).");
      timer = setInterval(() => {
        handleSimulateRequest();
      }, 45000);
    } else {
      addLog("⏸️ Đã tạm dừng chế độ tự động tạo yêu cầu.");
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isAutoStream]);

  // Handle Action with simulated real-time telemetry write latency
  const handleActionClick = (id: string, action: "approved" | "rejected") => {
    if (processingId) return; // Prevent multiple simultaneous triggers
    
    setProcessingId(id);
    setProcessingAction(action);
    const target = approvals.find((a) => a.id === id);
    const label = action === "approved" ? "DUYỆT" : "TỪ CHỐI";
    
    addLog(`⏳ Đang mã hóa & truyền phát quyết định ${label} cho nông hộ ${target?.name || "ẩn danh"}...`);

    // Simulate 900ms roundtrip to IoT server and smart contract sign
    setTimeout(() => {
      onAction(id, action);
      playSound(action === "approved" ? "success" : "warning");
      addLog(`✅ Quyết định ${label} đã hoàn tất đồng bộ! Gửi thông báo đẩy SMS thành công.`);
      setProcessingId(null);
      setProcessingAction(null);
    }, 9000); // 900ms
  };

  return (
    <div id="approval-screen-root" className="space-y-6">
      
      {/* Header section with live status */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-sky-400 text-[10px] font-black uppercase tracking-widest block">Thẩm định thực địa</span>
            <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[9px] font-bold tracking-wider">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              LIVESTREAM ĐANG HOẠT ĐỘNG
            </span>
          </div>
          <h2 className="text-slate-100 font-black text-2xl tracking-tight">Phê duyệt Nhật ký & Sai số Chấm công</h2>
          <p className="text-slate-400 text-xs mt-0.5">Xử lý sai số cảm biến, thiếu vân tay check-out hoặc check-in trễ giờ của CTV theo thời gian thực</p>
        </div>

        <div className="flex gap-2.5">
          {/* Sound Toggle Button */}
          <button
            onClick={() => {
              setIsSoundEnabled(!isSoundEnabled);
              addLog(isSoundEnabled ? "🔇 Đã tắt âm thanh cảnh báo." : "🔊 Đã bật âm thanh phản hồi.");
            }}
            className={`p-2.5 rounded-xl border text-xs font-bold transition-all flex items-center justify-center cursor-pointer active:scale-95 ${
              isSoundEnabled 
                ? "bg-slate-900 border-slate-800 text-slate-300 hover:text-slate-100" 
                : "bg-slate-950 border-slate-900 text-slate-600"
            }`}
            title={isSoundEnabled ? "Tắt âm thanh" : "Bật âm thanh"}
          >
            {isSoundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          <button
            onClick={() => {
              onReset();
              addLog("🔄 Đã thiết lập lại trạng thái dữ liệu phê duyệt ban đầu.");
              playSound("success");
            }}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded-xl text-xs transition-all cursor-pointer font-bold active:scale-95 flex items-center gap-1.5"
          >
            Khôi phục dữ liệu gốc
          </button>
        </div>
      </div>

      {/* Main split dashboard grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side: Pending Approvals List (Col span 8) */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 space-y-6 shadow-md">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
            <div className="space-y-1">
              <h3 className="text-slate-100 font-extrabold text-sm sm:text-base flex items-center gap-2">
                <ShieldAlert className="w-4 sm:w-5 h-4 sm:h-5 text-indigo-400" />
                Hàng chờ kiểm duyệt ({pendingCount})
              </h3>
              <p className="text-slate-500 text-[11px] sm:text-xs font-semibold">Quyết định phê duyệt sẽ được đồng bộ ngay lập tức tới sổ cái vùng trồng</p>
            </div>

            <span className="text-[10px] font-mono font-black bg-rose-500/10 text-rose-400 border border-rose-500/20 px-2.5 py-1 rounded-full uppercase tracking-wider animate-pulse flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-rose-500 rounded-full" />
              {pendingCount} Chờ xử lý
            </span>
          </div>

          <div className="space-y-4">
            {approvals.map((item) => {
              const isLoading = processingId === item.id;
              
              return (
                <div
                  key={item.id}
                  className={`p-4 sm:p-5 rounded-2xl border transition-all flex flex-col md:flex-row justify-between items-start md:items-center gap-4 relative overflow-hidden ${
                    item.status === "approved"
                      ? "bg-emerald-950/15 border-emerald-500/20 opacity-80"
                      : item.status === "rejected"
                      ? "bg-rose-950/15 border-rose-500/20 opacity-80"
                      : "bg-slate-950/50 border-slate-850/80 hover:border-slate-800"
                  }`}
                >
                  {/* Realtime processing overlay spinner */}
                  {isLoading && (
                    <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-[1px] flex items-center justify-center gap-3 z-10">
                      <Loader2 className="w-5 h-5 text-indigo-400 animate-spin" />
                      <span className="text-xs font-bold text-slate-300">Đồng bộ Viễn thông ({processingAction === "approved" ? "DUYỆT" : "TỪ CHỐI"})...</span>
                    </div>
                  )}

                  {/* User Profile Info */}
                  <div className="flex items-start sm:items-center gap-3.5 min-w-0 w-full">
                    <img
                      src={item.avatar}
                      alt={item.name}
                      className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl object-cover ring-2 ring-indigo-500/10 shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-extrabold text-slate-100 text-xs sm:text-sm truncate">{item.name}</h4>
                        <span className="text-[8px] px-1.5 py-0.5 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded font-black uppercase tracking-wider shrink-0">
                          {item.role}
                        </span>
                      </div>
                      
                      {/* Issue Warning Text */}
                      <div className="flex items-start gap-1.5 text-slate-400 text-xs font-semibold">
                        <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                        <div className="min-w-0">
                          <span className="text-slate-300 text-[11px] sm:text-xs block leading-relaxed">{item.issue}</span>
                          <span className="block text-[10px] text-slate-500 font-mono mt-0.5 truncate">{item.timeDetail} • {item.crop}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Action buttons depending on status */}
                  <div className="flex items-center gap-2.5 w-full md:w-auto self-end md:self-auto border-t border-slate-900/60 pt-3 md:pt-0 md:border-none shrink-0">
                    {item.status === "pending" ? (
                      <>
                        <button
                          disabled={processingId !== null}
                          onClick={() => handleActionClick(item.id, "rejected")}
                          className="flex-1 md:flex-initial px-3.5 py-2 bg-slate-900 hover:bg-rose-950/30 text-slate-400 hover:text-rose-400 border border-slate-800 hover:border-rose-900/40 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>TỪ CHỐI</span>
                        </button>
                        <button
                          disabled={processingId !== null}
                          onClick={() => handleActionClick(item.id, "approved")}
                          className="flex-1 md:flex-initial px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-slate-100 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-indigo-950/40 active:scale-95 disabled:opacity-50"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>DUYỆT CA</span>
                        </button>
                      </>
                    ) : item.status === "approved" ? (
                      <div className="flex items-center gap-1.5 text-emerald-400 text-[10px] font-black uppercase tracking-wider bg-emerald-500/10 px-3 py-1.5 rounded-xl border border-emerald-500/20 w-full md:w-auto justify-center">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>ĐÃ PHÊ DUYỆT</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5 text-rose-400 text-[10px] font-black uppercase tracking-wider bg-rose-500/10 px-3 py-1.5 rounded-xl border border-rose-500/20 w-full md:w-auto justify-center">
                        <X className="w-4 h-4" />
                        <span>ĐÃ TỪ CHỐI</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {pendingCount === 0 && (
              <div className="p-8 text-center bg-slate-950/40 border border-slate-850 rounded-2xl flex flex-col items-center justify-center space-y-3.5">
                <div className="p-3 bg-slate-900 border border-slate-800 text-emerald-400 rounded-2xl">
                  <UserCheck className="w-6 h-6 animate-bounce" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-200 text-sm uppercase tracking-wide">Tất cả sạch sẽ!</h4>
                  <p className="text-slate-500 text-xs max-w-sm mx-auto mt-1 leading-normal">
                    Không còn yêu cầu chấm công bất thường nào chờ xử lý. Nhật ký mùa vụ đã hoàn toàn đồng bộ với học máy.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Live Sync Control & Simulator Panel (Col span 4) */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Simulation controller card */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-md">
            <h3 className="text-slate-100 font-extrabold text-xs uppercase tracking-wider border-b border-slate-800 pb-3 flex items-center gap-1.5">
              <Radio className="w-4 h-4 text-emerald-400" />
              Mô phỏng Luồng Thời Gian Thực
            </h3>

            <p className="text-slate-400 text-[11px] leading-relaxed">
              Kiểm tra khả năng phản hồi tức thời của hệ thống bằng cách mô phỏng các biến cố từ máy quét vân tay hoặc cảm biến nông hộ ngoài thực địa.
            </p>

            <div className="space-y-2.5">
              <button
                onClick={handleSimulateRequest}
                className="w-full bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-indigo-500/40 text-slate-200 text-[11px] font-black tracking-wide uppercase py-2.5 px-3 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 shadow-sm"
              >
                <Sparkles className="w-4 h-4 text-indigo-400" />
                Tạo Yêu Cầu Gấp Mới
              </button>

              <div className="flex items-center justify-between p-3 bg-slate-950/80 border border-slate-850/60 rounded-xl">
                <div>
                  <span className="text-[11px] font-extrabold text-slate-200 block">Dòng sự kiện tự động</span>
                  <span className="text-[9px] text-slate-500 block">Tự động phát sinh sau mỗi 45 giây</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isAutoStream}
                    onChange={(e) => setIsAutoStream(e.target.checked)}
                    className="sr-only peer cursor-pointer"
                  />
                  <div className="w-9 h-5 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-slate-400 after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500 peer-checked:after:bg-slate-100"></div>
                </label>
              </div>
            </div>
          </div>

          {/* Live System Log Streamer */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-md flex flex-col h-[280px]">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3 shrink-0">
              <h3 className="text-slate-100 font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-indigo-400" />
                Dòng Hoạt Động IoT (Live)
              </h3>
              <div className="flex items-center gap-1">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-sky-500"></span>
                </span>
                <span className="text-[9px] font-mono text-slate-450 font-bold uppercase">Streaming</span>
              </div>
            </div>

            {/* Terminal log logs container */}
            <div 
              ref={logContainerRef}
              className="flex-1 bg-slate-950 border border-slate-850/80 rounded-2xl p-3 font-mono text-[10px] text-slate-400 overflow-y-auto space-y-2 select-text"
            >
              {liveLogs.map((log, i) => {
                let colorClass = "text-slate-400";
                if (log.includes("🔔")) colorClass = "text-amber-400 font-bold";
                else if (log.includes("✅")) colorClass = "text-emerald-400 font-bold";
                else if (log.includes("🚀")) colorClass = "text-indigo-400 font-bold";
                else if (log.includes("⚠️")) colorClass = "text-rose-400 font-semibold animate-pulse";
                else if (log.includes("⏳")) colorClass = "text-sky-400";

                return (
                  <div key={i} className={`leading-relaxed border-l-2 border-slate-800/60 pl-2 py-0.5 ${colorClass}`}>
                    {log}
                  </div>
                );
              })}
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-2 gap-2 text-[9px] font-bold uppercase tracking-wider shrink-0 text-slate-500 pt-1">
              <div className="flex items-center gap-1">
                <Wifi className="w-3 h-3 text-sky-400" /> Ping: <span className="font-mono text-slate-300">24ms</span>
              </div>
              <div className="flex items-center gap-1">
                <Cpu className="w-3 h-3 text-emerald-400" /> RAM: <span className="font-mono text-slate-300">0.82 GB</span>
              </div>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
