import React, { useState, useMemo } from "react";
import { parseCSV } from "../utils/csvParser";
import { productionYieldCSV, farmMonitoringCSV, weatherCSV } from "../data/datasets";
import {
  trainTestSplit,
  MultipleLinearRegression,
  DecisionTree,
  RandomForest,
  evaluateRegression,
  evaluateClassification,
  MinMaxScaler,
  LabelEncoder,
} from "../utils/ml";
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  Cell,
  LineChart,
  Line,
} from "recharts";
import {
  Cpu,
  Settings2,
  TrendingUp,
  Sliders,
  CheckCircle,
  Play,
  History,
  Info,
  ChevronRight,
  TrendingDown,
  Activity,
} from "lucide-react";

interface TrainingRun {
  id: number;
  timestamp: string;
  target: string;
  algorithm: string;
  features: string[];
  metrics: Record<string, number>;
}

export default function ModelSandbox() {
  // Load and parse datasets
  const rawYieldData = useMemo(() => parseCSV(productionYieldCSV), []);
  const rawMonitoringData = useMemo(() => parseCSV(farmMonitoringCSV), []);
  const rawWeatherData = useMemo(() => parseCSV(weatherCSV), []);

  // Targets
  // We can join tables to have more variables.
  // Let's create a joined dataset specifically for ML Sandbox:
  // We'll join productionYieldCSV with weatherCSV on Date & Farm_ID or join FarmMonitoring with Weather to get Soil moisture, Temp, Rainfall, etc.
  // Let's merge:
  // - Yield_Ton, Area_Ha from Farm Monitoring (FM001 to FM100).
  // - We'll create a clean joined array:
  const mlDataset = useMemo(() => {
    const dataset: Record<string, any>[] = [];
    rawMonitoringData.forEach((farm) => {
      // Find matching weather rows
      const weatherRows = rawWeatherData.filter((w) => w.Farm_ID === farm.Farm_ID);
      // Let's map each weather row as an observation of yield
      weatherRows.forEach((w) => {
        // Find matching production yield row if possible, or simulate it
        const yieldRow = rawYieldData.find((y) => y.Farm_ID === farm.Farm_ID && y.Date === w.Date);
        dataset.push({
          Farm_ID: farm.Farm_ID,
          Province: farm.Province,
          Crop: farm.Crop,
          Area_Ha: farm.Area_Ha,
          Soil_Moisture: farm["Soil_Moisture_%"] ?? w["Humidity_%"] ?? 60,
          Temperature: w.Temperature_C ?? farm.Temperature_C ?? 28,
          Humidity: w["Humidity_%"] ?? 75,
          Rainfall: w.Rainfall_mm ?? 50,
          Yield_Ton: yieldRow ? yieldRow.Quantity_Ton : farm.Yield_Ton,
          Profit_Million: yieldRow ? (yieldRow.Profit_VND / 1000000) : (farm.Area_Ha * 45), // Estimate Profit
          Disease_Risk: w.Disease_Risk === "High" ? 2 : w.Disease_Risk === "Medium" ? 1 : 0,
        });
      });
    });
    return dataset;
  }, [rawMonitoringData, rawWeatherData, rawYieldData]);

  // Available targets
  const targets = [
    { id: "Yield_Ton", name: "Sản lượng (Yield_Ton) - Hồi quy", type: "regression" },
    { id: "Profit_Million", name: "Lợi nhuận (Profit_Million_VND) - Hồi quy", type: "regression" },
    { id: "Disease_Risk", name: "Rủi ro dịch bệnh (Disease_Risk) - Phân loại", type: "classification" },
  ];

  // Config States
  const [selectedTarget, setSelectedTarget] = useState("Yield_Ton");
  const [selectedAlgorithm, setSelectedAlgorithm] = useState("random_forest");
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([
    "Area_Ha",
    "Soil_Moisture",
    "Temperature",
    "Humidity",
    "Rainfall",
  ]);
  const [testSplit, setTestSplit] = useState(20); // 20%
  const [epochs, setEpochs] = useState(500);
  const [learningRate, setLearningRate] = useState(0.05);
  const [maxDepth, setMaxDepth] = useState(5);
  const [minSamplesSplit, setMinSamplesSplit] = useState(2);
  const [numEstimators, setNumEstimators] = useState(15);

  // Training & Evaluation States
  const [isTraining, setIsTraining] = useState(false);
  const [trainingLogs, setTrainingLogs] = useState<{ epoch: number; loss: number }[]>([]);
  const [metrics, setMetrics] = useState<Record<string, number> | null>(null);
  const [chartData, setChartData] = useState<{ actual: number; predicted: number; index: number }[]>([]);
  const [featureImportances, setFeatureImportances] = useState<{ name: string; value: number }[]>([]);
  const [history, setHistory] = useState<TrainingRun[]>([]);

  // Active Trained Model instance (saved for live predictor form)
  const [activeTrainedModel, setActiveTrainedModel] = useState<any>(null);
  const [activeScaler, setActiveScaler] = useState<MinMaxScaler | null>(null);
  const [activeLabelEncoder, setActiveLabelEncoder] = useState<LabelEncoder | null>(null);

  // Live Predictor Inputs
  const [predCrop, setPredCrop] = useState("Lúa");
  const [predArea, setPredArea] = useState(3.5);
  const [predMoisture, setPredMoisture] = useState(65);
  const [predTemp, setPredTemp] = useState(28);
  const [predHumidity, setPredHumidity] = useState(80);
  const [predRainfall, setPredRainfall] = useState(45);
  const [predictedValue, setPredictedValue] = useState<string | null>(null);

  // Target Details
  const targetType = useMemo(() => {
    return targets.find((t) => t.id === selectedTarget)?.type ?? "regression";
  }, [selectedTarget]);

  // Features List
  const availableFeatures = ["Area_Ha", "Soil_Moisture", "Temperature", "Humidity", "Rainfall", "Crop_Encoded"];

  const handleFeatureToggle = (feat: string) => {
    if (selectedFeatures.includes(feat)) {
      setSelectedFeatures(selectedFeatures.filter((f) => f !== feat));
    } else {
      setSelectedFeatures([...selectedFeatures, feat]);
    }
  };

  // --- MODEL TRAINING PIPELINE ---

  const handleTrainModel = () => {
    setIsTraining(true);
    setTrainingLogs([]);
    setMetrics(null);
    setChartData([]);
    setFeatureImportances([]);
    setPredictedValue(null);

    // Run training with a short delay to allow loader to animate
    setTimeout(() => {
      try {
        // 1. Prepare and Encode Categoricals in the ML dataset
        const labelEncoder = new LabelEncoder();
        labelEncoder.fit(mlDataset, ["Crop"]);
        
        const preparedData = mlDataset.map((row) => ({
          ...row,
          Crop_Encoded: labelEncoder.transform(row, ["Crop"]).Crop,
        }));

        // 2. Perform Train-Test Split
        const { train, test } = trainTestSplit(preparedData, testSplit / 100, true);

        // 3. Preprocess Features using MinMaxScaler if running Multiple Linear Regression
        const scaler = new MinMaxScaler();
        const featuresToScale = selectedFeatures.filter((f) => f !== "Crop_Encoded");
        scaler.fit(train, featuresToScale);

        // Map inputs to feature vectors
        const mapX = (dataset: Record<string, any>[]) => {
          return dataset.map((row) => {
            const scaledRow = scaler.transform(row, featuresToScale);
            return selectedFeatures.map((f) => {
              if (f === "Crop_Encoded") return row.Crop_Encoded;
              return scaledRow[f] ?? 0;
            });
          });
        };

        const X_train_raw = mapX(train);
        const X_test_raw = mapX(test);
        const y_train = train.map((d) => d[selectedTarget]);
        const y_test = test.map((d) => d[selectedTarget]);

        let y_pred_test: number[] = [];
        let modelInstance: any = null;
        let logs: { epoch: number; loss: number }[] = [];

        // 4. Algorithm Selection & Training
        if (selectedAlgorithm === "linear_regression" && targetType === "regression") {
          const lrModel = new MultipleLinearRegression();
          lrModel.fit(X_train_raw, y_train, epochs, learningRate, (epoch, loss) => {
            logs.push({ epoch, loss });
          });
          y_pred_test = X_test_raw.map((x) => lrModel.predict(x));
          modelInstance = lrModel;
          setTrainingLogs(logs);

          // Standard feature importance based on LR weights
          const totalWeight = lrModel.weights.reduce((a, b) => Math.abs(a) + Math.abs(b), 0);
          setFeatureImportances(
            selectedFeatures.map((f, i) => ({
              name: f,
              value: totalWeight === 0 ? 1 / selectedFeatures.length : Math.abs(lrModel.weights[i]) / totalWeight,
            }))
          );
        } else if (selectedAlgorithm === "decision_tree") {
          const isClassifier = targetType === "classification";
          const dtModel = new DecisionTree(isClassifier, maxDepth, minSamplesSplit);
          dtModel.fit(train, selectedFeatures, selectedTarget);
          y_pred_test = test.map((row) => dtModel.predict(row));
          modelInstance = dtModel;

          // Uniform weights as mock importance for tree
          setFeatureImportances(
            selectedFeatures.map((f) => ({
              name: f,
              value: 1 / selectedFeatures.length,
            }))
          );
        } else if (selectedAlgorithm === "random_forest" || (selectedAlgorithm === "linear_regression" && targetType === "classification")) {
          // If linear_regression is selected with classification, fallback to Random Forest Classifier
          const isClassifier = targetType === "classification";
          const rfModel = new RandomForest(isClassifier, numEstimators, maxDepth, minSamplesSplit);
          rfModel.fit(train, selectedFeatures, selectedTarget);
          y_pred_test = test.map((row) => rfModel.predict(row));
          modelInstance = rfModel;

          setFeatureImportances(
            Object.entries(rfModel.featureImportances).map(([name, value]) => ({
              name,
              value,
            }))
          );
        }

        // --- 5. MODEL EVALUATION ---
        let computedMetrics: Record<string, number> = {};

        if (isRegression(targetType)) {
          const evalResult = evaluateRegression(y_test, y_pred_test);
          computedMetrics = {
            MAE: Number(evalResult.mae.toFixed(4)),
            MSE: Number(evalResult.mse.toFixed(4)),
            RMSE: Number(evalResult.rmse.toFixed(4)),
            R2: Number(evalResult.r2.toFixed(4)),
          };

          // Generate scatter plot points (actual vs predicted)
          setChartData(
            y_test.map((act, idx) => ({
              actual: Number(act.toFixed(2)),
              predicted: Number(y_pred_test[idx].toFixed(2)),
              index: idx,
            }))
          );
        } else {
          const evalResult = evaluateClassification(y_test, y_pred_test);
          computedMetrics = {
            Accuracy: Number(evalResult.accuracy.toFixed(4)),
            Precision: Number(evalResult.precision.toFixed(4)),
            Recall: Number(evalResult.recall.toFixed(4)),
            F1: Number(evalResult.f1.toFixed(4)),
          };
        }

        setMetrics(computedMetrics);
        setActiveTrainedModel(modelInstance);
        setActiveScaler(scaler);
        setActiveLabelEncoder(labelEncoder);

        // Save to History Log
        const algorithmNames: Record<string, string> = {
          linear_regression: "Multiple Linear Regression",
          decision_tree: "Decision Tree (CART)",
          random_forest: "Random Forest Ensemble",
        };
        const run: TrainingRun = {
          id: Date.now(),
          timestamp: new Date().toLocaleTimeString("vi-VN"),
          target: selectedTarget,
          algorithm: algorithmNames[selectedAlgorithm] || selectedAlgorithm,
          features: [...selectedFeatures],
          metrics: computedMetrics,
        };
        setHistory((prev) => [run, ...prev]);

      } catch (error) {
        console.error("Training error:", error);
      } finally {
        setIsTraining(false);
      }
    }, 1200);
  };

  const isRegression = (type: string) => type === "regression";

  // --- LIVE PREDICTOR HANDLER ---

  const handlePredictLive = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTrainedModel) return;

    try {
      // 1. Encode categorical input
      const encodedCrop = activeLabelEncoder ? activeLabelEncoder.transform({ Crop: predCrop }, ["Crop"]).Crop : 0;

      // 2. Scale features
      const featuresToScale = selectedFeatures.filter((f) => f !== "Crop_Encoded");
      const unscaledRow: Record<string, any> = {
        Area_Ha: predArea,
        Soil_Moisture: predMoisture,
        Temperature: predTemp,
        Humidity: predHumidity,
        Rainfall: predRainfall,
        Crop_Encoded: encodedCrop,
      };

      const scaledRow = activeScaler ? activeScaler.transform(unscaledRow, featuresToScale) : {};

      // 3. Assemble final input
      const mergedInput: Record<string, number> = {
        ...scaledRow,
        Crop_Encoded: encodedCrop,
      };

      let finalPred = 0;

      // Apply appropriate inference method depending on algorithm class
      if (activeTrainedModel instanceof MultipleLinearRegression) {
        const featureVector = selectedFeatures.map((f) => {
          if (f === "Crop_Encoded") return encodedCrop;
          return mergedInput[f] ?? 0;
        });
        finalPred = activeTrainedModel.predict(featureVector);
      } else {
        // CART / Random Forest tree-traversal uses direct named properties
        // We construct a row combining scaled features and unscaled depending on if Linear regression scaling was used,
        // but decision trees work best on unscaled or scaled raw structures identically. We provide the unscaled properties
        // since trees split on raw metric thresholds!
        const treeRow = {
          Area_Ha: predArea,
          Soil_Moisture: predMoisture,
          Temperature: predTemp,
          Humidity: predHumidity,
          Rainfall: predRainfall,
          Crop_Encoded: encodedCrop,
        };
        finalPred = activeTrainedModel.predict(treeRow);
      }

      if (targetType === "regression") {
        if (selectedTarget === "Profit_Million") {
          setPredictedValue(`${finalPred.toFixed(2)} Triệu VND`);
        } else {
          setPredictedValue(`${finalPred.toFixed(2)} Tấn (Ton)`);
        }
      } else {
        const labels = ["Low (Thấp / An toàn)", "Medium (Trung bình)", "High (Cao / Cảnh báo)"];
        setPredictedValue(labels[Math.round(finalPred)] || "Không xác định");
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div id="model-sandbox-root" className="grid grid-cols-1 xl:grid-cols-3 gap-6">
      {/* 1. Left Config column */}
      <div id="sandbox-config" className="xl:col-span-1 space-y-6">
        <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-5">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3 mb-1">
            <Settings2 className="w-5 h-5 text-sky-400" />
            <h3 className="text-slate-100 font-bold text-base">Cấu hình mô hình (Training Panel)</h3>
          </div>

          {/* Target Variable */}
          <div className="space-y-1.5">
            <label className="text-slate-400 text-xs font-bold uppercase tracking-wider block">1. Biến mục tiêu (Target)</label>
            <select
              id="select-target-variable"
              value={selectedTarget}
              onChange={(e) => {
                setSelectedTarget(e.target.value);
                setMetrics(null);
                setActiveTrainedModel(null);
              }}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-sm text-slate-200 font-medium focus:outline-none focus:border-sky-500 focus:bg-slate-900/50"
            >
              {targets.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
          </div>

          {/* Features Checklist */}
          <div className="space-y-2">
            <label className="text-slate-400 text-xs font-bold uppercase tracking-wider block">
              2. Đặc trưng dự báo (Features)
            </label>
            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5 max-h-[160px] overflow-y-auto">
              {availableFeatures.map((feat) => (
                <label key={feat} className="flex items-center gap-2.5 text-xs text-slate-400 font-medium cursor-pointer py-0.5 hover:text-slate-200 select-none">
                  <input
                    type="checkbox"
                    checked={selectedFeatures.includes(feat)}
                    onChange={() => handleFeatureToggle(feat)}
                    className="rounded text-sky-500 focus:ring-sky-500 border-slate-800 bg-slate-900 w-4 h-4"
                  />
                  {feat}
                </label>
              ))}
            </div>
          </div>

          {/* Algorithm selection */}
          <div className="space-y-1.5">
            <label className="text-slate-400 text-xs font-bold uppercase tracking-wider block">3. Thuật toán (Algorithm)</label>
            <select
              id="select-ml-algorithm"
              value={selectedAlgorithm}
              onChange={(e) => {
                setSelectedAlgorithm(e.target.value);
                setMetrics(null);
                setActiveTrainedModel(null);
              }}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-sm text-slate-200 font-medium focus:outline-none focus:border-sky-500 focus:bg-slate-900/50"
            >
              <option value="random_forest">Random Forest Ensemble (Mạnh nhất)</option>
              <option value="decision_tree">Decision Tree CART</option>
              {targetType === "regression" && (
                <option value="linear_regression">Multiple Linear Regression (Hồi quy đa biến)</option>
              )}
            </select>
          </div>

          {/* Split Ratio Slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs font-bold text-slate-400 uppercase tracking-wider">
              <span>4. Tỉ lệ Kiểm thử (Test split)</span>
              <span className="text-sky-400 font-mono">{testSplit}%</span>
            </div>
            <input
              type="range"
              min="10"
              max="40"
              step="5"
              value={testSplit}
              onChange={(e) => setTestSplit(Number(e.target.value))}
              className="w-full accent-sky-500 h-1.5 bg-slate-950 rounded-lg cursor-pointer border border-slate-800"
            />
          </div>

          {/* Algorithm Hyperparameters */}
          <div className="border-t border-slate-800 pt-4 space-y-4">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Sliders className="w-4 h-4 text-slate-500" /> Siêu tham số (Hyperparameters)
            </h4>

            {selectedAlgorithm === "linear_regression" && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-500 text-[10px] font-bold block uppercase">Vòng lặp (Epochs)</label>
                  <input
                    type="number"
                    value={epochs}
                    onChange={(e) => setEpochs(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-500 text-[10px] font-bold block uppercase">Tốc độ học (Alpha)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={learningRate}
                    onChange={(e) => setLearningRate(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>
            )}

            {(selectedAlgorithm === "decision_tree" || selectedAlgorithm === "random_forest") && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-500 text-[10px] font-bold block uppercase">Độ sâu tối đa (Depth)</label>
                  <input
                    type="number"
                    min="1"
                    max="15"
                    value={maxDepth}
                    onChange={(e) => setMaxDepth(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-500 text-[10px] font-bold block uppercase">Min Samples Split</label>
                  <input
                    type="number"
                    min="2"
                    value={minSamplesSplit}
                    onChange={(e) => setMinSamplesSplit(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>
            )}

            {selectedAlgorithm === "random_forest" && (
              <div className="space-y-1">
                <label className="text-slate-500 text-[10px] font-bold block uppercase">Số lượng Cây (Estimators)</label>
                <input
                  type="number"
                  min="5"
                  max="50"
                  value={numEstimators}
                  onChange={(e) => setNumEstimators(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-sky-500"
                />
              </div>
            )}
          </div>

          {/* Train Button */}
          <button
            id="btn-train-ml-model"
            disabled={isTraining || selectedFeatures.length === 0}
            onClick={handleTrainModel}
            className="w-full bg-sky-600 hover:bg-sky-500 text-white font-bold py-3 px-4 rounded-xl transition-all duration-200 disabled:opacity-50 disabled:pointer-events-none text-sm flex items-center justify-center gap-2 shadow-lg shadow-sky-950/40 active:scale-95 cursor-pointer"
          >
            {isTraining ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Đang huấn luyện...
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                Huấn luyện mô hình
              </>
            )}
          </button>
        </div>
      </div>

      {/* 2. Middle & Right: Evaluation logs, metrics & predictor */}
      <div id="sandbox-main" className="xl:col-span-2 space-y-6">
        {/* Model Results / Placeholder */}
        {!metrics && !isTraining ? (
          <div className="bg-slate-900 border border-dashed border-slate-800 p-12 text-center rounded-2xl flex flex-col items-center justify-center space-y-3 min-h-[300px]">
            <Cpu className="w-12 h-12 text-slate-600 animate-bounce" />
            <h3 className="text-slate-300 font-bold text-base">Hệ thống học máy sẵn sàng</h3>
            <p className="text-slate-500 text-xs max-w-sm">
              Chọn biến mục tiêu, điều chỉnh thuật toán học máy bên trái và bắt đầu quy trình huấn luyện để xem kết quả đánh giá chi tiết.
            </p>
          </div>
        ) : isTraining ? (
          <div className="bg-slate-900 p-8 rounded-2xl border border-slate-800 text-center flex flex-col items-center justify-center space-y-4 min-h-[300px]">
            <div className="w-12 h-12 border-4 border-sky-500 border-t-transparent rounded-full animate-spin" />
            <div>
              <h3 className="text-slate-100 font-bold text-base">Đang xử lý pipeline dữ liệu nông nghiệp...</h3>
              <p className="text-slate-400 text-xs mt-1">Đồng bộ dữ liệu, mã hóa biến phân loại, thực hiện trích chọn đặc trưng và khớp mô hình</p>
            </div>
            {/* Mock loader bar */}
            <div className="w-64 bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-800">
              <div className="bg-sky-500 h-full rounded-full animate-pulse" style={{ width: "70%" }} />
            </div>
          </div>
        ) : (
          /* Evaluation Display */
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Stats Cards */}
            <div className="md:col-span-3 bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-500 animate-bounce" />
                  <h3 className="text-slate-100 font-bold text-base">Kết quả huấn luyện thành công!</h3>
                </div>
                <span className="text-[10px] bg-sky-950/50 text-sky-400 border border-sky-900/30 px-2.5 py-1 rounded-full font-bold uppercase tracking-wider">
                  {selectedAlgorithm.toUpperCase()}
                </span>
              </div>

              {/* Performance Metrics Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {Object.entries(metrics || {}).map(([key, val]) => (
                  <div key={key} className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-center">
                    <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block mb-1">
                      {key}
                    </span>
                    <span className={`text-xl font-black ${key === "R2" || key === "Accuracy" ? "text-sky-400" : "text-slate-200"} font-mono`}>
                      {val}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Scatter plot of Predictions (Actual vs Predicted) */}
            {isRegression(targetType) && chartData.length > 0 && (
              <div className="md:col-span-2 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-2">
                <h4 className="text-slate-300 font-bold text-xs uppercase tracking-wider mb-2">Đồ thị thực tế vs dự báo (R² Fit)</h4>
                <div className="h-56 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <ScatterChart margin={{ top: 10, right: 10, bottom: 10, left: -10 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis type="number" stroke="#475569" style={{ fontSize: 10, fill: '#94a3b8' }} dataKey="actual" name="Actual" label={{ value: "Thực tế", position: "insideBottom", fill: '#94a3b8', fontSize: 10, offset: -5 }} />
                      <YAxis type="number" stroke="#475569" style={{ fontSize: 10, fill: '#94a3b8' }} dataKey="predicted" name="Predicted" label={{ value: "Dự báo", position: "insideLeft", fill: '#94a3b8', fontSize: 10, angle: -90, offset: 10 }} />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f1f5f9', borderRadius: '12px' }} cursor={{ strokeDasharray: "3 3" }} />
                      <Scatter name="Inference Points" data={chartData} fill="#38bdf8" />
                    </ScatterChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

            {/* Feature Importances bar chart */}
            {featureImportances.length > 0 && (
              <div className={`bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-2 ${isRegression(targetType) ? "md:col-span-1" : "md:col-span-3"}`}>
                <h4 className="text-slate-300 font-bold text-xs uppercase tracking-wider mb-2">Độ quan trọng đặc trưng</h4>
                <div className="h-56 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={featureImportances} layout="vertical" margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis type="number" stroke="#475569" style={{ fontSize: 10, fill: '#94a3b8' }} domain={[0, 1]} />
                      <YAxis dataKey="name" type="category" width={80} stroke="#475569" style={{ fontSize: 9, fill: '#94a3b8' }} />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f1f5f9', borderRadius: '12px' }} />
                      <Bar dataKey="value" fill="#0284c7" radius={[0, 4, 4, 0]}>
                        {featureImportances.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={index === 0 ? "#0369a1" : "#38bdf8"} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

            {/* Numerical LR logs chart if available */}
            {selectedAlgorithm === "linear_regression" && trainingLogs.length > 0 && (
              <div className="md:col-span-3 bg-slate-900 p-5 rounded-2xl border border-slate-800 space-y-2">
                <h4 className="text-slate-300 font-bold text-xs uppercase tracking-wider mb-2">Đường cong hội tụ (Training Loss Convergence)</h4>
                <div className="h-44 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={trainingLogs} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis dataKey="epoch" stroke="#475569" style={{ fontSize: 10, fill: '#94a3b8' }} />
                      <YAxis stroke="#475569" style={{ fontSize: 10, fill: '#94a3b8' }} />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f1f5f9', borderRadius: '12px' }} />
                      <Line type="monotone" dataKey="loss" stroke="#f43f5e" strokeWidth={2} dot={false} name="Loss (MSE)" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}
          </div>
        )}

        {/* 3. Interactive Live Predictor Form (using active model) */}
        {activeTrainedModel && (
          <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3 mb-2">
              <Activity className="w-5 h-5 text-sky-400" />
              <div>
                <h3 className="text-slate-100 font-bold text-base">Inference Sandbox (Bộ dự báo thực tế)</h3>
                <p className="text-slate-400 text-xs mt-0.5">Mô hình đã được khớp thành công. Hãy thay đổi đầu vào để nhận dự báo tức thì!</p>
              </div>
            </div>

            <form onSubmit={handlePredictLive} className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {/* Crop type */}
              <div className="space-y-1">
                <label className="text-slate-500 text-[10px] font-bold uppercase block">Loại cây trồng (Crop)</label>
                <select
                  value={predCrop}
                  onChange={(e) => setPredCrop(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 font-semibold focus:outline-none focus:border-sky-500"
                >
                  <option value="Lúa">Lúa</option>
                  <option value="Cà phê">Cà phê</option>
                  <option value="Sầu riêng">Sầu riêng</option>
                  <option value="Xoài">Xoài</option>
                  <option value="Thanh long">Thanh long</option>
                </select>
              </div>

              {/* Area */}
              <div className="space-y-1">
                <label className="text-slate-500 text-[10px] font-bold uppercase block">Diện tích (Area_Ha)</label>
                <input
                  type="number"
                  step="0.1"
                  value={predArea}
                  onChange={(e) => setPredArea(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 font-semibold focus:outline-none focus:border-sky-500"
                />
              </div>

              {/* Moisture */}
              <div className="space-y-1">
                <label className="text-slate-500 text-[10px] font-bold uppercase block">Độ ẩm đất (Soil Moisture %)</label>
                <input
                  type="number"
                  value={predMoisture}
                  onChange={(e) => setPredMoisture(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 font-semibold focus:outline-none focus:border-sky-500"
                />
              </div>

              {/* Temp */}
              <div className="space-y-1">
                <label className="text-slate-500 text-[10px] font-bold uppercase block">Nhiệt độ (Temperature C)</label>
                <input
                  type="number"
                  value={predTemp}
                  onChange={(e) => setPredTemp(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 font-semibold focus:outline-none focus:border-sky-500"
                />
              </div>

              {/* Humidity */}
              <div className="space-y-1">
                <label className="text-slate-500 text-[10px] font-bold uppercase block">Độ ẩm không khí (Humidity %)</label>
                <input
                  type="number"
                  value={predHumidity}
                  onChange={(e) => setPredHumidity(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 font-semibold focus:outline-none focus:border-sky-500"
                />
              </div>

              {/* Rainfall */}
              <div className="space-y-1">
                <label className="text-slate-500 text-[10px] font-bold uppercase block">Lượng mưa (Rainfall mm)</label>
                <input
                  type="number"
                  value={predRainfall}
                  onChange={(e) => setPredRainfall(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 font-semibold focus:outline-none focus:border-sky-500"
                />
              </div>

              {/* Predict button */}
              <div className="sm:col-span-2 xl:col-span-3 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-sky-950/20 p-4 rounded-2xl border border-sky-900/30">
                <button
                  type="submit"
                  id="btn-run-sandbox-predictor"
                  className="bg-sky-600 hover:bg-sky-500 text-white font-bold py-2.5 px-6 rounded-xl transition-all text-xs flex items-center gap-1.5 shrink-0 self-start md:self-auto cursor-pointer"
                >
                  <Cpu className="w-4 h-4" /> Khởi chạy dự báo
                </button>

                {predictedValue && (
                  <div className="space-y-0.5 text-right md:text-left">
                    <span className="text-slate-500 text-[9px] uppercase font-bold tracking-wider block">Giá trị dự báo mục tiêu</span>
                    <span className="text-lg font-black text-sky-400 font-mono bg-slate-950/80 border border-slate-800 px-3 py-1.5 rounded-xl inline-block">{predictedValue}</span>
                  </div>
                )}
              </div>
            </form>
          </div>
        )}

        {/* 4. History logs table */}
        {history.length > 0 && (
          <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-4">
            <h3 className="text-slate-100 font-bold text-base flex items-center gap-2">
              <History className="w-5 h-5 text-sky-400" /> Lịch sử huấn luyện (Runs Comparing)
            </h3>

            <div className="overflow-x-auto border border-slate-800 rounded-xl bg-slate-950">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-900/80 text-slate-300 border-b border-slate-800">
                    <th className="px-4 py-2.5 font-bold uppercase">Thời gian</th>
                    <th className="px-4 py-2.5 font-bold uppercase">Biến mục tiêu</th>
                    <th className="px-4 py-2.5 font-bold uppercase">Thuật toán</th>
                    <th className="px-4 py-2.5 font-bold uppercase">Đặc trưng</th>
                    <th className="px-4 py-2.5 font-bold uppercase text-right">Chỉ số đánh giá</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40 text-slate-300">
                  {history.map((run) => (
                    <tr key={run.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="px-4 py-3 font-semibold font-mono text-slate-500">{run.timestamp}</td>
                      <td className="px-4 py-3 font-bold text-slate-200">{run.target}</td>
                      <td className="px-4 py-3 font-semibold text-sky-400">{run.algorithm}</td>
                      <td className="px-4 py-3 max-w-[150px] truncate text-slate-400 font-mono" title={run.features.join(", ")}>
                        {run.features.join(", ")}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="flex gap-2 justify-end">
                          {Object.entries(run.metrics).map(([name, val]) => (
                            <span key={name} className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px] font-bold font-mono text-slate-300">
                              {name}: {val}
                            </span>
                          ))}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
