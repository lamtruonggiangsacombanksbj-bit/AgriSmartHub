import React, { useState, useMemo } from "react";
import { 
  Wheat, 
  Layers, 
  TrendingUp, 
  Calendar, 
  CheckCircle2, 
  HelpCircle,
  Plus,
  Scale,
  Sparkles
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from "recharts";

interface HarvestRecord {
  id: string;
  cropName: string;
  variety: string;
  location: string;
  harvestDate: string;
  quantityTons: number;
  quality: "A" | "B" | "C";
  status: "stored" | "exported" | "processing";
}

const INITIAL_HARVEST_RECORDS: HarvestRecord[] = [
  { id: "HRV-301", cropName: "Sầu riêng", variety: "Ri6", location: "Bến Tre", harvestDate: "2026-06-28", quantityTons: 12.5, quality: "A", status: "exported" },
  { id: "HRV-302", cropName: "Sầu riêng", variety: "Dona", location: "Đồng Nai", harvestDate: "2026-06-25", quantityTons: 8.2, quality: "A", status: "stored" },
  { id: "HRV-303", cropName: "Cà phê", variety: "Robusta", location: "Lâm Đồng", harvestDate: "2026-06-20", quantityTons: 15.0, quality: "B", status: "processing" },
  { id: "HRV-304", cropName: "Lúa mùa", variety: "ST25", location: "Sóc Trăng", harvestDate: "2026-06-18", quantityTons: 45.0, quality: "A", status: "exported" },
  { id: "HRV-305", cropName: "Thanh long", variety: "Ruột đỏ", location: "Bình Thuận", harvestDate: "2026-06-15", quantityTons: 6.4, quality: "C", status: "stored" },
];

export default function CropYieldScreen() {
  const [records, setRecords] = useState<HarvestRecord[]>(() => {
    try {
      const cached = localStorage.getItem("farming_harvest_records");
      return cached ? JSON.parse(cached) : INITIAL_HARVEST_RECORDS;
    } catch (e) {
      return INITIAL_HARVEST_RECORDS;
    }
  });

  React.useEffect(() => {
    try {
      localStorage.setItem("farming_harvest_records", JSON.stringify(records));
    } catch (e) {
      console.error(e);
    }
  }, [records]);

  // States for Yield Estimator tool
  const [soilNitrogen, setSoilNitrogen] = useState(65);
  const [irrigationCycle, setIrrigationCycle] = useState(12); // times per month
  const [sunlightHours, setSunlightHours] = useState(7.5); // hrs/day
  const [tempCelsius, setTempCelsius] = useState(28);

  const estimatedYieldResult = useMemo(() => {
    // Basic predictive algorithm based on inputs
    const baseYield = 12.0; // tons per hectare base
    const nFactor = (soilNitrogen / 60) * 0.35;
    const waterFactor = (irrigationCycle / 10) * 0.25;
    const sunFactor = (sunlightHours / 7.0) * 0.25;
    const tempDev = Math.abs(tempCelsius - 27.5);
    const tempFactor = (1 - tempDev / 30) * 0.15;

    const finalYield = baseYield * (0.5 + nFactor + waterFactor + sunFactor + tempFactor);
    return Math.min(Math.max(finalYield, 4.0), 22.0); // clamped
  }, [soilNitrogen, irrigationCycle, sunlightHours, tempCelsius]);

  // Bar Chart representing current warehouse inventory levels (in Tons)
  const inventoryChartData = [
    { name: "Sầu riêng Ri6", stock: 15.4, exported: 42.1, processing: 5.0 },
    { name: "Sầu riêng Dona", stock: 12.0, exported: 28.5, processing: 2.0 },
    { name: "Cà phê Robusta", stock: 25.8, exported: 88.0, processing: 45.0 },
    { name: "Lúa ST25", stock: 68.0, exported: 120.0, processing: 10.0 },
    { name: "Xoài Cát Hòa Lộc", stock: 8.5, exported: 18.2, processing: 4.5 },
  ];

  // Radar chart representing Quality Profile of agricultural products this season
  const radarData = [
    { subject: "Màu sắc tự nhiên", A: 95, fullMark: 100 },
    { subject: "Trọng lượng trung bình", A: 88, fullMark: 100 },
    { subject: "Độ ngọt (Brix)", A: 92, fullMark: 100 },
    { subject: "Thời gian bảo quản", A: 85, fullMark: 100 },
    { subject: "Độ đồng đều lô", A: 90, fullMark: 100 },
    { subject: "Không tì vết vỏ", A: 82, fullMark: 100 },
  ];

  return (
    <div className="space-y-6 text-slate-200">
      
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900/40 p-5 rounded-2xl border border-slate-800/60 backdrop-blur-md">
        <div>
          <h2 className="text-xl font-black text-slate-100 flex items-center gap-2.5 uppercase tracking-tight">
            <span className="p-2 bg-amber-500/10 text-amber-400 rounded-xl border border-amber-500/20">
              <Wheat className="w-5 h-5" />
            </span>
            Nông sản & Sản lượng thu hoạch
          </h2>
          <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
            Hệ thống đo lường trọng lượng, theo dõi lượng hàng tồn kho nông sản, lịch sử thu hoạch và giả lập sản lượng ước tính thông qua mạng nơ-ron cục bộ.
          </p>
        </div>
        <span className="px-3 py-1.5 bg-amber-500/10 border border-amber-500/30 text-[10px] font-black uppercase text-amber-400 rounded-xl block shrink-0">
          Tổng vụ hè thu: 216.5 tấn
        </span>
      </div>

      {/* Grid of Top Summary Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 flex items-center gap-4">
          <div className="p-3 bg-sky-500/10 border border-sky-500/25 text-sky-400 rounded-xl shrink-0">
            <Scale className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Tổng nông sản lưu kho</span>
            <strong className="text-lg text-slate-100 font-mono font-black">129.7 Tấn</strong>
            <span className="text-[9px] text-emerald-400 block font-medium mt-0.5">Sẵn sàng vận chuyển</span>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 flex items-center gap-4">
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 rounded-xl shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Tỷ lệ đạt chuẩn loại A (Brix)</span>
            <strong className="text-lg text-slate-100 font-mono font-black">88.5%</strong>
            <span className="text-[9px] text-indigo-400 block font-medium mt-0.5">Cao hơn 3.2% so với vụ trước</span>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 flex items-center gap-4">
          <div className="p-3 bg-indigo-500/10 border border-indigo-500/25 text-indigo-400 rounded-xl shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Năng suất bình quân</span>
            <strong className="text-lg text-slate-100 font-mono font-black">11.8 Tấn / Ha</strong>
            <span className="text-[9px] text-amber-500 block font-medium mt-0.5">Dẫn đầu khu vực Nam Bộ</span>
          </div>
        </div>
      </div>

      {/* Inventory Levels & radar Quality profiles */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        
        {/* Main inventory Chart */}
        <div className="lg:col-span-3 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl">
          <div className="border-b border-slate-800/60 pb-3 mb-4 flex items-center justify-between">
            <div>
              <h3 className="text-xs font-black text-slate-100 uppercase tracking-wider">Cơ cấu Nông sản tồn kho & Vận xuất</h3>
              <p className="text-[10px] text-slate-400">Đơn vị: Tấn (Metric Tons)</p>
            </div>
            <div className="flex gap-2 text-[9px] text-slate-400">
              <span className="flex items-center gap-1"><span className="w-2 h-2 bg-indigo-500 rounded" /> Lưu kho</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 bg-emerald-500 rounded" /> Đã xuất</span>
            </div>
          </div>

          <div className="h-64 w-full text-slate-900 text-[10px] font-bold">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={inventoryChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" stroke="#64748b" tick={{ fill: '#94a3b8' }} />
                <YAxis stroke="#64748b" tick={{ fill: '#94a3b8' }} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155' }} labelStyle={{ color: '#fff' }} />
                <Legend />
                <Bar dataKey="stock" name="Tồn kho" fill="#6366f1" radius={[4, 4, 0, 0]} />
                <Bar dataKey="exported" name="Xuất khẩu" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Quality Radar Profile */}
        <div className="lg:col-span-2 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div className="border-b border-slate-800/60 pb-3 mb-4">
            <h3 className="text-xs font-black text-slate-100 uppercase tracking-wider">Hồ sơ Chất lượng Sầu riêng Ri6 (Nông sản Tiêu biểu)</h3>
            <p className="text-[10px] text-slate-400 mt-0.5">Kiểm định bởi hệ thống AI quang phổ & cảm biến mùi vị</p>
          </div>

          <div className="flex-1 flex items-center justify-center h-48 text-slate-900 text-[10px] font-bold">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="70%" data={radarData}>
                <PolarGrid stroke="#334155" />
                <PolarAngleAxis dataKey="subject" stroke="#64748b" tick={{ fill: '#94a3b8', fontSize: 8 }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#334155" tick={{ fill: '#64748b' }} />
                <Radar name="Chỉ số đạt chuẩn" dataKey="A" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.25} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155' }} />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          <div className="text-center text-[9.5px] text-slate-400 bg-slate-950/40 p-2 border border-slate-900 rounded-xl mt-3">
            🎯 Lô đạt chuẩn xuất khẩu Châu Âu đạt điểm đánh giá chung <strong className="text-amber-400">91.2 / 100</strong>
          </div>
        </div>

      </div>

      {/* Yield Simulator using Soil chemistry + Weather inputs */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        
        {/* Yield Predictive Simulator Form */}
        <div className="lg:col-span-2 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800/60 pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400 animate-pulse" />
              <h3 className="text-xs font-black text-slate-100 uppercase tracking-wider">Ước lượng năng suất trồng</h3>
            </div>
            <span className="text-[8px] bg-slate-950 border border-slate-800 px-1.5 py-0.5 rounded text-indigo-400 font-mono">Neural Model</span>
          </div>

          <div className="space-y-4">
            {/* Input 1 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-400">Nồng độ Nitơ trong đất (ppm):</span>
                <span className="text-sky-400 font-mono font-black">{soilNitrogen} ppm</span>
              </div>
              <input
                type="range"
                min="30"
                max="120"
                value={soilNitrogen}
                onChange={(e) => setSoilNitrogen(Number(e.target.value))}
                className="w-full h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-sky-400"
              />
            </div>

            {/* Input 2 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-400">Chu kỳ tưới tiêu (lần / tháng):</span>
                <span className="text-indigo-400 font-mono font-black">{irrigationCycle} lần</span>
              </div>
              <input
                type="range"
                min="4"
                max="24"
                value={irrigationCycle}
                onChange={(e) => setIrrigationCycle(Number(e.target.value))}
                className="w-full h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-indigo-400"
              />
            </div>

            {/* Input 3 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-400">Số giờ nắng trung bình (giờ / ngày):</span>
                <span className="text-amber-400 font-mono font-black">{sunlightHours.toFixed(1)} giờ</span>
              </div>
              <input
                type="range"
                min="4.0"
                max="12.0"
                step="0.5"
                value={sunlightHours}
                onChange={(e) => setSunlightHours(Number(e.target.value))}
                className="w-full h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>

            {/* Input 4 */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-400">Nhiệt độ rễ cây (°C):</span>
                <span className="text-rose-400 font-mono font-black">{tempCelsius}°C</span>
              </div>
              <input
                type="range"
                min="18"
                max="38"
                value={tempCelsius}
                onChange={(e) => setTempCelsius(Number(e.target.value))}
                className="w-full h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-rose-400"
              />
            </div>

          </div>

          <div className="bg-slate-950 border border-slate-900 rounded-xl p-3.5 text-center mt-3">
            <span className="text-[10px] font-bold text-slate-500 uppercase">Năng suất Ước tính Dự phóng</span>
            <div className="text-2xl font-black font-mono text-emerald-400 mt-1">
              {estimatedYieldResult.toFixed(2)} <span className="text-xs">Tấn / Hécta</span>
            </div>
            <p className="text-[8.5px] text-slate-500 mt-1 leading-relaxed">
              * Dự toán được tính dựa trên mô hình thuật toán tối ưu sinh trưởng vùng trồng sầu riêng & cây có múi.
            </p>
          </div>

        </div>

        {/* Harvest Log List */}
        <div className="lg:col-span-3 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800/60 pb-3 mb-4">
              <h3 className="text-xs font-black text-slate-100 uppercase tracking-wider">Lịch trình Thu hoạch & Giao dịch kho bãi</h3>
              <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded text-[9px] font-mono">Real-time Feed</span>
            </div>

            <div className="space-y-3 max-h-[280px] overflow-y-auto custom-scrollbar pr-1">
              {records.map((r) => (
                <div key={r.id} className="p-3 bg-slate-950/80 border border-slate-900 rounded-xl flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-slate-900 border border-slate-800 text-sky-400 rounded-lg shrink-0">
                      <Wheat className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <strong className="text-slate-200 text-[11px] font-bold">{r.cropName} ({r.variety})</strong>
                        <span className={`px-1.5 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${
                          r.quality === "A" ? "bg-emerald-500/10 text-emerald-400" : r.quality === "B" ? "bg-indigo-500/10 text-indigo-400" : "bg-amber-500/10 text-amber-400"
                        }`}>
                          Hạng {r.quality}
                        </span>
                      </div>
                      <p className="text-[9px] text-slate-500 mt-0.5">Vùng trồng: {r.location} • Ngày: {r.harvestDate}</p>
                    </div>
                  </div>

                  <div className="text-right space-y-1">
                    <span className="text-[11px] font-black text-slate-200 font-mono block">{r.quantityTons} Tấn</span>
                    <span className={`inline-block px-1.5 py-0.5 rounded text-[8.5px] font-black uppercase tracking-wider ${
                      r.status === "exported" ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : r.status === "stored" ? "bg-sky-500/10 text-sky-400 border border-sky-500/20" : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                    }`}>
                      {r.status === "exported" ? "Đã Xuất khẩu" : r.status === "stored" ? "Lưu kho" : "Chế biến"}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-2.5 pt-4 border-t border-slate-800/40 mt-4">
            <button 
              onClick={() => {
                const newRecord: HarvestRecord = {
                  id: `HRV-${Math.floor(100 + Math.random() * 900)}`,
                  cropName: "Sầu riêng",
                  variety: "Ri6",
                  location: "Tiền Giang",
                  harvestDate: new Date().toISOString().split('T')[0],
                  quantityTons: 6.5,
                  quality: "A",
                  status: "stored"
                };
                setRecords([newRecord, ...records]);
              }}
              className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-500 text-slate-100 text-[10px] font-black uppercase tracking-wider rounded-xl transition-all cursor-pointer shadow text-center"
            >
              Ghi nhận lô thu hoạch mới
            </button>
            <button className="py-2 px-3 bg-slate-950 hover:bg-slate-900 border border-slate-850 text-slate-400 hover:text-slate-300 text-[10px] font-black uppercase rounded-xl transition-all">
              Xuất PDF / Excel
            </button>
          </div>
        </div>

      </div>

    </div>
  );
}
