import React, { useState } from "react";
import {
  Calendar,
  ChevronLeft,
  ChevronRight,
  Info,
  Clock,
  MapPin,
  CheckCircle,
  Plus,
} from "lucide-react";

interface CalendarEvent {
  day: number;
  title: string;
  crop: string;
  farmer: string;
  shift: "Ca Sáng" | "Ca Chiều" | "Ca Tối";
  type: "phun_thuoc" | "bon_phan" | "tuoi_nuoc" | "thu_hoach" | "kiem_tra_dat";
  color: string; // Tailwind hex or class-based
}

const INITIAL_EVENTS: CalendarEvent[] = [
  { day: 1, title: "Đo độ ẩm & tưới tiêu sầu riêng", crop: "Sầu riêng Ri6", farmer: "Trần Văn Hùng", shift: "Ca Sáng", type: "tuoi_nuoc", color: "bg-blue-400" },
  { day: 1, title: "Bón phân đợt 2 lúa vụ hè thu", crop: "Lúa mùa cao sản", farmer: "Nguyễn Thị Út", shift: "Ca Chiều", type: "bon_phan", color: "bg-amber-400" },
  { day: 2, title: "Kiểm tra độ pH thổ nhưỡng đất", crop: "Cà phê Robusta", farmer: "Phạm Đức Minh", shift: "Ca Sáng", type: "kiem_tra_dat", color: "bg-emerald-400" },
  { day: 3, title: "Phun chế phẩm sinh học trị rầy", crop: "Xoài Cát", farmer: "Lê Văn Tám", shift: "Ca Chiều", type: "phun_thuoc", color: "bg-purple-400" },
  { day: 4, title: "Thu hoạch sầu riêng xuất khẩu", crop: "Sầu riêng Dona", farmer: "Vương Đình Trung", shift: "Ca Sáng", type: "thu_hoach", color: "bg-orange-400" },
  { day: 4, title: "Tưới phun sương định kỳ thông minh", crop: "Thanh long", farmer: "Lê Hoàng Anh", shift: "Ca Chiều", type: "tuoi_nuoc", color: "bg-blue-400" },
  { day: 5, title: "Bón phân vi lượng rễ sầu riêng", crop: "Sầu riêng Ri6", farmer: "Trần Văn Hùng", shift: "Ca Chiều", type: "bon_phan", color: "bg-amber-400" },
  { day: 6, title: "Thu hoạch bưởi da xanh đợt cuối", crop: "Bưởi da xanh", farmer: "Phạm Quốc Tuấn", shift: "Ca Sáng", type: "thu_hoach", color: "bg-orange-400" },
  { day: 8, title: "Kiểm tra sâu đục thân lúa", crop: "Lúa cao sản", farmer: "Bùi Thị Lan", shift: "Ca Sáng", type: "kiem_tra_dat", color: "bg-emerald-400" },
  { day: 9, title: "Bơm xả úng chống úng nước lúa", crop: "Lúa", farmer: "Đỗ Đăng Khoa", shift: "Ca Tối", type: "tuoi_nuoc", color: "bg-blue-400" },
  { day: 10, title: "Đo nồng độ NPK sầu riêng bằng IoT", crop: "Sầu riêng Ri6", farmer: "Trần Văn Hùng", shift: "Ca Sáng", type: "kiem_tra_dat", color: "bg-emerald-400" },
  { day: 11, title: "Dọn cỏ vệ sinh gốc cà phê", crop: "Cà phê", farmer: "Phạm Đức Minh", shift: "Ca Chiều", type: "bon_phan", color: "bg-amber-400" },
  { day: 12, title: "Tưới nước định lượng qua app di động", crop: "Sầu riêng", farmer: "Đặng Thị Thanh Vy", shift: "Ca Sáng", type: "tuoi_nuoc", color: "bg-blue-400" },
  { day: 13, title: "Thu hoạch cà phê quả chín đỏ", crop: "Cà phê Robusta", farmer: "Phạm Đức Minh", shift: "Ca Sáng", type: "thu_hoach", color: "bg-orange-400" },
];

export default function ShiftCalendarScreen() {
  const [currentYear] = useState(2026);
  const [currentMonth] = useState(6); // June
  const [selectedDay, setSelectedDay] = useState<number | null>(4);
  const [events, setEvents] = useState<CalendarEvent[]>(() => {
    try {
      const cached = localStorage.getItem("agrismart_calendar_events");
      return cached ? JSON.parse(cached) : INITIAL_EVENTS;
    } catch (e) {
      return INITIAL_EVENTS;
    }
  });

  React.useEffect(() => {
    try {
      localStorage.setItem("agrismart_calendar_events", JSON.stringify(events));
    } catch (e) {
      console.error("Failed to save calendar events:", e);
    }
  }, [events]);

  // Calendar parameters for June 2026:
  // June 1, 2026 is a Monday (1)
  // Number of days in June: 30
  const daysInMonth = 30;
  const startDayOffset = 0; // Starts exactly on Monday in June 2026! Perfect!

  const weekDays = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"];

  const handleAddEvent = () => {
    if (!selectedDay) return;
    const titles = ["Bón phân rễ cây", "Phun chế phẩm vi sinh hữu cơ", "Thu hoạch sầu riêng vỏ sẫm", "Đo nhiệt độ đất"];
    const cropsList = ["Sầu riêng Ri6", "Cà phê Arabica", "Thanh long", "Lúa nếp thơm"];
    const farmersList = ["Trần Văn Hùng", "Phạm Đức Minh", "Lê Hoàng Anh", "Nguyễn Thị Mai"];
    const typesList: CalendarEvent["type"][] = ["bon_phan", "phun_thuoc", "thu_hoach", "kiem_tra_dat"];
    const colorsList = ["bg-amber-400", "bg-purple-400", "bg-orange-400", "bg-emerald-400"];
    
    const idx = Math.floor(Math.random() * titles.length);

    const newEvent: CalendarEvent = {
      day: selectedDay,
      title: titles[idx],
      crop: cropsList[idx],
      farmer: farmersList[idx],
      shift: "Ca Sáng",
      type: typesList[idx],
      color: colorsList[idx],
    };

    setEvents([...events, newEvent]);
  };

  const selectedDayEvents = events.filter((e) => e.day === selectedDay);

  return (
    <div id="shift-calendar-root" className="space-y-6">
      {/* 1. Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-sky-400 text-[10px] font-black uppercase tracking-widest block">Lịch trình mùa vụ</span>
          <h2 className="text-slate-100 font-black text-2xl tracking-tight">Kế hoạch sản xuất & Ca canh tác</h2>
          <p className="text-slate-400 text-xs mt-0.5">Sắp xếp ngày thu hoạch, lịch tưới nước thông minh và kiểm định hữu cơ của các vùng liên kết</p>
        </div>
      </div>

      {/* 2. Calendar structure layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Replicating the gorgeous June 2026 calendar block */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <h3 className="text-slate-100 font-extrabold text-base flex items-center gap-2">
                <Calendar className="w-5 h-5 text-indigo-400" />
                Lịch mùa vụ thông minh
              </h3>
              <p className="text-slate-500 text-xs font-semibold">
                {events.length} ca chăm sóc • Vùng liên kết Nam Bộ
              </p>
            </div>

            {/* Navigation controls matching layout */}
            <div className="flex items-center gap-3">
              <button className="p-2 bg-slate-950 border border-slate-850 hover:bg-slate-800 rounded-xl text-slate-400 hover:text-slate-200 transition-colors cursor-pointer">
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="text-slate-200 font-black text-xs uppercase tracking-wider">
                Tháng {currentMonth} {currentYear}
              </span>
              <button className="p-2 bg-slate-950 border border-slate-850 hover:bg-slate-800 rounded-xl text-slate-400 hover:text-slate-200 transition-colors cursor-pointer">
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Weekday headers */}
          <div className="grid grid-cols-7 text-center border-b border-slate-850 pb-3">
            {weekDays.map((d, i) => (
              <span
                key={d}
                className={`text-[10px] font-black tracking-widest uppercase ${
                  i === 6 ? "text-rose-400" : "text-slate-500"
                }`}
              >
                {d}
              </span>
            ))}
          </div>

          {/* Calendar grid */}
          <div className="grid grid-cols-7 gap-2.5">
            {/* June 2026 starts on Monday, so 0 offset */}
            {Array.from({ length: daysInMonth }).map((_, idx) => {
              const dayNum = idx + 1;
              const isSelected = selectedDay === dayNum;
              const dayEvents = events.filter((e) => e.day === dayNum);

              return (
                <div
                  key={dayNum}
                  onClick={() => setSelectedDay(dayNum)}
                  className={`min-h-[75px] p-2.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                    isSelected
                      ? "bg-indigo-950/40 border-indigo-500/70 shadow-lg shadow-indigo-950/30"
                      : "bg-slate-950/40 border-slate-850/60 hover:border-slate-800 hover:bg-slate-950"
                  }`}
                >
                  <span
                    className={`font-mono text-xs font-black ${
                      isSelected ? "text-indigo-400" : "text-slate-400"
                    }`}
                  >
                    {dayNum}
                  </span>

                  {/* Dot events below numbers replicating screenshot perfectly */}
                  <div className="flex flex-wrap gap-1 mt-1">
                    {dayEvents.map((evt, i) => (
                      <span
                        key={i}
                        className={`w-1.5 h-1.5 rounded-full ${evt.color} inline-block`}
                        title={evt.title}
                      />
                    ))}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Legend section */}
          <div className="border-t border-slate-850 pt-4 flex flex-wrap gap-4 text-[10px] font-bold text-slate-500 uppercase tracking-wider justify-center">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-orange-400 inline-block" /> Thu hoạch
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-blue-400 inline-block" /> Tưới tiêu
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-400 inline-block" /> Bón phân
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-purple-400 inline-block" /> Phun thuốc
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block" /> Đo đạc đất
            </span>
          </div>

        </div>

        {/* Right: Selected Day Events detail column */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-extrabold text-slate-100 text-sm">
                  Chi tiết Ngày {selectedDay} Tháng 6
                </h4>
                <p className="text-slate-500 text-xs">
                  {selectedDayEvents.length} ca trực đồng ruộng
                </p>
              </div>

              <button
                disabled={!selectedDay}
                onClick={handleAddEvent}
                className="p-1.5 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border border-indigo-500/20 rounded-xl transition-all cursor-pointer disabled:opacity-50"
                title="Giao ca trực mới cho nông hộ"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <hr className="border-slate-850" />

            <div className="space-y-3.5 max-h-[350px] overflow-y-auto pr-1">
              {selectedDayEvents.length > 0 ? (
                selectedDayEvents.map((e, idx) => (
                  <div
                    key={idx}
                    className="p-4 bg-slate-950 rounded-2xl border border-slate-850 flex flex-col justify-between gap-3 group hover:border-slate-800 transition-colors"
                  >
                    <div className="space-y-1">
                      <span className="text-[9px] text-slate-500 font-extrabold uppercase tracking-widest block">
                        Chuẩn chăm sóc sinh học
                      </span>
                      <h5 className="font-extrabold text-xs text-slate-200 tracking-wide">
                        {e.title}
                      </h5>
                    </div>

                    <div className="space-y-1 text-[11px] text-slate-400 font-medium">
                      <div className="flex justify-between">
                        <span>Chủ hộ phụ trách:</span>
                        <strong className="text-slate-300">{e.farmer}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>Cây trồng:</span>
                        <strong className="text-slate-300">{e.crop}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>Khung ca trực:</span>
                        <strong className="text-slate-300">{e.shift}</strong>
                      </div>
                    </div>

                    <div className="border-t border-slate-900/60 pt-2.5 flex items-center justify-between text-[10px] font-bold">
                      <span className="text-indigo-400 flex items-center gap-1 font-mono">
                        <Clock className="w-3.5 h-3.5 text-slate-500" />
                        07:30 - 11:30
                      </span>

                      <span className="text-emerald-400 flex items-center gap-1 font-semibold">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                        Đã giao việc
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-12 text-slate-500 flex flex-col items-center gap-2">
                  <Info className="w-5 h-5 text-slate-600" />
                  <p className="text-xs leading-normal max-w-[200px] mx-auto">
                    Không có ca làm việc nào được đặt lịch cho Ngày {selectedDay}.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
