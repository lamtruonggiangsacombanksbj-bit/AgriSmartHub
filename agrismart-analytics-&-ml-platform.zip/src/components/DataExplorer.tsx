import React, { useState, useMemo } from "react";
import { parseCSV, getDescriptiveStats } from "../utils/csvParser";
import {
  traceabilityCSV,
  esgCSV,
  farmerCSV,
  farmMonitoringCSV,
  ordersCSV,
  monthlyAnalyticsCSV,
  productionYieldCSV,
  weatherCSV,
} from "../data/datasets";
import { Search, Database, FileSpreadsheet, Eye, BarChart4, ArrowUpDown } from "lucide-react";

export default function DataExplorer() {
  const datasets = useMemo(() => [
    { id: "farmers", name: "1. Cơ sở dữ liệu Nông hộ (Farmers)", raw: farmerCSV, icon: Database },
    { id: "farms", name: "2. Giám sát Trang trại (Farm Monitoring)", raw: farmMonitoringCSV, icon: FileSpreadsheet },
    { id: "yield", name: "3. Sản lượng & Rủi ro (Production Yield)", raw: productionYieldCSV, icon: Eye },
    { id: "weather", name: "4. Thời tiết & Môi trường (Weather)", raw: weatherCSV, icon: Database },
    { id: "orders", name: "5. Đơn hàng & Logistics (Orders)", raw: ordersCSV, icon: FileSpreadsheet },
    { id: "esg", name: "6. Chỉ số Bền vững (ESG & Sustainability)", raw: esgCSV, icon: Eye },
    { id: "traceability", name: "7. Truy xuất & Blockchain (Traceability)", raw: traceabilityCSV, icon: Database },
    { id: "monthly", name: "8. Báo cáo phân tích Tháng (Monthly)", raw: monthlyAnalyticsCSV, icon: BarChart4 },
  ], []);

  const [activeTab, setActiveTab] = useState("farmers");
  const [search, setSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: "asc" | "desc" } | null>(null);

  const parsedData = useMemo(() => {
    const selected = datasets.find((d) => d.id === activeTab);
    return selected ? parseCSV(selected.raw) : [];
  }, [activeTab, datasets]);

  const headers = useMemo(() => {
    if (parsedData.length === 0) return [];
    return Object.keys(parsedData[0]);
  }, [parsedData]);

  // Reset pagination on tab change
  const handleTabChange = (id: string) => {
    setActiveTab(id);
    setSearch("");
    setCurrentPage(1);
    setSortConfig(null);
  };

  const sortedData = useMemo(() => {
    let sortable = [...parsedData];
    if (sortConfig !== null) {
      sortable.sort((a, b) => {
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];
        if (aValue === null || aValue === undefined) return 1;
        if (bValue === null || bValue === undefined) return -1;
        
        if (typeof aValue === "number" && typeof bValue === "number") {
          return sortConfig.direction === "asc" ? aValue - bValue : bValue - aValue;
        }
        return sortConfig.direction === "asc"
          ? String(aValue).localeCompare(String(bValue))
          : String(bValue).localeCompare(String(aValue));
      });
    }
    return sortable;
  }, [parsedData, sortConfig]);

  const filteredData = useMemo(() => {
    if (!search) return sortedData;
    const lowerSearch = search.toLowerCase();
    return sortedData.filter((row) =>
      Object.values(row).some((val) => String(val).toLowerCase().includes(lowerSearch))
    );
  }, [sortedData, search]);

  const paginatedData = useMemo(() => {
    const rowsPerPage = 10;
    const start = (currentPage - 1) * rowsPerPage;
    return filteredData.slice(start, start + rowsPerPage);
  }, [filteredData, currentPage]);

  const totalPages = Math.ceil(filteredData.length / 10);

  const requestSort = (key: string) => {
    let direction: "asc" | "desc" = "asc";
    if (sortConfig && sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc";
    }
    setSortConfig({ key, direction });
    setCurrentPage(1);
  };

  // Numerical columns for descriptive stats
  const numericColumns = useMemo(() => {
    if (parsedData.length === 0) return [];
    return Object.keys(parsedData[0]).filter(
      (key) => typeof parsedData[0][key] === "number" && parsedData[0][key] !== null
    );
  }, [parsedData]);

  return (
    <div id="data-explorer-root" className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Sidebar Selector */}
      <div id="explorer-sidebar" className="lg:col-span-1 bg-slate-900 p-4 rounded-2xl border border-slate-800">
        <h3 className="text-slate-500 font-bold mb-3 px-2 text-xs uppercase tracking-wider">
          Danh mục Dataset ({datasets.length})
        </h3>
        <div className="space-y-1">
          {datasets.map((d) => {
            const Icon = d.icon;
            return (
              <button
                key={d.id}
                id={`btn-tab-${d.id}`}
                onClick={() => handleTabChange(d.id)}
                className={`w-full text-left px-3 py-2.5 rounded-xl transition-all duration-200 text-sm flex items-center gap-3 ${
                  activeTab === d.id
                    ? "bg-slate-950 text-sky-400 font-semibold border-l-4 border-sky-400"
                    : "text-slate-400 hover:bg-slate-800/50 hover:text-slate-200"
                }`}
              >
                <Icon className={`w-4 h-4 ${activeTab === d.id ? "text-sky-400" : "text-slate-500"}`} />
                <span className="truncate">{d.name}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Dataset Explorer and Stats */}
      <div id="explorer-main" className="lg:col-span-3 space-y-6">
        {/* Table Card */}
        <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
            <div>
              <h2 className="text-xl font-bold text-slate-100">
                {datasets.find((d) => d.id === activeTab)?.name.split(". ")[1]}
              </h2>
              <p className="text-slate-400 text-xs mt-1">
                Hiển thị dữ liệu thực tế được sử dụng trong quy trình mô hình hóa (Tổng cộng {filteredData.length} / {parsedData.length} bản ghi)
              </p>
            </div>
            
            {/* Search Input */}
            <div className="relative">
              <input
                type="text"
                id="search-dataset-input"
                placeholder="Tìm kiếm dữ liệu..."
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full sm:w-64 pl-10 pr-4 py-2 text-sm bg-slate-950 border border-slate-800 rounded-xl focus:outline-none focus:border-sky-500 focus:bg-slate-900/50 transition-all text-slate-200 placeholder:text-slate-600"
              />
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
            </div>
          </div>

          {/* Table Container */}
          <div className="overflow-x-auto border border-slate-800 rounded-xl bg-slate-950">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="bg-slate-900/80 text-slate-300 border-b border-slate-800">
                  {headers.map((h) => (
                    <th
                      key={h}
                      onClick={() => requestSort(h)}
                      className="px-4 py-3 font-semibold text-xs tracking-wider cursor-pointer hover:bg-slate-800 hover:text-slate-100 select-none transition-colors"
                    >
                      <div className="flex items-center gap-1">
                        {h}
                        <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {paginatedData.length > 0 ? (
                  paginatedData.map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/30 transition-colors">
                      {headers.map((h) => {
                        const val = row[h];
                        let content = String(val === null || val === undefined ? "—" : val);
                        if (typeof val === "boolean") {
                          content = val ? "Có" : "Không";
                        }
                        return (
                          <td key={h} className="px-4 py-3 text-xs text-slate-300 max-w-[200px] truncate">
                            {typeof val === "boolean" ? (
                              <span
                                className={`px-2 py-0.5 rounded-full text-xs font-semibold ${
                                  val ? "bg-green-500/10 text-green-400 border border-green-500/20" : "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                                }`}
                              >
                                {content}
                              </span>
                            ) : typeof val === "number" && h.toLowerCase().includes("vnd") ? (
                              <span className="font-mono text-sky-400 font-semibold">
                                {val.toLocaleString("vi-VN")}
                              </span>
                            ) : typeof val === "number" && h.toLowerCase().includes("million") ? (
                              <span className="font-mono font-semibold text-slate-200">{val} Tr triệu</span>
                            ) : (
                              content
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={headers.length} className="px-4 py-8 text-center text-slate-500 text-xs">
                      Không tìm thấy dữ liệu nào phù hợp với tìm kiếm
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between border-t border-slate-800 pt-4 mt-4">
              <span className="text-slate-400 text-xs">
                Trang {currentPage} trên {totalPages} (Tổng {filteredData.length} dòng)
              </span>
              <div className="flex gap-1">
                <button
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  className="px-3 py-1.5 rounded-lg border border-slate-800 bg-slate-900 text-xs font-medium text-slate-300 hover:bg-slate-850 disabled:opacity-30 disabled:pointer-events-none transition-all"
                >
                  Trước
                </button>
                <button
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  className="px-3 py-1.5 rounded-lg border border-slate-800 bg-slate-900 text-xs font-medium text-slate-300 hover:bg-slate-850 disabled:opacity-30 disabled:pointer-events-none transition-all"
                >
                  Sau
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Statistical Summary Card */}
        {numericColumns.length > 0 && (
          <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800">
            <h3 className="text-base font-bold text-slate-100 mb-4 flex items-center gap-2">
              <BarChart4 className="w-5 h-5 text-sky-400" />
              Thống kê Mô tả Các Biến Số (Descriptive Statistics)
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {numericColumns.map((col) => {
                const stats = getDescriptiveStats(parsedData, col);
                if (!stats) return null;
                const isPrice = col.toLowerCase().includes("vnd");
                const format = (v: number) => {
                  if (isPrice) return `${Math.round(v).toLocaleString("vi-VN")}đ`;
                  return Number(v.toFixed(2));
                };
                return (
                  <div key={col} className="bg-slate-950 p-4 rounded-xl border border-slate-800/60 space-y-2">
                    <h4 className="text-slate-200 font-bold text-xs border-b border-slate-800 pb-1.5 mb-2 truncate">
                      {col}
                    </h4>
                    <div className="grid grid-cols-2 gap-y-1 text-xs">
                      <span className="text-slate-400">Mẫu (N):</span>
                      <span className="text-slate-200 font-medium text-right">{stats.count}</span>

                      <span className="text-slate-400">Trung bình (μ):</span>
                      <span className="text-sky-400 font-bold text-right font-mono">{format(stats.mean)}</span>

                      <span className="text-slate-400">Trung vị (Median):</span>
                      <span className="text-slate-200 font-semibold text-right font-mono">{format(stats.median)}</span>

                      <span className="text-slate-400">Lớn nhất (Max):</span>
                      <span className="text-slate-200 font-semibold text-right font-mono">{format(stats.max)}</span>

                      <span className="text-slate-400">Nhỏ nhất (Min):</span>
                      <span className="text-slate-200 font-semibold text-right font-mono">{format(stats.min)}</span>

                      <span className="text-slate-400">Độ lệch chuẩn (σ):</span>
                      <span className="text-slate-200 font-semibold text-right font-mono">{format(stats.stdDev)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
