import React, { useMemo, useState } from "react";
import { farmMonitoringCSV } from "../data/datasets";
import { parseCSV } from "../utils/csvParser";
import {
  AlertTriangle,
  Droplet,
  Thermometer,
  ShieldAlert,
  Bug,
  Sprout,
  CheckCircle,
  XCircle,
  ChevronDown,
  ChevronUp,
  Filter,
  Info,
  SlidersHorizontal,
  ThumbsUp,
  RotateCcw
} from "lucide-react";

interface FarmAlert {
  id: string;
  farmId: string;
  farmerId: string;
  province: string;
  crop: string;
  soilMoisture: number;
  temperature: number;
  riskType: "pest" | "fungus" | "drought" | "none";
  severity: "critical" | "warning" | "info" | "none";
  title: string;
  desc: string;
  actionRequired: string;
}

export default function AlertCards() {
  const [selectedCrop, setSelectedCrop] = useState<string>("Tất cả");
  const [selectedProvince, setSelectedProvince] = useState<string>("Tất cả");
  const [minSeverity, setMinSeverity] = useState<string>("all");
  const [acknowledgedAlerts, setAcknowledgedAlerts] = useState<string[]>([]);
  const [expandedAlert, setExpandedAlert] = useState<string | null>(null);

  // Parse telemetry datasets dynamically
  const farmFailsafeData = useMemo(() => {
    try {
      return parseCSV(farmMonitoringCSV);
    } catch (e) {
      console.error("Error parsing farm monitoring CSV inside alert engine:", e);
      return [];
    }
  }, []);

  // Compute active real-time risk levels for each farm
  const alerts: FarmAlert[] = useMemo(() => {
    return farmFailsafeData.map((row: any, idx: number) => {
      const farmId = row.Farm_ID || `FM-ERR-${idx}`;
      const farmerId = row.Farmer_ID || "N/A";
      const province = row.Province || "Chưa xác định";
      const crop = row.Crop || "Cây trồng";
      const soilMoisture = parseFloat(row["Soil_Moisture_%"]) || 0;
      const temperature = parseFloat(row.Temperature_C) || 0;

      let riskType: "pest" | "fungus" | "drought" | "none" = "none";
      let severity: "critical" | "warning" | "info" | "none" = "none";
      let title = "";
      let desc = "";
      let actionRequired = "";

      // 1. Critical Drought Risk
      if (soilMoisture < 50 && temperature > 31) {
        riskType = "drought";
        severity = "critical";
        title = `Cảnh báo hạn hán & Cháy lá sầu riêng`;
        desc = `Độ ẩm đất cực thấp (${soilMoisture}%) kết hợp nhiệt độ cao (${temperature}°C) dễ gây rụng lá và héo rễ non đột ngột.`;
        actionRequired = "Khẩn cấp: Bật vòi tưới phun sương giữ ẩm cho đất và hạ nhiệt tán lá vào sáng sớm/chiều mát.";
      }
      // 2. High Pest & Insect Risk (Thích nhiệt ẩm cao hoặc khô hanh vừa phải tùy loại cây)
      else if (crop === "Sầu riêng" && soilMoisture < 58 && temperature >= 30.5) {
        riskType = "pest";
        severity = "warning";
        title = `Nguy cơ bùng phát Rầy phấn trắng`;
        desc = `Điều kiện nhiệt độ (${temperature}°C) và ẩm độ dưới tán sầu riêng đang tạo ổ dịch thuận lợi cho rầy phấn trắng ký sinh đọt non.`;
        actionRequired = "Khuyến nghị: Theo dõi kỹ mặt dưới các chồi sầu riêng non, phun chế phẩm sinh học trị rầy nếu phát hiện mật độ cao.";
      }
      else if (crop === "Thanh long" && temperature > 32) {
        riskType = "pest";
        severity = "warning";
        title = `Cảnh báo sương mai & Nám cành thanh long`;
        desc = `Nhiệt độ môi trường vượt ngưỡng an toàn (${temperature}°C). Nguy cơ gây cháy nắng vỏ cành và tạo điều kiện rệp sáp phát triển.`;
        actionRequired = "Nên bổ sung rơm tủ gốc và bổ sung Kali để tăng sức đề kháng nhiệt cho dây thanh long.";
      }
      // 3. High Fungus Risk (Độ ẩm quá cao kết hợp nóng ẩm)
      else if (soilMoisture > 75 && temperature > 30) {
        riskType = "fungus";
        severity = "critical";
        title = `Cảnh báo nấm Thối rễ & Xì mủ (Phytophthora)`;
        desc = `Độ ẩm đất bão hòa cao (${soilMoisture}%) và nhiệt độ ấm nóng (${temperature}°C) tạo điều kiện cực kỳ thuận lợi cho bào tử nấm lây lan qua mạch dẫn.`;
        actionRequired = "Khẩn cấp: Tạm ngưng tưới nước, xới xáo đất nhẹ để thoát khí, quét vôi hoặc đồng sunfat quanh cổ rễ.";
      }
      else if (soilMoisture < 50) {
        riskType = "drought";
        severity = "warning";
        title = `Độ ẩm đất thiếu hụt`;
        desc = `Hệ thống ghi nhận độ ẩm đất ở mức thấp (${soilMoisture}%), dưới ngưỡng sinh trưởng tiêu chuẩn của cây ${crop}.`;
        actionRequired = "Cân nhắc kích hoạt hệ thống tưới nhỏ giọt định kỳ để bổ sung lượng ẩm tối thiểu.";
      }

      return {
        id: `alert-${farmId}-${idx}`,
        farmId,
        farmerId,
        province,
        crop,
        soilMoisture,
        temperature,
        riskType,
        severity,
        title,
        desc,
        actionRequired
      };
    }).filter(a => a.severity !== "none");
  }, [farmFailsafeData]);

  // Unique lists for filtering dropdowns
  const cropsList = useMemo(() => {
    const list = new Set(alerts.map(a => a.crop));
    return ["Tất cả", ...Array.from(list)];
  }, [alerts]);

  const provincesList = useMemo(() => {
    const list = new Set(alerts.map(a => a.province));
    return ["Tất cả", ...Array.from(list)];
  }, [alerts]);

  // Filter alerts
  const filteredAlerts = useMemo(() => {
    return alerts.filter(a => {
      if (acknowledgedAlerts.includes(a.id)) return false;
      
      const cropMatch = selectedCrop === "Tất cả" || a.crop === selectedCrop;
      const provinceMatch = selectedProvince === "Tất cả" || a.province === selectedProvince;
      
      let severityMatch = true;
      if (minSeverity === "critical") severityMatch = a.severity === "critical";
      if (minSeverity === "warning") severityMatch = a.severity === "critical" || a.severity === "warning";
      
      return cropMatch && provinceMatch && severityMatch;
    });
  }, [alerts, selectedCrop, selectedProvince, minSeverity, acknowledgedAlerts]);

  // Count stats
  const stats = useMemo(() => {
    const total = alerts.filter(a => !acknowledgedAlerts.includes(a.id)).length;
    const critical = alerts.filter(a => a.severity === "critical" && !acknowledgedAlerts.includes(a.id)).length;
    const warning = alerts.filter(a => a.severity === "warning" && !acknowledgedAlerts.includes(a.id)).length;
    return { total, critical, warning };
  }, [alerts, acknowledgedAlerts]);

  const toggleExpand = (id: string) => {
    setExpandedAlert(expandedAlert === id ? null : id);
  };

  const handleAcknowledge = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setAcknowledgedAlerts([...acknowledgedAlerts, id]);
    if (expandedAlert === id) setExpandedAlert(null);
  };

  const resetAcknowledged = () => {
    setAcknowledgedAlerts([]);
  };

  return (
    <div id="alert-dashboard-container" className="space-y-4">
      {/* Alert Header Summary bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 p-5 rounded-2xl border border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-xl">
            <ShieldAlert className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h4 className="text-slate-100 font-black text-sm">Hệ thống Cảnh báo Sức khỏe Cây trồng Tự động (AI-IoT)</h4>
            <p className="text-slate-400 text-xs mt-0.5">
              Phát hiện dị thường về độ ẩm đất và nhiệt độ từ trạm đo IoT để dự báo sớm dịch hại và rủi ro sinh trưởng.
            </p>
          </div>
        </div>

        {/* Counts badges */}
        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 rounded-lg text-[10px] font-black bg-rose-950/60 text-rose-400 border border-rose-900/50 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3 text-rose-400" />
            <span>{stats.critical} Nguy cấp</span>
          </span>
          <span className="px-2.5 py-1 rounded-lg text-[10px] font-black bg-amber-950/60 text-amber-400 border border-amber-900/50 flex items-center gap-1">
            <Info className="w-3 h-3 text-amber-400" />
            <span>{stats.warning} Cảnh báo</span>
          </span>
          {acknowledgedAlerts.length > 0 && (
            <button
              onClick={resetAcknowledged}
              className="px-2 py-1 rounded-lg text-[10px] font-black bg-slate-950 hover:bg-slate-850 text-slate-400 hover:text-slate-200 border border-slate-800 transition-all cursor-pointer flex items-center gap-1"
              title="Khôi phục các cảnh báo đã ẩn"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Khôi phục ({acknowledgedAlerts.length})</span>
            </button>
          )}
        </div>
      </div>

      {/* Interactive Controls & Filters */}
      <div className="bg-slate-900/40 p-4 rounded-xl border border-slate-800/80 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2 text-xs text-slate-400 font-bold">
          <Filter className="w-4 h-4 text-slate-500" />
          <span>Bộ lọc thông minh:</span>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-xs">
          {/* Crop select */}
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-slate-500 font-bold uppercase">Cây trồng:</span>
            <select
              value={selectedCrop}
              onChange={(e) => setSelectedCrop(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-slate-300 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-indigo-500 transition-all font-semibold cursor-pointer"
            >
              {cropsList.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          {/* Province select */}
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-slate-500 font-bold uppercase">Tỉnh thành:</span>
            <select
              value={selectedProvince}
              onChange={(e) => setSelectedProvince(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-slate-300 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-indigo-500 transition-all font-semibold cursor-pointer"
            >
              {provincesList.map(p => (
                <option key={p} value={p}>{p}</option>
              ))}
            </select>
          </div>

          {/* Severity filter */}
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-slate-500 font-bold uppercase">Mức độ nguy hiểm:</span>
            <select
              value={minSeverity}
              onChange={(e) => setMinSeverity(e.target.value)}
              className="bg-slate-950 border border-slate-800 text-slate-300 text-xs rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-indigo-500 transition-all font-semibold cursor-pointer"
            >
              <option value="all">Tất cả mức độ</option>
              <option value="warning">Cảnh báo trở lên</option>
              <option value="critical">Chỉ xem Nguy cấp (Critical)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Alerts Grid / List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredAlerts.length > 0 ? (
          filteredAlerts.map((alert) => {
            const isCritical = alert.severity === "critical";
            const isExpanded = expandedAlert === alert.id;
            
            return (
              <div
                key={alert.id}
                onClick={() => toggleExpand(alert.id)}
                className={`p-5 rounded-2xl border transition-all duration-300 relative overflow-hidden cursor-pointer hover:-translate-y-0.5 select-none ${
                  isCritical
                    ? "bg-rose-950/10 border-rose-900/50 hover:bg-rose-950/20 shadow-md shadow-rose-950/5"
                    : "bg-amber-950/10 border-amber-900/50 hover:bg-amber-950/20 shadow-md shadow-amber-950/5"
                }`}
              >
                {/* Background decorative glow element */}
                <div className={`absolute top-0 right-0 w-24 h-24 rounded-full filter blur-2xl opacity-10 -mr-6 -mt-6 ${
                  isCritical ? "bg-rose-500" : "bg-amber-500"
                }`} />

                {/* Primary Card Row */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    {/* Dynamic Indicator Icon */}
                    <div className={`p-2.5 rounded-xl shrink-0 border ${
                      isCritical
                        ? "bg-rose-950 text-rose-400 border-rose-900/40"
                        : "bg-amber-950 text-amber-400 border-amber-900/40"
                    }`}>
                      {alert.riskType === "pest" ? (
                        <Bug className="w-5 h-5" />
                      ) : alert.riskType === "fungus" ? (
                        <ShieldAlert className="w-5 h-5" />
                      ) : (
                        <Thermometer className="w-5 h-5 animate-bounce" />
                      )}
                    </div>

                    <div>
                      {/* Meta Tags Row */}
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`text-[9px] font-black px-2 py-0.5 rounded-full tracking-wide uppercase ${
                          isCritical
                            ? "bg-rose-950/80 text-rose-400 border border-rose-900/30"
                            : "bg-amber-950/80 text-amber-400 border border-amber-900/30"
                        }`}>
                          {alert.severity === "critical" ? "NGUY CẤP" : "CẢNH BÁO PHÒNG TRỪ"}
                        </span>
                        <span className="text-[10px] text-indigo-400 font-extrabold">{alert.crop}</span>
                        <span className="text-[10px] text-slate-500">•</span>
                        <span className="text-[10px] text-slate-400 font-bold">{alert.province}</span>
                      </div>

                      {/* Title */}
                      <h5 className="text-slate-200 font-black text-sm mt-1.5 leading-snug tracking-tight">
                        {alert.title}
                      </h5>
                    </div>
                  </div>

                  {/* Top-Right Toggle & Dismiss triggers */}
                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => handleAcknowledge(alert.id, e)}
                      className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer shrink-0"
                      title="Xác nhận đã xử lý"
                    >
                      <ThumbsUp className="w-3.5 h-3.5" />
                    </button>
                    <div className="text-slate-500 shrink-0 p-1">
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </div>
                  </div>
                </div>

                {/* Inline current telemetry stats strip */}
                <div className="grid grid-cols-2 gap-2 mt-4 bg-slate-950/60 p-2.5 rounded-xl border border-slate-850">
                  <div className="flex items-center gap-1.5">
                    <Droplet className={`w-3.5 h-3.5 ${alert.soilMoisture < 50 ? "text-rose-400" : "text-sky-400"}`} />
                    <div className="text-[10px]">
                      <span className="text-slate-500 block">Độ ẩm đất</span>
                      <strong className="text-slate-200 font-mono font-bold">{alert.soilMoisture}%</strong>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Thermometer className={`w-3.5 h-3.5 ${alert.temperature > 31 ? "text-rose-400" : "text-amber-400"}`} />
                    <div className="text-[10px]">
                      <span className="text-slate-500 block">Nhiệt độ đo</span>
                      <strong className="text-slate-200 font-mono font-bold">{alert.temperature}°C</strong>
                    </div>
                  </div>
                </div>

                {/* Expanded guidance details drawer */}
                {isExpanded && (
                  <div className="mt-4 pt-4 border-t border-slate-800/60 space-y-3 text-xs animate-fadeIn">
                    <div className="space-y-1">
                      <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider block">Chi tiết sự cố</span>
                      <p className="text-slate-350 leading-relaxed font-semibold">
                        {alert.desc}
                      </p>
                    </div>

                    <div className={`p-3 rounded-xl border flex gap-2 ${
                      isCritical
                        ? "bg-rose-950/25 border-rose-900/30 text-rose-300"
                        : "bg-amber-950/25 border-amber-900/30 text-amber-300"
                    }`}>
                      <Info className="w-4 h-4 shrink-0 mt-0.5" />
                      <div className="space-y-0.5">
                        <span className="text-[9px] font-black uppercase tracking-wider block">Chỉ dẫn kỹ thuật của Chuyên gia:</span>
                        <p className="text-[11px] font-bold leading-normal">
                          {alert.actionRequired}
                        </p>
                      </div>
                    </div>

                    <div className="flex justify-between items-center text-[10px] text-slate-500 pt-1">
                      <span>Mã trạm: <strong>{alert.farmId}</strong></span>
                      <span>Mã nông hộ: <strong>{alert.farmerId}</strong></span>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="col-span-1 md:col-span-2 py-12 bg-slate-900/30 rounded-2xl border border-dashed border-slate-800 text-center space-y-2">
            <CheckCircle className="w-10 h-10 text-emerald-500 mx-auto" />
            <div className="space-y-0.5">
              <span className="font-extrabold text-slate-200 block text-sm">Hệ thống đang hoạt động an toàn</span>
              <p className="text-slate-500 text-xs">
                Không phát hiện bất kỳ dị thường hay rủi ro sâu bệnh nào từ dữ liệu thời gian thực.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
