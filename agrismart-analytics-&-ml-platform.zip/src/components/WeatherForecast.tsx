import React, { useState, useEffect, useMemo } from "react";
import {
  Sun,
  Cloud,
  CloudSun,
  CloudRain,
  CloudLightning,
  CloudDrizzle,
  Droplet,
  Thermometer,
  CalendarDays,
  Sprout,
  Compass,
  AlertCircle,
  TrendingDown,
  TrendingUp,
  RefreshCw,
  Info
} from "lucide-react";

interface WeatherDay {
  date: string;
  tempMax: number;
  tempMin: number;
  precipitation: number;
  humidity: number;
  description: string;
  icon: string;
  weatherCode: number;
}

const PROVINCES = [
  "Đắk Lắk",
  "Tiền Giang",
  "Đồng Tháp",
  "An Giang",
  "Lâm Đồng",
  "Cần Thơ"
];

export default function WeatherForecast() {
  const [selectedProvince, setSelectedProvince] = useState<string>("Đắk Lắk");
  const [forecast, setForecast] = useState<WeatherDay[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchWeather = async (prov: string) => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`/api/weather?province=${encodeURIComponent(prov)}`);
      if (!response.ok) {
        throw new Error("Không thể kết nối tới máy chủ thời tiết.");
      }
      const data = await response.json();
      setForecast(data.forecast || []);
    } catch (err: any) {
      console.error("Error fetching weather:", err);
      setError(err.message || "Đã xảy ra lỗi khi tải dữ liệu thời tiết.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWeather(selectedProvince);
  }, [selectedProvince]);

  // Translate ISO date (YYYY-MM-DD) into beautiful Vietnamese Day name
  const formatVietnameseDate = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      const dayNum = date.getDay();
      const days = ["Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"];
      const formattedDate = date.toLocaleDateString("vi-VN", { day: "2-digit", month: "2-digit" });
      return {
        dayName: days[dayNum],
        dateOnly: formattedDate
      };
    } catch (e) {
      return { dayName: "Hôm nay", dateOnly: dateStr };
    }
  };

  // Get dynamic cultivation recommendation based on 7-day weather outlook
  const cultivationAdvisory = useMemo(() => {
    if (forecast.length === 0) return null;

    let totalRain = 0;
    let maxTemp = -999;
    let minHumidity = 999;
    let rainDays = 0;
    let superRainyDay: string | null = null;
    let superHotDay: string | null = null;

    forecast.forEach((day) => {
      totalRain += day.precipitation;
      if (day.precipitation > 0) rainDays++;
      if (day.precipitation > 15 && !superRainyDay) {
        const { dayName } = formatVietnameseDate(day.date);
        superRainyDay = dayName;
      }
      if (day.tempMax > maxTemp) {
        maxTemp = day.tempMax;
        if (day.tempMax > 34) {
          const { dayName } = formatVietnameseDate(day.date);
          superHotDay = dayName;
        }
      }
      if (day.humidity < minHumidity) {
        minHumidity = day.humidity;
      }
    });

    // Recommendations logic
    if (superRainyDay) {
      return {
        title: "Khuyến nghị mưa lớn: Tránh bón phân & Cải thiện rãnh thoát nước",
        text: `Dự kiến có mưa lớn tập trung vào khoảng ${superRainyDay}. Khuyến nghị nông hộ hoãn bón phân hóa học ngoài trời để tránh rửa trôi lãng phí. Kiểm tra ngay hệ thống kênh rạch, rãnh thoát nước để phòng ngừa ngập úng rễ sầu riêng/thanh long.`,
        type: "danger",
        badge: "Cảnh báo xói mòn"
      };
    }

    if (totalRain > 25) {
      return {
        title: "Khuyến nghị ẩm độ cao: Đề phòng nấm bệnh sinh trưởng",
        text: `Tổng lượng mưa dự báo trong tuần đạt mức khá (${totalRain.toFixed(1)} mm, mưa rải rác ${rainDays} ngày). Độ ẩm không khí tăng cao tạo ổ dịch nấm hại quả, thối rễ mủ sầu riêng. Hãy tiến hành tỉa cành thông thoáng, dọn cỏ dại quanh gốc cây.`,
        type: "warning",
        badge: "Đề phòng nấm hại"
      };
    }

    if (superHotDay) {
      return {
        title: "Khuyến nghị nhiệt cao: Tăng tần suất tưới giữ ẩm ban đêm",
        text: `Nhiệt độ cực đỉnh lên tới ${maxTemp}°C xuất hiện quanh ${superHotDay}. Khuyến cáo tăng lượng tưới nhỏ giọt lúc chiều tối để điều hòa độ ẩm đất rễ cây, phủ rơm rạ khô quanh bán kính gốc sầu riêng để hạn chế thoát hơi nước.`,
        type: "warning",
        badge: "Cân bằng nước"
      };
    }

    if (totalRain === 0) {
      return {
        title: "Khuyến nghị hạn nhẹ: Chế độ tưới nước định kỳ",
        text: "Cả tuần trời nắng ráo hoàn toàn không có mưa dông. Thích hợp cho việc thu hoạch quả thanh long, xoài chín, phơi sấy cà phê. Tuy nhiên, lưu ý duy trì hệ thống tưới phun sương tự động 2 lần/ngày để bảo đảm dưỡng chất nuôi bông/đọt non sầu riêng.",
        type: "success",
        badge: "Nắng ráo lý tưởng"
      };
    }

    return {
      title: "Khuyến nghị thời tiết ôn hòa: Phù hợp bón phân dưỡng đọt",
      text: "Các chỉ số thời tiết dao động lý tưởng (Nắng rải rác xen kẽ dông nhẹ chiều tối). Thời điểm vàng để nông hộ tiến hành bón lân hữu cơ vi sinh, phun phân bón lá hỗ trợ sầu riêng kéo đọt non hoặc búp hoa thanh long phát triển đồng đều.",
      type: "success",
      badge: "Canh tác thuận lợi"
    };
  }, [forecast]);

  // Render weather icon dynamically
  const renderWeatherIcon = (iconName: string) => {
    switch (iconName) {
      case "sun":
        return <Sun className="w-8 h-8 text-amber-400 drop-shadow-[0_0_10px_rgba(245,158,11,0.4)]" />;
      case "cloud-sun":
        return <CloudSun className="w-8 h-8 text-sky-300 drop-shadow-[0_0_10px_rgba(125,211,252,0.3)]" />;
      case "cloud":
        return <Cloud className="w-8 h-8 text-slate-400" />;
      case "cloud-drizzle":
        return <CloudDrizzle className="w-8 h-8 text-teal-400 animate-pulse" />;
      case "cloud-rain":
        return <CloudRain className="w-8 h-8 text-blue-400 drop-shadow-[0_0_10px_rgba(59,130,246,0.3)]" />;
      case "cloud-rain-wind":
        return <CloudRain className="w-8 h-8 text-blue-500 drop-shadow-[0_0_15px_rgba(59,130,246,0.5)] animate-bounce" />;
      case "cloud-lightning":
        return <CloudLightning className="w-8 h-8 text-yellow-400 animate-pulse" />;
      default:
        return <Cloud className="w-8 h-8 text-slate-400" />;
    }
  };

  return (
    <div id="weather-dashboard-widget" className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-6">
      {/* Widget Header with interactive controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-sky-500/10 border border-sky-500/20 text-sky-400 rounded-xl">
            <Compass className="w-6 h-6 animate-spin-slow" />
          </div>
          <div>
            <h4 className="text-slate-100 font-black text-sm uppercase tracking-wider flex items-center gap-2">
              <span>Khí tượng Nông nghiệp liên vùng</span>
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-900/40 normal-case tracking-normal">
                Live Open-Meteo
              </span>
            </h4>
            <p className="text-slate-400 text-xs mt-0.5">
              Dự báo thời tiết 7 ngày tới hỗ trợ lập kế hoạch tưới tiêu, bón phân và thu hoạch.
            </p>
          </div>
        </div>

        {/* Selected Province controller */}
        <div className="flex items-center gap-2">
          <span className="text-[11px] text-slate-500 font-bold uppercase tracking-wider">Vùng trồng:</span>
          <div className="flex items-center gap-2">
            <select
              value={selectedProvince}
              onChange={(e) => setSelectedProvince(e.target.value)}
              disabled={loading}
              className="bg-slate-950 border border-slate-850 text-slate-200 text-xs font-bold rounded-xl px-3 py-1.5 focus:outline-none focus:border-sky-500 transition-all cursor-pointer"
            >
              {PROVINCES.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
            <button
              onClick={() => fetchWeather(selectedProvince)}
              disabled={loading}
              className="p-2 bg-slate-950 border border-slate-850 text-slate-400 hover:text-sky-400 rounded-xl hover:bg-slate-850 transition-all cursor-pointer"
              title="Làm mới dự báo"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Primary loading / error / content panel */}
      {loading ? (
        <div className="py-12 flex flex-col items-center justify-center space-y-3">
          <RefreshCw className="w-8 h-8 text-sky-400 animate-spin" />
          <span className="text-slate-400 text-xs font-semibold">Đang liên kết dữ liệu thời tiết thực...</span>
        </div>
      ) : error ? (
        <div className="p-5 bg-rose-950/20 border border-rose-900/40 rounded-xl flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h5 className="text-slate-200 font-black text-sm">Không thể truy xuất dữ liệu khí tượng</h5>
            <p className="text-slate-400 text-xs">{error}</p>
            <button
              onClick={() => fetchWeather(selectedProvince)}
              className="mt-2 text-xs font-bold text-sky-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              Thử lại ngay
            </button>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* 7-day horizontal scrollable forecast grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
            {forecast.map((day, idx) => {
              const { dayName, dateOnly } = formatVietnameseDate(day.date);
              const isToday = idx === 0;

              return (
                <div
                  key={day.date}
                  className={`p-4 rounded-xl border transition-all duration-300 flex flex-col justify-between space-y-4 hover:border-sky-500/40 relative ${
                    isToday
                      ? "bg-slate-950/80 border-sky-500/40 ring-1 ring-sky-500/20 shadow-md shadow-sky-500/5"
                      : "bg-slate-950/40 border-slate-850"
                  }`}
                >
                  {isToday && (
                    <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 px-2 py-0.5 bg-sky-600 text-[8px] text-sky-100 font-black rounded-full uppercase tracking-wider shadow">
                      Hôm nay
                    </span>
                  )}

                  {/* Header info */}
                  <div className="text-center space-y-0.5 pt-1">
                    <span className="text-xs font-black text-slate-200 block truncate">{dayName}</span>
                    <span className="text-[10px] text-slate-500 font-mono block">{dateOnly}</span>
                  </div>

                  {/* Big visual icon & weather status */}
                  <div className="flex flex-col items-center justify-center space-y-2">
                    {renderWeatherIcon(day.icon)}
                    <span className="text-[10px] text-slate-400 font-bold text-center leading-snug h-6 overflow-hidden line-clamp-2">
                      {day.description}
                    </span>
                  </div>

                  {/* Telemetry info */}
                  <div className="space-y-2 pt-2 border-t border-slate-850/60">
                    {/* Temperature range indicator */}
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-slate-500 font-bold">Nhiệt độ</span>
                      <span className="text-slate-200 font-mono font-bold">
                        {Math.round(day.tempMin)}°-{Math.round(day.tempMax)}°C
                      </span>
                    </div>

                    {/* Humidity */}
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-slate-500 font-bold">Độ ẩm</span>
                      <div className="flex items-center gap-0.5">
                        <Droplet className="w-3 h-3 text-sky-400 shrink-0" />
                        <span className="text-slate-350 font-mono font-bold">{day.humidity}%</span>
                      </div>
                    </div>

                    {/* Rain amount */}
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-slate-500 font-bold">Lượng mưa</span>
                      <span className={`font-mono font-bold ${day.precipitation > 0 ? "text-blue-400" : "text-slate-500"}`}>
                        {day.precipitation.toFixed(1)} mm
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Smart Cultivation Planning Advisory Card */}
          {cultivationAdvisory && (
            <div
              className={`p-4 rounded-xl border flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all ${
                cultivationAdvisory.type === "danger"
                  ? "bg-rose-950/10 border-rose-900/40"
                  : cultivationAdvisory.type === "warning"
                  ? "bg-amber-950/10 border-amber-900/40"
                  : "bg-emerald-950/10 border-emerald-900/40"
              }`}
            >
              <div className="flex items-start gap-3.5">
                <div className={`p-2.5 rounded-xl border shrink-0 mt-0.5 ${
                  cultivationAdvisory.type === "danger"
                    ? "bg-rose-950/60 text-rose-400 border-rose-900/30"
                    : cultivationAdvisory.type === "warning"
                    ? "bg-amber-950/60 text-amber-400 border-amber-900/30"
                    : "bg-emerald-950/60 text-emerald-400 border-emerald-900/30"
                }`}>
                  <Sprout className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`text-[9px] font-black px-2 py-0.5 rounded-full tracking-wide uppercase ${
                      cultivationAdvisory.type === "danger"
                        ? "bg-rose-900/20 text-rose-400 border border-rose-800/30"
                        : cultivationAdvisory.type === "warning"
                        ? "bg-amber-900/20 text-amber-400 border border-amber-800/30"
                        : "bg-emerald-900/20 text-emerald-400 border border-emerald-800/30"
                    }`}>
                      {cultivationAdvisory.badge}
                    </span>
                    <h5 className="text-slate-200 font-extrabold text-xs">
                      {cultivationAdvisory.title}
                    </h5>
                  </div>
                  <p className="text-slate-400 text-xs leading-relaxed font-semibold">
                    {cultivationAdvisory.text}
                  </p>
                </div>
              </div>

              <div className="shrink-0 flex items-center gap-1 bg-slate-950/80 px-3 py-2 rounded-xl border border-slate-850 text-[10px] text-slate-400">
                <Info className="w-3.5 h-3.5 text-sky-400" />
                <span>Cập nhật 3 giờ trước</span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
