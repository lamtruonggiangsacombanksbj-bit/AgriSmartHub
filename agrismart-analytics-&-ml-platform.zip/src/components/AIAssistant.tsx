import React, { useState, useRef, useEffect } from "react";
import ReactMarkdown from "react-markdown";
import { Send, Bot, User, Sparkles, AlertCircle, RefreshCw } from "lucide-react";

interface Message {
  role: "user" | "model";
  content: string;
}

const SYSTEM_INSTRUCTION = `Bạn là một Chuyên gia phân tích dữ liệu Nông nghiệp thông minh (AgriSmart ML Consultant).
Nhiệm vụ của bạn là giải thích các thuật ngữ học máy, phân tích dữ liệu trích xuất từ 8 file dataset nông nghiệp của người dùng, đề xuất các phương pháp cải thiện năng suất cây trồng, tối ưu hóa lợi nhuận, giảm thiểu rủi ro dịch bệnh, nâng cao chỉ số bền vững ESG, và tư vấn các quyết định canh tác thông minh.
Hãy trả lời bằng tiếng Việt lịch sự, thân thiện, súc tích và dễ hiểu cho nông dân lẫn kỹ sư nông nghiệp.`;

const SUGGESTED_PROMPTS = [
  "Phân tích đặc trưng ảnh hưởng lớn nhất đến sản lượng lúa?",
  "Đề xuất quy trình xử lý dữ liệu thời tiết khi có mưa bão?",
  "Ý nghĩa của chỉ số R² (R-squared) trong mô hình hồi quy là gì?",
  "Làm sao để tăng điểm bền vững ESG cho trang trại sầu riêng?",
];

export default function AIAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "model",
      content:
        "Xin chào! Tôi là **Trợ lý Nông nghiệp Thông minh AI**. Tôi có thể giúp bạn giải thích các ma trận tương quan đặc trưng, tối ưu hóa các siêu tham số mô hình học máy (epochs, depth), tư vấn cải thiện sản lượng cây trồng, nâng cao chỉ số bền vững ESG, và quản trị rủi ro khí hậu dựa trên 8 bộ dữ liệu nông nghiệp thực tế của bạn. Hãy hỏi tôi bất cứ điều gì!",
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend: string) => {
    if (!textToSend.trim()) return;

    const userMessage: Message = { role: "user", content: textToSend };
    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMessage],
          systemInstruction: SYSTEM_INSTRUCTION,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Gặp lỗi khi giao tiếp với máy chủ AI.");
      }

      setMessages((prev) => [...prev, { role: "model", content: data.text }]);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Không thể kết nối đến Trợ lý AI. Vui lòng kiểm tra GEMINI_API_KEY trong panel Secrets.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(input);
  };

  const handleResetChat = () => {
    setMessages([
      {
        role: "model",
        content:
          "Xin chào! Tôi là **Trợ lý Nông nghiệp Thông minh AI**. Tôi có thể giúp bạn giải thích các ma trận tương quan đặc trưng, tối ưu hóa các siêu tham số mô hình học máy (epochs, depth), tư vấn cải thiện sản lượng cây trồng, nâng cao chỉ số bền vững ESG, và quản trị rủi ro khí hậu dựa trên 8 bộ dữ liệu nông nghiệp thực tế của bạn. Hãy hỏi tôi bất cứ điều gì!",
      },
    ]);
    setError(null);
    setInput("");
  };

  return (
    <div id="ai-assistant-root" className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[600px]">
      {/* Suggestions panel */}
      <div id="ai-prompts-panel" className="lg:col-span-1 bg-slate-900 p-5 rounded-2xl border border-slate-800 flex flex-col justify-between">
        <div className="space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Sparkles className="w-5 h-5 text-sky-400 animate-pulse" />
            <h3 className="text-slate-100 font-bold text-sm">Gợi ý câu hỏi nhanh</h3>
          </div>
          <p className="text-slate-400 text-xs leading-relaxed">
            Nhấp vào bất kỳ mẫu câu nào bên dưới để nhận phân tích, tư vấn chuyên sâu từ chuyên gia AI:
          </p>
          <div className="space-y-2">
            {SUGGESTED_PROMPTS.map((prompt) => (
              <button
                key={prompt}
                onClick={() => handleSendMessage(prompt)}
                disabled={isLoading}
                className="w-full text-left p-3 rounded-xl text-xs text-slate-300 bg-slate-950 hover:bg-sky-950/40 hover:text-sky-400 border border-slate-800/80 hover:border-sky-900/40 transition-all font-medium disabled:opacity-50 cursor-pointer"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={handleResetChat}
          className="w-full py-2 bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800/80 font-bold rounded-xl text-xs transition-all flex items-center justify-center gap-1.5 mt-4 cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Khởi động lại cuộc thoại
        </button>
      </div>

      {/* Main chat window */}
      <div id="ai-chat-window" className="lg:col-span-3 bg-slate-900 rounded-2xl border border-slate-800 flex flex-col overflow-hidden h-full">
        {/* Chat Header */}
        <div className="bg-slate-950 p-4 border-b border-slate-800 flex items-center gap-3 shrink-0">
          <div className="p-2 bg-sky-950/60 rounded-xl border border-sky-900/30">
            <Bot className="w-5 h-5 text-sky-400" />
          </div>
          <div>
            <h4 className="font-bold text-slate-100 text-sm">AgriSmart AI Consultant</h4>
            <span className="text-[10px] text-sky-400 font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-sky-400 inline-block animate-ping" />
              Sẵn sàng trợ giúp 24/7
            </span>
          </div>
        </div>

        {/* Message Log */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-950/40">
          {messages.map((m, idx) => (
            <div key={idx} className={`flex gap-3 max-w-[85%] ${m.role === "user" ? "ml-auto flex-row-reverse" : "mr-auto"}`}>
              {/* Avatar */}
              <div className={`p-2 rounded-xl shrink-0 h-10 w-10 flex items-center justify-center ${m.role === "user" ? "bg-sky-600 text-slate-950" : "bg-slate-900 border border-slate-800 text-sky-400 shadow-sm"}`}>
                {m.role === "user" ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
              </div>

              {/* Bubble */}
              <div className={`p-4 rounded-2xl text-xs leading-relaxed ${m.role === "user" ? "bg-sky-900/60 border border-sky-700/50 text-slate-100 rounded-tr-none" : "bg-slate-900 border border-slate-800 text-slate-100 shadow-sm rounded-tl-none"}`}>
                <div className="markdown-body text-slate-200">
                  <ReactMarkdown>{m.content}</ReactMarkdown>
                </div>
              </div>
            </div>
          ))}

          {/* Loader bubble */}
          {isLoading && (
            <div className="flex gap-3 max-w-[85%] mr-auto animate-pulse">
              <div className="p-2 rounded-xl shrink-0 h-10 w-10 flex items-center justify-center bg-slate-900 border border-slate-800 text-sky-400 shadow-sm">
                <Bot className="w-5 h-5" />
              </div>
              <div className="p-4 rounded-2xl text-xs leading-relaxed bg-slate-900 border border-slate-800 text-slate-400 shadow-sm rounded-tl-none flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-bounce [animation-delay:-0.3s]" />
                <div className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-bounce [animation-delay:-0.15s]" />
                <div className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-bounce" />
              </div>
            </div>
          )}

          {/* Error Banner */}
          {error && (
            <div className="bg-rose-950/40 border border-rose-900/40 text-rose-300 p-4 rounded-xl flex items-start gap-3 max-w-[80%] mx-auto">
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div className="text-xs">
                <span className="font-bold">Lỗi kết nối AI:</span> {error}
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <form onSubmit={handleFormSubmit} className="p-4 border-t border-slate-800 flex gap-3 bg-slate-950 shrink-0">
          <input
            type="text"
            id="ai-chat-user-input"
            disabled={isLoading}
            placeholder="Đặt câu hỏi cho Trợ lý Nông nghiệp..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-sky-500 focus:bg-slate-900/50 transition-all disabled:opacity-50"
          />
          <button
            type="submit"
            id="btn-send-ai-message"
            disabled={isLoading || !input.trim()}
            className="bg-sky-600 hover:bg-sky-500 text-white p-3 rounded-xl transition-all disabled:opacity-50 disabled:pointer-events-none cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
