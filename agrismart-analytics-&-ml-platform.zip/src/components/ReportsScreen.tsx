import React, { useState } from "react";
import AIAssistant from "./AIAssistant";
import {
  BarChart3,
  FileText,
  Download,
  CheckCircle2,
  Sparkles,
  TrendingUp,
  Award,
} from "lucide-react";

interface ReportItem {
  id: string;
  title: string;
  category: "Dự báo" | "ESG" | "Sản lượng";
  date: string;
  author: string;
  fileSize: string;
}

export default function ReportsScreen() {
  const [reports] = useState<ReportItem[]>([
    { id: "REP-01", title: "Dự báo Biến đổi Khí hậu & Lượng mưa Khu vực ĐBSCL Q3/2026", category: "Dự báo", date: "2026-06-15", author: "Hệ thống Học máy AgriSmart", fileSize: "4.2 MB" },
    { id: "REP-02", title: "Báo cáo Tuân thủ ESG & Chứng chỉ Carbon xanh Vùng trồng Sầu riêng", category: "ESG", date: "2026-06-22", author: "Chuyên gia Môi trường AI", fileSize: "2.8 MB" },
    { id: "REP-03", title: "Đánh giá Phân tích Thổ nhưỡng & Kiến nghị Vi lượng Đất Đắk Lắk", category: "Dự báo", date: "2026-06-25", author: "AgriSmart Core Model", fileSize: "1.9 MB" },
    { id: "REP-04", title: "Thống kê Hiệu suất Thu hoạch & Đối chiếu Doanh thu Chuỗi cung ứng", category: "Sản lượng", date: "2026-06-28", author: "Hệ thống Blockchain Node", fileSize: "3.5 MB" }
  ]);

  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  const handleDownload = (id: string, title: string) => {
    setDownloadingId(id);
    setTimeout(() => {
      setDownloadingId(null);
      // Mock triggers download
      const element = document.createElement("a");
      const file = new Blob([`Báo cáo AgriSmart Hub: ${title}\nDữ liệu được băm bảo mật trên Blockchain Node.`], { type: "text/plain" });
      element.href = URL.createObjectURL(file);
      element.download = `${id}_report.txt`;
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }, 1200);
  };

  return (
    <div id="reports-screen-root" className="space-y-6">
      {/* 1. Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-sky-400 text-[10px] font-black uppercase tracking-widest block">Trung tâm dữ liệu</span>
          <h2 className="text-slate-100 font-black text-2xl tracking-tight">Báo cáo Phân tích AI & Thống kê Tối ưu</h2>
          <p className="text-slate-400 text-xs mt-0.5">Truy xuất báo cáo chuyên sâu, chỉ số tín chỉ Carbon và tư vấn mô hình học máy tức thì</p>
        </div>
      </div>

      {/* 2. Main split screen layout */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
        
        {/* Left: Reports list & Download cards */}
        <div className="xl:col-span-5 space-y-5">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4">
            <h3 className="text-slate-100 font-extrabold text-sm flex items-center gap-2 border-b border-slate-800 pb-3">
              <BarChart3 className="w-4 h-4 text-sky-400" />
              Tệp tài liệu xuất bản gần đây
            </h3>

            <div className="space-y-3.5">
              {reports.map((r) => {
                const isDownloading = downloadingId === r.id;
                return (
                  <div
                    key={r.id}
                    className="p-4 bg-slate-950 rounded-2xl border border-slate-850 flex flex-col justify-between gap-3 group hover:border-slate-850 transition-colors"
                  >
                    <div className="space-y-1">
                      <div className="flex justify-between items-center">
                        <span className={`text-[8px] px-2 py-0.5 rounded-full font-black tracking-wider uppercase ${
                          r.category === "Dự báo"
                            ? "bg-sky-950 text-sky-400 border border-sky-900/40"
                            : r.category === "ESG"
                            ? "bg-teal-950 text-teal-400 border border-teal-900/40"
                            : "bg-amber-950 text-amber-400 border border-amber-900/40"
                        }`}>
                          {r.category}
                        </span>
                        <span className="text-[10px] text-slate-500 font-semibold">{r.date}</span>
                      </div>
                      <h4 className="font-extrabold text-xs text-slate-200 tracking-wide leading-relaxed">
                        {r.title}
                      </h4>
                    </div>

                    <div className="border-t border-slate-900/80 pt-2.5 flex items-center justify-between text-[11px] font-bold">
                      <div className="text-slate-500">
                        Bởi: <strong className="text-slate-400">{r.author}</strong>
                      </div>

                      <button
                        onClick={() => handleDownload(r.id, r.title)}
                        disabled={isDownloading}
                        className="text-sky-400 hover:text-sky-300 p-1.5 bg-sky-500/5 hover:bg-sky-500/10 border border-sky-500/10 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 disabled:opacity-40"
                      >
                        {isDownloading ? (
                          <span className="w-3.5 h-3.5 border-2 border-sky-400 border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <>
                            <Download className="w-3.5 h-3.5" />
                            <span className="text-[9px] font-black uppercase tracking-wider">{r.fileSize}</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Core Analytics Highlight Badge */}
          <div className="bg-gradient-to-r from-indigo-950/40 to-slate-900 p-5 rounded-2xl border border-indigo-900/20 space-y-3">
            <div className="p-2 bg-indigo-500/15 text-indigo-400 rounded-xl w-fit border border-indigo-500/20">
              <Award className="w-4 h-4" />
            </div>
            <div>
              <h4 className="font-bold text-slate-200 text-xs uppercase tracking-wider flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-sky-400" />
                Mã hóa Blockchain Node
              </h4>
              <p className="text-slate-400 text-[11px] mt-1.5 leading-relaxed">
                Tất cả dữ liệu sản lượng, thời gian chấm công và xuất xứ lô hàng đều được đăng kiểm số, băm mật SHA-256 phân rã tại các trạm biên (Node confirmed 22) để bảo đảm minh bạch tuyệt đối chống gian lận thương mại nông sản.
              </p>
            </div>
          </div>
        </div>

        {/* Right: Embedded AI Assistant chatbot specifically for report questions */}
        <div className="xl:col-span-7 h-[600px]">
          <AIAssistant />
        </div>

      </div>
    </div>
  );
}
