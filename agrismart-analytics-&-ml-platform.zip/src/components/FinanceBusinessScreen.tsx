import React, { useState, useMemo } from "react";
import { 
  TrendingUp, 
  DollarSign, 
  ArrowUpRight, 
  ArrowDownRight, 
  Calculator, 
  Sparkles, 
  Layers, 
  Activity,
  Plus
} from "lucide-react";
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell
} from "recharts";

const CROP_PRESETS = {
  saurien: { name: "Sầu riêng Ri6", yieldPerHa: 15, defaultPrice: 75000, defaultCost: 120000000 },
  caphe: { name: "Cà phê Robusta", yieldPerHa: 3.5, defaultPrice: 48000, defaultCost: 45000000 },
  lua: { name: "Lúa mùa cao sản", yieldPerHa: 7.2, defaultPrice: 12500, defaultCost: 22000000 }
};

const INITIAL_TRANSACTIONS = [
  { id: "TX-1001", time: "Hôm nay 09:30", type: "income", description: "Bán lô Sầu riêng Dona xuất khẩu Thượng Hải", crop: "Sầu riêng Dona", amount: 480000000, status: "completed" },
  { id: "TX-1002", time: "Hôm nay 08:15", type: "expense", description: "Thanh toán phân bón hữu cơ NPK nhập khẩu", crop: "Hữu cơ tổng hợp", amount: -45000000, status: "completed" },
  { id: "TX-1003", time: "Hôm qua 16:40", type: "income", description: "Nhận tiền thanh toán 10 tấn lúa vụ hè thu", crop: "Lúa cao sản", amount: 125000000, status: "completed" },
  { id: "TX-1004", time: "Hôm qua 11:20", type: "expense", description: "Lắp đặt bổ sung 3 cụm IoT cảm biến độ ẩm rễ", crop: "Thiết bị IoT", amount: -18000000, status: "completed" },
  { id: "TX-1005", time: "28/06/2026", type: "income", description: "Xuất bán 4 tấn Cà phê Robusta Lâm Đồng", crop: "Cà phê Robusta", amount: 192000000, status: "completed" },
];

export default function FinanceBusinessScreen() {
  const [selectedCropKey, setSelectedCropKey] = useState<keyof typeof CROP_PRESETS>("saurien");
  const [area, setArea] = useState(3.5); // ha
  const [marketPrice, setMarketPrice] = useState(CROP_PRESETS.saurien.defaultPrice);
  const [costPerHa, setCostPerHa] = useState(CROP_PRESETS.saurien.defaultCost);

  // Sync sliders when preset crop changes
  const handleCropPresetChange = (key: keyof typeof CROP_PRESETS) => {
    setSelectedCropKey(key);
    setMarketPrice(CROP_PRESETS[key].defaultPrice);
    setCostPerHa(CROP_PRESETS[key].defaultCost);
  };

  const calculatorResults = useMemo(() => {
    const preset = CROP_PRESETS[selectedCropKey];
    const totalYieldKg = preset.yieldPerHa * area * 1000;
    const totalRevenue = totalYieldKg * marketPrice;
    const totalCost = costPerHa * area;
    const totalProfit = totalRevenue - totalCost;
    const roi = totalCost > 0 ? (totalProfit / totalCost) * 100 : 0;
    return {
      totalYieldKg,
      totalRevenue,
      totalCost,
      totalProfit,
      roi
    };
  }, [selectedCropKey, area, marketPrice, costPerHa]);

  // Overall financial summary
  const summaryCards = [
    { title: "Tổng Doanh thu lũy kế", value: "3.84B VND", change: "+14.2% so với tháng trước", positive: true, icon: DollarSign },
    { title: "Lợi nhuận thuần dự kiến", value: "1.65B VND", change: "+8.6% tỷ suất tăng trưởng", positive: true, icon: TrendingUp },
    { title: "Tổng Chi phí hoạt động", value: "2.19B VND", change: "-2.4% tiết kiệm do tối ưu IoT", positive: true, icon: Layers },
    { title: "Chỉ số ROI bình quân", value: "75.4%", change: "Vùng trồng sầu riêng dẫn đầu", positive: true, icon: Activity },
  ];

  // Financial Chart Data (Revenue vs Expenses by Month)
  const chartData = [
    { name: "Tháng 1", revenue: 220, expense: 140, profit: 80 },
    { name: "Tháng 2", revenue: 250, expense: 150, profit: 100 },
    { name: "Tháng 3", revenue: 380, expense: 180, profit: 200 },
    { name: "Tháng 4", revenue: 450, expense: 210, profit: 240 },
    { name: "Tháng 5", revenue: 580, expense: 250, profit: 330 },
    { name: "Tháng 6", revenue: 720, expense: 310, profit: 410 },
  ];

  const pieData = [
    { name: "Sầu riêng Ri6", value: 55, color: "#10b981" },
    { name: "Cà phê Robusta", value: 28, color: "#eab308" },
    { name: "Lúa vụ hè thu", value: 17, color: "#3b82f6" },
  ];

  return (
    <div className="space-y-6 text-slate-200">
      
      {/* Title section */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900/40 p-5 rounded-2xl border border-slate-800/60 backdrop-blur-md">
        <div>
          <h2 className="text-xl font-black text-slate-100 flex items-center gap-2.5 uppercase tracking-tight">
            <span className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
              <TrendingUp className="w-5 h-5" />
            </span>
            Quản trị Tài chính & Kinh doanh nông nghiệp
          </h2>
          <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
            Hệ thống phân tích lợi nhuận, chi phí vận hành, dòng tiền thực và dự báo kinh doanh thông minh nông sản chất lượng cao.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className="px-3 py-1.5 bg-slate-950 border border-slate-800 text-[10px] font-mono font-bold text-slate-400 rounded-xl">
            Cập nhật: Mới nhất
          </span>
          <span className="px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/30 text-[10px] font-black uppercase text-emerald-400 rounded-xl animate-pulse">
            Dòng tiền ổn định
          </span>
        </div>
      </div>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((card, idx) => {
          const Icon = card.icon;
          return (
            <div key={idx} className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 hover:border-slate-700/80 transition-all shadow-xl flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">{card.title}</span>
                <div className="p-2 bg-slate-950/80 border border-slate-800 rounded-xl text-sky-400">
                  <Icon className="w-4 h-4" />
                </div>
              </div>
              <div className="mt-4">
                <h3 className="text-2xl font-black text-slate-100 font-mono tracking-tight">{card.value}</h3>
                <div className="flex items-center gap-1.5 mt-1">
                  {card.positive ? (
                    <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <ArrowDownRight className="w-3.5 h-3.5 text-rose-400" />
                  )}
                  <span className={`text-[10px] font-bold ${card.positive ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {card.change}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Financial Chart Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Revenue and Expense Trend */}
        <div className="lg:col-span-2 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-slate-800/60 pb-4 mb-4">
            <div>
              <h3 className="text-xs font-black text-slate-100 uppercase tracking-wider">Xu hướng Doanh thu & Chi phí 6 tháng đầu năm</h3>
              <p className="text-[10px] text-slate-400 mt-0.5">Giá trị biểu diễn bằng đơn vị Triệu VND (Million VND)</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 bg-indigo-500 rounded-full" />
              <span className="text-[9px] font-bold text-slate-400 mr-2">Doanh thu</span>
              <span className="w-2.5 h-2.5 bg-amber-500 rounded-full" />
              <span className="text-[9px] font-bold text-slate-400">Chi phí</span>
            </div>
          </div>
          
          <div className="h-64 w-full text-slate-900 text-[10px] font-bold">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" stroke="#64748b" tick={{ fill: '#94a3b8' }} />
                <YAxis stroke="#64748b" tick={{ fill: '#94a3b8' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                  labelStyle={{ color: '#f1f5f9', fontWeight: 'bold' }}
                />
                <Legend wrapperStyle={{ color: '#94a3b8' }} />
                <Bar dataKey="revenue" name="Doanh thu" fill="#4f46e5" radius={[4, 4, 0, 0]} />
                <Bar dataKey="expense" name="Chi phí" fill="#d97706" radius={[4, 4, 0, 0]} />
                <Line type="monotone" dataKey="profit" name="Lợi nhuận ròng" stroke="#10b981" strokeWidth={3} dot={{ r: 4 }} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Share of Revenue by Crop type */}
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div className="border-b border-slate-800/60 pb-4 mb-4">
            <h3 className="text-xs font-black text-slate-100 uppercase tracking-wider">Tỷ lệ đóng góp doanh số theo loại cây</h3>
            <p className="text-[10px] text-slate-400 mt-0.5">Dựa trên tổng sản lượng xuất bán đến tháng 6/2026</p>
          </div>

          <div className="flex-1 flex items-center justify-center h-48 relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px' }}
                  itemStyle={{ color: '#f1f5f9' }}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute text-center">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Doanh số</span>
              <span className="text-lg font-black text-slate-100 font-mono">100%</span>
            </div>
          </div>

          <div className="space-y-2 mt-4 pt-4 border-t border-slate-800/40">
            {pieData.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="font-semibold text-slate-300">{item.name}</span>
                </div>
                <span className="font-mono font-black text-slate-100">{item.value}%</span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Simulator Calculator & Log Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        
        {/* Investment & Profit Forecast Calculator */}
        <div className="lg:col-span-3 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800/60 pb-4">
            <div className="flex items-center gap-2">
              <Calculator className="w-4 h-4 text-emerald-400" />
              <h3 className="text-xs font-black text-slate-100 uppercase tracking-wider">Trình giả lập Đầu tư & Ước tính biên Lợi nhuận</h3>
            </div>
            <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded text-[9px] font-bold font-mono uppercase tracking-widest">AI Engine Grounded</span>
          </div>

          {/* Presets Button Selector */}
          <div className="grid grid-cols-3 gap-2">
            {(Object.keys(CROP_PRESETS) as Array<keyof typeof CROP_PRESETS>).map((key) => {
              const isActive = selectedCropKey === key;
              return (
                <button
                  key={key}
                  onClick={() => handleCropPresetChange(key)}
                  className={`py-2 px-3 text-center rounded-xl font-black text-[10px] uppercase tracking-wider transition-all cursor-pointer ${
                    isActive 
                      ? 'bg-sky-600 border border-sky-500 text-slate-100' 
                      : 'bg-slate-950/80 border border-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
                  }`}
                >
                  {CROP_PRESETS[key].name}
                </button>
              );
            })}
          </div>

          {/* Interactive Inputs */}
          <div className="space-y-4 pt-2">
            
            {/* Slider Area */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-400">Diện tích canh tác (ha):</span>
                <span className="text-indigo-400 font-mono font-black">{area.toFixed(1)} ha</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="25.0"
                step="0.5"
                value={area}
                onChange={(e) => setArea(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-indigo-500"
              />
            </div>

            {/* Price Input */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-400">Giá nông sản kỳ vọng (VND/kg):</span>
                <span className="text-emerald-400 font-mono font-black">{marketPrice.toLocaleString()} VND</span>
              </div>
              <input
                type="range"
                min={selectedCropKey === "lua" ? 5000 : selectedCropKey === "caphe" ? 20000 : 30000}
                max={selectedCropKey === "lua" ? 30000 : selectedCropKey === "caphe" ? 100000 : 200000}
                step={selectedCropKey === "lua" ? 500 : 1000}
                value={marketPrice}
                onChange={(e) => setMarketPrice(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-emerald-500"
              />
            </div>

            {/* Cost Input */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-400">Chi phí đầu tư & phân bón (VND/ha):</span>
                <span className="text-amber-400 font-mono font-black">{costPerHa.toLocaleString()} VND</span>
              </div>
              <input
                type="range"
                min={selectedCropKey === "lua" ? 5000000 : selectedCropKey === "caphe" ? 15000000 : 40000000}
                max={selectedCropKey === "lua" ? 50000000 : selectedCropKey === "caphe" ? 120000000 : 250000000}
                step={1000000}
                value={costPerHa}
                onChange={(e) => setCostPerHa(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
            </div>

          </div>

          {/* Output Dashboard Widget */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 grid grid-cols-2 gap-3.5 mt-4">
            
            <div className="p-3 bg-slate-900/40 border border-slate-900 rounded-xl">
              <span className="text-[10px] font-bold text-slate-500 block uppercase">Sản lượng dự kiến</span>
              <strong className="text-slate-200 text-lg font-mono font-black block mt-0.5">
                {(calculatorResults.totalYieldKg / 1000).toFixed(1)} tấn
              </strong>
              <span className="text-[9px] text-slate-500 mt-0.5 block">
                {CROP_PRESETS[selectedCropKey].yieldPerHa} tấn/ha trung bình
              </span>
            </div>

            <div className="p-3 bg-slate-900/40 border border-slate-900 rounded-xl">
              <span className="text-[10px] font-bold text-slate-500 block uppercase">Tổng vốn đầu tư</span>
              <strong className="text-amber-500 text-lg font-mono font-black block mt-0.5">
                {calculatorResults.totalCost.toLocaleString()}đ
              </strong>
              <span className="text-[9px] text-slate-500 mt-0.5 block">
                {(costPerHa / 1000000).toFixed(1)} triệu VND/ha
              </span>
            </div>

            <div className="p-3 bg-slate-900/40 border border-slate-900 rounded-xl">
              <span className="text-[10px] font-bold text-slate-500 block uppercase">Doanh thu dự báo</span>
              <strong className="text-indigo-400 text-lg font-mono font-black block mt-0.5">
                {calculatorResults.totalRevenue.toLocaleString()}đ
              </strong>
              <span className="text-[9px] text-slate-500 mt-0.5 block">
                Tính bằng sản lượng x đơn giá
              </span>
            </div>

            <div className="p-3 bg-emerald-500/5 border border-emerald-500/10 rounded-xl relative overflow-hidden">
              <span className="text-[10px] font-bold text-slate-500 block uppercase">Biên lợi nhuận ròng</span>
              <strong className="text-emerald-400 text-lg font-mono font-black block mt-0.5">
                {calculatorResults.totalProfit > 0 ? "+" : ""}
                {calculatorResults.totalProfit.toLocaleString()}đ
              </strong>
              <div className="absolute right-2 bottom-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[9px] font-black font-mono px-1.5 py-0.5 rounded-lg">
                ROI: {calculatorResults.roi.toFixed(1)}%
              </div>
            </div>

          </div>

        </div>

        {/* Real-time Financial Ledger (Recent Transactions) */}
        <div className="lg:col-span-2 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800/60 pb-4 mb-4">
              <h3 className="text-xs font-black text-slate-100 uppercase tracking-wider">Lịch sử Giao dịch & Phát sinh</h3>
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            </div>

            <div className="space-y-3">
              {INITIAL_TRANSACTIONS.map((tx) => (
                <div key={tx.id} className="p-3 bg-slate-950/80 border border-slate-900 hover:border-slate-850 rounded-xl transition-all flex items-start gap-3">
                  <div className={`p-1.5 rounded-lg shrink-0 ${
                    tx.type === "income" 
                      ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                      : "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                  }`}>
                    {tx.type === "income" ? (
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    ) : (
                      <ArrowDownRight className="w-3.5 h-3.5" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1 space-y-0.5">
                    <div className="flex items-center justify-between gap-2">
                      <strong className="text-[10.5px] font-bold text-slate-200 block truncate">{tx.description}</strong>
                      <span className={`text-[10.5px] font-mono font-black shrink-0 ${
                        tx.type === "income" ? "text-emerald-400" : "text-rose-400"
                      }`}>
                        {tx.type === "income" ? "+" : ""}
                        {tx.amount.toLocaleString()}đ
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[9px] text-slate-500">
                      <span>Mã: {tx.id} • {tx.crop}</span>
                      <span className="font-medium">{tx.time}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button className="w-full mt-4 py-2 bg-slate-950 hover:bg-slate-900 text-[10px] font-black uppercase text-sky-400 tracking-wider border border-slate-850 hover:border-slate-800 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5">
            <Plus className="w-3.5 h-3.5" />
            Lập phiếu Thu / Chi mới
          </button>
        </div>

      </div>

    </div>
  );
}
