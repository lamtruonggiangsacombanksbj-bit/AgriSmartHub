import React, { useState, useMemo } from "react";
import { parseCSV } from "../utils/csvParser";
import { productionYieldCSV, farmMonitoringCSV, weatherCSV } from "../data/datasets";
import { getCorrelationMatrix, MinMaxScaler, StandardScaler, LabelEncoder } from "../utils/ml";
import { Hammer, Shuffle, Sliders, Hash, HelpCircle, Layers, CheckCircle } from "lucide-react";

export default function DataPreprocessing() {
  const [activeScaler, setActiveScaler] = useState<"minmax" | "standard">("minmax");
  const [selectedCorrGroup, setSelectedCorrGroup] = useState<"yield" | "weather">("yield");

  // Load and parse real datasets
  const yieldData = useMemo(() => parseCSV(productionYieldCSV), []);
  const monitoringData = useMemo(() => parseCSV(farmMonitoringCSV), []);
  const weatherData = useMemo(() => parseCSV(weatherCSV), []);

  // Compute Correlation Matrices dynamically
  const correlationFeatures = useMemo(() => {
    if (selectedCorrGroup === "yield") {
      return ["Quantity_Ton", "Unit_Price_VND", "Revenue_VND", "Cost_VND", "Profit_VND", "ESG_Score"];
    } else {
      return ["Area_Ha", "Soil_Moisture_%", "Temperature_C", "Humidity_%", "Rainfall_mm", "Yield_Ton"];
    }
  }, [selectedCorrGroup]);

  // For the weather group, let's join monitoringData with weatherData by Farm_ID
  const joinedData = useMemo(() => {
    if (selectedCorrGroup === "yield") return yieldData;
    
    // Join farms and weather
    const joined: Record<string, any>[] = [];
    monitoringData.forEach((farm) => {
      const weatherRows = weatherData.filter((w) => w.Farm_ID === farm.Farm_ID);
      weatherRows.forEach((w) => {
        joined.push({
          ...farm,
          ...w,
          Yield_Ton: farm.Yield_Ton, // Ensure this column is mapped correctly
        });
      });
    });
    return joined;
  }, [selectedCorrGroup, yieldData, monitoringData, weatherData]);

  const corrMatrix = useMemo(() => {
    if (joinedData.length === 0) return {};
    return getCorrelationMatrix(joinedData, correlationFeatures);
  }, [joinedData, correlationFeatures]);

  // Scaler Interactive Demo data
  const originalScalerData = useMemo(() => {
    return yieldData.slice(0, 5).map((d) => ({
      ID: d.Production_ID,
      Quantity: d.Quantity_Ton,
      Profit: d.Profit_VND,
    }));
  }, [yieldData]);

  const scaledData = useMemo(() => {
    if (yieldData.length === 0) return [];
    const feats = ["Quantity_Ton", "Profit_VND"];
    
    if (activeScaler === "minmax") {
      const scaler = new MinMaxScaler();
      scaler.fit(yieldData, feats);
      return yieldData.slice(0, 5).map((d) => {
        const scaled = scaler.transform(d, feats);
        return {
          ID: d.Production_ID,
          Quantity: Number(scaled.Quantity_Ton.toFixed(4)),
          Profit: Number(scaled.Profit_VND.toFixed(4)),
        };
      });
    } else {
      const scaler = new StandardScaler();
      scaler.fit(yieldData, feats);
      return yieldData.slice(0, 5).map((d) => {
        const scaled = scaler.transform(d, feats);
        return {
          ID: d.Production_ID,
          Quantity: Number(scaled.Quantity_Ton.toFixed(4)),
          Profit: Number(scaled.Profit_VND.toFixed(4)),
        };
      });
    }
  }, [yieldData, activeScaler]);

  // Label Encoder Demo data
  const originalEncoderData = ["Lúa", "Cà phê", "Sầu riêng", "Xoài", "Thanh long"];
  const encodedDemo = useMemo(() => {
    const mockData = originalEncoderData.map((c) => ({ Crop: c }));
    const encoder = new LabelEncoder();
    encoder.fit(mockData, ["Crop"]);
    return originalEncoderData.map((c) => ({
      original: c,
      encoded: encoder.transform({ Crop: c }, ["Crop"]).Crop,
    }));
  }, []);

  const getHeatmapColor = (val: number) => {
    if (val === 1) return "bg-sky-600 text-white";
    if (val > 0.7) return "bg-sky-500/80 text-white";
    if (val > 0.4) return "bg-sky-500/40 text-sky-200 border border-sky-500/10";
    if (val > 0.1) return "bg-sky-500/10 text-sky-400 border border-sky-500/20";
    if (val > -0.1) return "bg-slate-950 text-slate-400 border border-slate-800";
    if (val > -0.4) return "bg-rose-500/10 text-rose-400 border border-rose-500/20";
    if (val > -0.7) return "bg-rose-500/40 text-rose-200";
    return "bg-rose-600 text-white";
  };

  return (
    <div id="data-preprocessing-root" className="space-y-6">
      {/* Overview and Pipeline banner */}
      <div className="bg-slate-900 border border-slate-800 text-slate-200 p-6 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-3xl">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Hammer className="w-6 h-6 text-sky-400 animate-pulse" />
            Quy trình Tiền xử lý & Trích xuất Đặc trưng (Data Pipeline)
          </h2>
          <p className="text-slate-400 text-xs leading-relaxed">
            Trước khi đưa dữ liệu nông nghiệp vào học máy, chúng tôi thiết kế và vận hành các bước xử lý dữ liệu tự động bao gồm: Điền khuyết dữ liệu (Imputation), Mã hóa biến phân loại (Encoding), Chuẩn hóa dải trị (Scaling) và Phân tích tương quan Pearson để loại bỏ đặc trưng nhiễu.
          </p>
        </div>
        <div className="bg-green-500/10 p-4 rounded-xl border border-green-500/20 text-center min-w-[150px]">
          <span className="text-green-400 text-xs block uppercase font-bold tracking-wider">Trạng thái Pipeline</span>
          <span className="text-white font-bold text-lg flex items-center justify-center gap-1.5 mt-1">
            <CheckCircle className="w-5 h-5 text-green-500" /> Sẵn sàng
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Step-by-Step Processing Logs */}
        <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-4">
          <h3 className="text-base font-bold text-slate-100 flex items-center gap-2 mb-2">
            <Layers className="w-5 h-5 text-sky-400" />
            Nhật ký Tiền xử lý Dữ liệu Thực tế (Data Processing Logs)
          </h3>
          
          <div className="space-y-4 relative before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-800">
            {/* Step 1 */}
            <div className="relative pl-8 flex gap-3 text-sm">
              <span className="absolute left-1.5 top-1.5 w-3 h-3 rounded-full bg-sky-500 ring-4 ring-sky-950" />
              <div>
                <h4 className="font-bold text-slate-200">1. Ghép nối & Liên kết (Data Joining)</h4>
                <p className="text-slate-400 text-xs mt-0.5">
                  Đồng bộ hóa 8 bảng dữ liệu gốc theo các khóa ngoại: <code>Farm_ID</code>, <code>Farmer_ID</code>, và <code>Production_ID</code>. Tạo bảng thuộc tính tổng hợp lưu trữ lịch sử chăm sóc, thời tiết và sản lượng.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="relative pl-8 flex gap-3 text-sm">
              <span className="absolute left-1.5 top-1.5 w-3 h-3 rounded-full bg-sky-500 ring-4 ring-sky-950" />
              <div>
                <h4 className="font-bold text-slate-200">2. Khử khuyết & Làm sạch (Null Value Imputation)</h4>
                <p className="text-slate-400 text-xs mt-0.5">
                  Phát hiện cột trống (như <code>Customer_Rating</code> trong Đơn hàng). Thực hiện kỹ thuật Median-Imputation dựa trên nhóm <code>Crop</code> để tránh phân phối bị lệch, thay vì loại bỏ gây mất mát mẫu dữ liệu.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="relative pl-8 flex gap-3 text-sm">
              <span className="absolute left-1.5 top-1.5 w-3 h-3 rounded-full bg-sky-500 ring-4 ring-sky-950" />
              <div>
                <h4 className="font-bold text-slate-200">3. Mã hóa Danh mục (Categorical Encoding)</h4>
                <p className="text-slate-400 text-xs mt-0.5">
                  Mã hóa biến danh mục phi số như <code>Crop</code> và <code>Province</code> thành các nhãn số nguyên (Label Encoding) hoặc ma trận nhị phân (One-Hot Encoding) để các thuật toán tuyến tính và phi tuyến có thể tính toán được.
                </p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="relative pl-8 flex gap-3 text-sm">
              <span className="absolute left-1.5 top-1.5 w-3 h-3 rounded-full bg-sky-500 ring-4 ring-sky-950" />
              <div>
                <h4 className="font-bold text-slate-200">4. Phân tách Dữ liệu (Train-Test Splitting)</h4>
                <p className="text-slate-400 text-xs mt-0.5">
                  Xáo trộn ngẫu nhiên và phân tách dữ liệu theo tỉ lệ tối ưu (mặc định 80% để Huấn luyện và 20% độc lập để Đánh giá/Kiểm thử) nhằm phát hiện và ngăn chặn hiện tượng Overfitting (quá khớp).
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Correlation Heatmap */}
        <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-3 mb-2">
            <div>
              <h3 className="text-base font-bold text-slate-100">
                Ma trận Tương quan Đặc trưng (Pearson Matrix)
              </h3>
              <p className="text-slate-400 text-xs mt-0.5">Phân tích mối quan hệ tuyến tính giữa các biến số</p>
            </div>
            
            <div className="flex bg-slate-950 p-1.5 rounded-xl border border-slate-800 self-start">
              <button
                id="btn-corr-yield"
                onClick={() => setSelectedCorrGroup("yield")}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  selectedCorrGroup === "yield" ? "bg-slate-900 text-sky-400 shadow-sm" : "text-slate-400 hover:text-slate-200"
                }`}
              >
                Nhóm Tài chính
              </button>
              <button
                id="btn-corr-weather"
                onClick={() => setSelectedCorrGroup("weather")}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  selectedCorrGroup === "weather" ? "bg-slate-900 text-sky-400 shadow-sm" : "text-slate-400 hover:text-slate-200"
                }`}
              >
                Nhóm Môi trường
              </button>
            </div>
          </div>

          {/* Render Heatmap Box Grid */}
          <div className="overflow-x-auto">
            <div className="min-w-[450px]">
              {/* Feature column headers */}
              <div className="grid grid-cols-7 gap-1.5 mb-1 text-center font-bold text-[10px] text-slate-500 uppercase tracking-wider">
                <div className="text-left py-1 text-slate-400 lowercase first-letter:uppercase truncate">Đặc trưng</div>
                {correlationFeatures.map((feat) => (
                  <div key={feat} className="py-1 truncate" title={feat}>
                    {feat.split("_")[0]}
                  </div>
                ))}
              </div>

              {/* Rows */}
              <div className="space-y-1.5">
                {correlationFeatures.map((f1) => (
                  <div key={f1} className="grid grid-cols-7 gap-1.5 items-center">
                    {/* Row Header */}
                    <div className="text-left text-xs font-bold text-slate-400 truncate pr-2" title={f1}>
                      {f1}
                    </div>
                    {/* Matrix Cells */}
                    {correlationFeatures.map((f2) => {
                      const val = corrMatrix[f1]?.[f2] ?? 0;
                      return (
                        <div
                          key={f2}
                          className={`py-3 rounded-lg text-center font-mono text-xs font-bold transition-all hover:scale-105 shadow-sm flex items-center justify-center ${getHeatmapColor(
                            val
                          )}`}
                          title={`Tương quan giữa ${f1} & ${f2} là ${val}`}
                        >
                          {val.toFixed(2)}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="flex gap-4 text-[10px] text-slate-500 font-semibold justify-center pt-2">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-sky-500 inline-block" /> Tương quan dương cao (&gt;0.7)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-slate-950 inline-block border border-slate-800" /> Tương quan yếu (0.0)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-rose-500 inline-block" /> Tương quan âm (&lt;-0.4)
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Interactive Scaler Sandbox */}
        <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-2">
            <div>
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Sliders className="w-5 h-5 text-sky-400" />
                Chuẩn hóa biến số (Feature Scaling Sandbox)
              </h3>
              <p className="text-slate-400 text-xs mt-0.5">Xử lý chênh lệch biên độ số lớn và nhỏ trước khi đưa vào ML</p>
            </div>
            
            <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
              <button
                id="btn-scaler-minmax"
                onClick={() => setActiveScaler("minmax")}
                className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                  activeScaler === "minmax" ? "bg-slate-900 text-sky-400 shadow-sm" : "text-slate-400 hover:text-slate-200"
                }`}
              >
                MinMax
              </button>
              <button
                id="btn-scaler-standard"
                onClick={() => setActiveScaler("standard")}
                className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                  activeScaler === "standard" ? "bg-slate-900 text-sky-400 shadow-sm" : "text-slate-400 hover:text-slate-200"
                }`}
              >
                Standard (Z-Score)
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* Original Box */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-850">
              <h4 className="text-slate-300 text-xs font-bold mb-3 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-slate-600" /> Dữ liệu gốc
              </h4>
              <div className="space-y-3 font-mono text-xs">
                {originalScalerData.map((d) => (
                  <div key={d.ID} className="flex justify-between border-b border-slate-900 pb-1.5">
                    <span className="text-slate-500 font-bold">{d.ID}</span>
                    <span className="text-slate-300 font-semibold">
                      {d.Quantity}T | {d.Profit.toLocaleString("vi-VN")}đ
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Scaled Box */}
            <div className="bg-sky-950/20 p-4 rounded-xl border border-sky-900/30">
              <h4 className="text-sky-400 text-xs font-bold mb-3 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-sky-500" /> Sau chuẩn hóa
              </h4>
              <div className="space-y-3 font-mono text-xs">
                {scaledData.map((d) => (
                  <div key={d.ID} className="flex justify-between border-b border-sky-900/20 pb-1.5">
                    <span className="text-sky-400 font-bold">{d.ID}</span>
                    <span className="text-sky-200 font-semibold">
                      {d.Quantity} | {d.Profit}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <p className="text-slate-400 text-xs leading-relaxed flex items-start gap-1.5 bg-slate-950 p-3 rounded-xl border border-slate-800/80">
            <HelpCircle className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
            {activeScaler === "minmax" ? (
              <span><strong>Min-Max Scaling:</strong> Áp dụng công thức <code>(x - x_min) / (x_max - x_min)</code> để đưa toàn bộ giá trị biến về khoảng cố định <code>[0, 1]</code>. Thích hợp cho mạng nơ-ron hoặc mô hình khoảng cách (K-Means, KNN).</span>
            ) : (
              <span><strong>Standardization (Z-score Normalization):</strong> Chuyển đổi dữ liệu về phân phối chuẩn có <code>mean = 0</code> và <code>std = 1</code> dựa trên công thức <code>(x - μ) / σ</code>. Thích hợp cho Linear Regression, Logistic Regression, PCA.</span>
            )}
          </p>
        </div>

        {/* Categorical Encoder Sandbox */}
        <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 space-y-4">
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Hash className="w-5 h-5 text-sky-400" />
              Mã hóa biến phân loại (Label Encoding)
            </h3>
            <p className="text-slate-400 text-xs mt-0.5">Chuyển đổi dữ liệu văn bản định danh thành định dạng số học</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Encoder demo listing */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 space-y-2">
              <h4 className="text-slate-300 text-xs font-bold mb-1.5">Chuyển đổi các loại cây trồng (Crop)</h4>
              <div className="space-y-2 font-mono text-xs">
                {encodedDemo.map((item) => (
                  <div key={item.original} className="flex items-center justify-between border-b border-slate-900 pb-1.5">
                    <span className="text-slate-300 font-medium">{item.original}</span>
                    <span className="text-slate-600">➔</span>
                    <span className="text-sky-400 bg-sky-950/50 px-2 py-0.5 rounded-full border border-sky-900/30 font-bold">
                      {item.encoded}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Encoder detailed summary */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-850 flex flex-col justify-between">
              <div>
                <h4 className="text-slate-300 text-xs font-bold mb-2 flex items-center gap-1.5">
                  <Shuffle className="w-4 h-4 text-sky-400" /> Một-Hot (One-Hot Encoding)
                </h4>
                <p className="text-slate-400 text-xs leading-relaxed">
                  Thay vì mã hóa tuần tự từ <code>0</code> đến <code>4</code> (gây ngộ nhận cho mô hình rằng Xoài (3) lớn hơn Lúa (0)), One-Hot sẽ bung <code>Crop</code> thành 5 cột nhị phân:
                </p>
                <div className="bg-slate-900 p-2 rounded-lg border border-slate-800 font-mono text-[9px] text-slate-300 mt-2 space-y-1">
                  <div>Lúa: [1, 0, 0, 0, 0]</div>
                  <div>Cà phê: [0, 1, 0, 0, 0]</div>
                  <div>Sầu riêng: [0, 0, 1, 0, 0]</div>
                </div>
              </div>
            </div>
          </div>

          <p className="text-slate-400 text-xs leading-relaxed flex items-start gap-1.5 bg-slate-950 p-3 rounded-xl border border-slate-800/80">
            <HelpCircle className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
            <span><strong>Nguyên tắc chọn bộ mã hóa:</strong> Áp dụng Label Encoding cho biến phân loại có tính chất thứ bậc (e.g. Cấp độ truy xuất: Standard &lt; Full). Áp dụng One-Hot Encoding cho các biến phi thứ bậc (Cây trồng, Tỉnh thành) để tránh phân biệt mức độ ưu tiên sai lầm.</span>
          </p>
        </div>
      </div>
    </div>
  );
}
