import React, { useState, useMemo } from "react";
import { parseCSV } from "../utils/csvParser";
import { farmMonitoringCSV, farmerCSV } from "../data/datasets";
import {
  Clock,
  Search,
  CheckCircle,
  AlertCircle,
  MapPin,
  RefreshCw,
  Smartphone,
  Eye,
  Activity,
  User,
} from "lucide-react";

interface AttendanceRecord {
  id: string;
  name: string;
  role: string;
  region: string;
  time: string;
  status: "Đúng giờ" | "Muộn" | "Vắng" | "Về sớm";
  location: string;
  photoUrl: string;
  device: string;
  crop: string;
}

const INITIAL_RECORDS: AttendanceRecord[] = [
  {
    id: "1",
    name: "Trần Văn Hùng",
    role: "Cộng tác viên Sầu riêng",
    region: "Bến Tre - Vùng A1",
    time: "07:45",
    status: "Muộn",
    location: "10.2435° N, 106.3751° E",
    photoUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
    device: "Xiaomi Redmi Note 12",
    crop: "Sầu riêng Ri6",
  },
  {
    id: "2",
    name: "Phạm Đức Minh",
    role: "Chủ hộ cà phê liên kết",
    region: "Lâm Đồng - Vùng C3",
    time: "07:15",
    status: "Đúng giờ",
    location: "11.9404° N, 108.4583° E",
    photoUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150",
    device: "iPhone 13 Pro Max",
    crop: "Cà phê Robusta",
  },
  {
    id: "3",
    name: "Lê Hoàng Anh",
    role: "Khảo sát viên thổ nhưỡng",
    region: "Đắk Lắk - Vùng D1",
    time: "11:20",
    status: "Về sớm",
    location: "12.6842° N, 108.0123° E",
    photoUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150",
    device: "Samsung Galaxy S22",
    crop: "Đất trồng tiêu",
  },
  {
    id: "4",
    name: "Nguyễn Thị Mai",
    role: "Cộng tác viên Thu hoạch",
    region: "Tiền Giang - Vùng B2",
    time: "07:02",
    status: "Đúng giờ",
    location: "10.3601° N, 106.3125° E",
    photoUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150",
    device: "Oppo Reno 8",
    crop: "Xoài Cát Hòa Lộc",
  },
  {
    id: "5",
    name: "Vương Đình Trung",
    role: "Kỹ thuật viên sinh học",
    region: "Cần Thơ - Vùng K5",
    time: "07:22",
    status: "Đúng giờ",
    location: "10.0452° N, 105.7469° E",
    photoUrl: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150",
    device: "iPad Air 5",
    crop: "Lúa mùa cao sản",
  }
];

export default function AttendanceScreen() {
  const [records, setRecords] = useState<AttendanceRecord[]>(() => {
    try {
      const cached = localStorage.getItem("agrismart_attendance_records");
      return cached ? JSON.parse(cached) : INITIAL_RECORDS;
    } catch (e) {
      return INITIAL_RECORDS;
    }
  });

  React.useEffect(() => {
    try {
      localStorage.setItem("agrismart_attendance_records", JSON.stringify(records));
    } catch (e) {
      console.error("Failed to save attendance records:", e);
    }
  }, [records]);

  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("Tất cả");
  const [selectedRecord, setSelectedRecord] = useState<AttendanceRecord | null>(null);

  // Parse original farm logs for statistical background info
  const farmLogs = useMemo(() => parseCSV(farmMonitoringCSV), []);
  
  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      const matchesSearch = r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            r.crop.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            r.region.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesFilter = statusFilter === "Tất cả" || r.status === statusFilter;
      return matchesSearch && matchesFilter;
    });
  }, [records, searchQuery, statusFilter]);

  const stats = useMemo(() => {
    const total = records.length;
    const onTime = records.filter(r => r.status === "Đúng giờ").length;
    const late = records.filter(r => r.status === "Muộn" || r.status === "Về sớm").length;
    const absent = records.filter(r => r.status === "Vắng").length;
    return { total, onTime, late, absent };
  }, [records]);

  const handleManualCheckIn = () => {
    const randNames = ["Hoàng Văn Thái", "Nguyễn Hồng Nhung", "Phạm Hải Đăng", "Đỗ Quốc Việt"];
    const randCrops = ["Thanh long ruột đỏ", "Cà phê Arabica", "Sầu riêng Dona", "Bưởi Da Xanh"];
    const randRegions = ["Bình Thuận - Vùng T2", "Đắk Nông - Vùng M4", "Bến Tre - Vùng S1", "Vĩnh Long - Vùng H3"];
    
    const newRecord: AttendanceRecord = {
      id: String(records.length + 1),
      name: randNames[Math.floor(Math.random() * randNames.length)],
      role: "Hộ liên kết vùng trồng",
      region: randRegions[Math.floor(Math.random() * randRegions.length)],
      time: new Date().toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" }),
      status: "Đúng giờ",
      location: "10." + Math.floor(Math.random() * 9000 + 1000) + "° N, 105." + Math.floor(Math.random() * 9000 + 1000) + "° E",
      photoUrl: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150",
      device: "Samsung Knox IoT Client",
      crop: randCrops[Math.floor(Math.random() * randCrops.length)]
    };

    setRecords([newRecord, ...records]);
  };

  return (
    <div id="attendance-screen-root" className="space-y-6">
      {/* 1. Header Row */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-sky-400 text-[10px] font-black uppercase tracking-widest block">Tính năng cốt lõi</span>
          <h2 className="text-slate-100 font-black text-2xl tracking-tight">Nhật ký Chấm công & IoT Thực địa</h2>
          <p className="text-slate-400 text-xs mt-0.5">Theo dõi lịch trình trực tiếp, tọa độ check-in GPS và ảnh xác thực sinh trắc học của CTV vùng trồng</p>
        </div>
        
        <div className="flex items-center gap-3">
          <button
            onClick={() => setRecords(INITIAL_RECORDS)}
            className="p-2.5 bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800/80 rounded-xl text-xs flex items-center gap-1.5 transition-all cursor-pointer"
            title="Khôi phục mặc định"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          
          <button
            onClick={handleManualCheckIn}
            className="bg-indigo-600 hover:bg-indigo-500 text-slate-100 font-bold py-2.5 px-4 rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-lg shadow-indigo-950/40 cursor-pointer active:scale-95"
          >
            <Clock className="w-4 h-4" />
            <span>Mô phỏng Check-in tức thì</span>
          </button>
        </div>
      </div>

      {/* 2. Visual Stats Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex items-center gap-4">
          <div className="p-3 bg-slate-950 text-indigo-400 rounded-xl border border-slate-800">
            <User className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Ghi nhận hôm nay</span>
            <span className="text-xl font-black text-slate-100 font-mono">{stats.total} nhân sự</span>
          </div>
        </div>

        <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex items-center gap-4">
          <div className="p-3 bg-slate-950 text-emerald-400 rounded-xl border border-slate-800">
            <CheckCircle className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Đúng giờ</span>
            <span className="text-xl font-black text-emerald-400 font-mono">{stats.onTime}</span>
          </div>
        </div>

        <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex items-center gap-4">
          <div className="p-3 bg-slate-950 text-amber-400 rounded-xl border border-slate-800">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Đi trễ / Về sớm</span>
            <span className="text-xl font-black text-amber-400 font-mono">{stats.late}</span>
          </div>
        </div>

        <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex items-center gap-4">
          <div className="p-3 bg-slate-950 text-rose-400 rounded-xl border border-slate-800">
            <AlertCircle className="w-5 h-5" />
          </div>
          <div>
            <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Vắng mặt</span>
            <span className="text-xl font-black text-rose-400 font-mono">{stats.absent}</span>
          </div>
        </div>
      </div>

      {/* 3. Main Data Area */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        
        {/* Left: Interactive list of attendance */}
        <div className="xl:col-span-2 space-y-4">
          {/* Controls bar */}
          <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 flex flex-col sm:flex-row gap-3 justify-between items-center">
            <div className="relative w-full sm:w-72">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Tìm tên, vùng trồng, nông sản..."
                className="w-full bg-slate-950 border border-slate-800/80 rounded-xl pl-10 pr-4 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 placeholder:text-slate-700"
              />
            </div>

            <div className="flex gap-1.5 w-full sm:w-auto">
              {["Tất cả", "Đúng giờ", "Muộn", "Về sớm"].map((filter) => (
                <button
                  key={filter}
                  onClick={() => setStatusFilter(filter)}
                  className={`flex-1 sm:flex-initial px-3 py-1.5 rounded-lg text-[10px] font-bold border transition-colors ${
                    statusFilter === filter
                      ? "bg-indigo-600 text-white border-indigo-500"
                      : "bg-slate-950 text-slate-400 border-slate-800 hover:border-slate-700 hover:text-slate-200"
                  }`}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          {/* List/Table */}
          <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950/40 text-slate-400 text-[10px] font-black uppercase tracking-wider">
                    <th className="py-4 px-5">Nhân sự & Vùng</th>
                    <th className="py-4 px-5">Thời gian</th>
                    <th className="py-4 px-5">Trạng thái</th>
                    <th className="py-4 px-5">Cây trồng chính</th>
                    <th className="py-4 px-5 text-right">Chi tiết</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-xs">
                  {filteredRecords.length > 0 ? (
                    filteredRecords.map((r) => (
                      <tr
                        key={r.id}
                        className="hover:bg-slate-800/35 transition-colors cursor-pointer"
                        onClick={() => setSelectedRecord(r)}
                      >
                        <td className="py-4 px-5 flex items-center gap-3">
                          <img
                            src={r.photoUrl}
                            alt={r.name}
                            className="w-8 h-8 rounded-lg object-cover ring-2 ring-indigo-500/10"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <span className="font-bold text-slate-200 block">{r.name}</span>
                            <span className="text-[10px] text-slate-500 block">{r.region}</span>
                          </div>
                        </td>
                        <td className="py-4 px-5">
                          <div className="font-semibold text-slate-300">{r.time}</div>
                          <span className="text-[9px] text-slate-600">Đăng ký vân tay IoT</span>
                        </td>
                        <td className="py-4 px-5">
                          <span className={`inline-block text-[9px] px-2 py-0.5 rounded-full font-extrabold tracking-wider ${
                            r.status === "Đúng giờ"
                              ? "bg-emerald-950/60 text-emerald-400 border border-emerald-900/40"
                              : r.status === "Muộn"
                              ? "bg-amber-950/60 text-amber-400 border border-amber-900/40"
                              : "bg-rose-950/60 text-rose-400 border border-rose-900/40"
                          }`}>
                            {r.status.toUpperCase()}
                          </span>
                        </td>
                        <td className="py-4 px-5 font-medium text-slate-400">
                          {r.crop}
                        </td>
                        <td className="py-4 px-5 text-right">
                          <button className="text-indigo-400 hover:text-indigo-300 p-1 bg-indigo-500/5 hover:bg-indigo-500/10 rounded-lg transition-all">
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={5} className="text-center py-10 text-slate-500">
                        Không tìm thấy bản ghi chấm công nào phù hợp.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right: Detailed sidebar preview */}
        <div className="xl:col-span-1">
          {selectedRecord ? (
            <div className="bg-slate-900 rounded-2xl border border-slate-800 p-6 space-y-6 sticky top-24">
              <div className="flex items-center gap-4">
                <img
                  src={selectedRecord.photoUrl}
                  alt={selectedRecord.name}
                  className="w-16 h-16 rounded-2xl object-cover ring-4 ring-indigo-500/20 shrink-0"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h4 className="font-extrabold text-slate-100 text-base">{selectedRecord.name}</h4>
                  <span className="text-xs text-indigo-400 font-semibold">{selectedRecord.role}</span>
                  <div className="mt-1.5">
                    <span className={`inline-block text-[9px] px-2 py-0.5 rounded-full font-extrabold tracking-wider ${
                      selectedRecord.status === "Đúng giờ"
                        ? "bg-emerald-950/60 text-emerald-400 border border-emerald-900/40"
                        : "bg-amber-950/60 text-amber-400 border border-amber-900/40"
                    }`}>
                      {selectedRecord.status.toUpperCase()}
                    </span>
                  </div>
                </div>
              </div>

              <hr className="border-slate-800/80" />

              <div className="space-y-4 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Khu vực quản lý:</span>
                  <span className="text-slate-300 font-bold text-right">{selectedRecord.region}</span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 font-medium">Mã thiết bị đăng ký:</span>
                  <span className="text-slate-300 font-mono flex items-center gap-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-slate-500" />
                    {selectedRecord.device}
                  </span>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-slate-500 font-medium">Định vị GPS thực địa:</span>
                  <span className="text-indigo-400 font-mono text-[11px] flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5" />
                    {selectedRecord.location}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Thời gian check-in:</span>
                  <span className="text-slate-300 font-bold">{selectedRecord.time}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-slate-500 font-medium">Nông sản thu mua chính:</span>
                  <span className="text-slate-300 font-bold">{selectedRecord.crop}</span>
                </div>
              </div>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2.5">
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest block">Chỉ số cảm biến trạm IoT của Hộ</span>
                <div className="grid grid-cols-2 gap-3 text-center">
                  <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800/40">
                    <span className="text-[10px] text-slate-500 block">Độ ẩm đất</span>
                    <span className="text-sm font-extrabold text-sky-400 font-mono">74.2%</span>
                  </div>
                  <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800/40">
                    <span className="text-[10px] text-slate-500 block">Lượng mưa</span>
                    <span className="text-sm font-extrabold text-blue-400 font-mono">12.5mm</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setSelectedRecord(null)}
                className="w-full bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 py-2.5 border border-slate-800 hover:border-slate-700 transition-all text-xs font-bold rounded-xl cursor-pointer"
              >
                Đóng bảng chi tiết
              </button>
            </div>
          ) : (
            <div className="bg-slate-900/50 rounded-2xl border border-slate-800/60 p-8 text-center h-[280px] flex flex-col justify-center items-center space-y-3">
              <div className="p-3 bg-slate-900 text-slate-600 rounded-2xl border border-slate-800">
                <Activity className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-slate-300 text-xs uppercase tracking-wider">Thông tin GPS / Sinh trắc học</h4>
                <p className="text-slate-500 text-[11px] max-w-[200px] mx-auto mt-1 leading-normal">
                  Vui lòng click một bản ghi chấm công bên cạnh để kiểm tra tọa độ GPS và ảnh đối chiếu.
                </p>
              </div>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
