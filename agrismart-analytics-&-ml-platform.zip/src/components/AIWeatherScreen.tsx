import React, { useState, useMemo } from "react";
import { 
  CloudRain, 
  Sun, 
  Thermometer, 
  Droplets, 
  Wind, 
  Sparkles, 
  Bot, 
  Send,
  AlertTriangle,
  Compass,
  CheckCircle2,
  Bug
} from "lucide-react";

interface WeatherMetric {
  title: string;
  value: string;
  desc: string;
  icon: any;
  colorClass: string;
}

interface ChatMessage {
  id: string;
  sender: "user" | "bot";
  text: string;
  time: string;
}

export default function AIWeatherScreen() {
  const [selectedRegion, setSelectedRegion] = useState("Mekong");
  
  // Custom Weather presets per region
  const weatherPresets = {
    Mekong: { temp: 31, humidity: 82, rainChance: 70, windSpeed: 12, npk: "N: 82, P: 45, K: 68", soilMoisture: 68 },
    TayNguyen: { temp: 26, humidity: 75, rainChance: 40, windSpeed: 18, npk: "N: 60, P: 58, K: 75", soilMoisture: 55 },
    DongNai: { temp: 29, humidity: 78, rainChance: 60, windSpeed: 10, npk: "N: 74, P: 50, K: 70", soilMoisture: 62 },
  };

  const activeWeather = weatherPresets[selectedRegion as keyof typeof weatherPresets] || weatherPresets.Mekong;

  // Pest and disease risk forecasting algorithm based on weather metrics
  const pestRiskForecast = useMemo(() => {
    const { temp, humidity, rainChance, soilMoisture } = activeWeather;
    
    const risks = [
      {
        name: "Nấm nứt thân xì mủ (Phytophthora) ở sầu riêng",
        riskLevel: (humidity > 80 && soilMoisture > 65) ? "Nguy cơ Rất Cao" : "Nguy cơ Trung Bình",
        recommendation: "Hạn chế tưới gốc, tăng cường bón vôi nông nghiệp và quét Bordeaux xung quanh thân cây.",
        severity: (humidity > 80 && soilMoisture > 65) ? "high" : "medium"
      },
      {
        name: "Sâu đục thân, sâu cuốn lá hại lúa vụ Hè Thu",
        riskLevel: (temp > 30 && humidity > 70) ? "Nguy cơ Rất Cao" : "Nguy cơ Thấp",
        recommendation: "Bố trí bẫy đèn sinh học vào ban đêm, ngắt bớt bẹ lá héo và phun thuốc sinh học BT.",
        severity: (temp > 30 && humidity > 70) ? "high" : "low"
      },
      {
        name: "Bọ xít muỗi phá hoại đọt non cây cà phê",
        riskLevel: (temp < 28 && humidity > 70 && rainChance > 50) ? "Nguy cơ Rất Cao" : "Nguy cơ Thấp",
        recommendation: "Tỉa cành tạo tán thông thoáng, làm sạch cỏ dại xung quanh gốc rễ.",
        severity: (temp < 28 && humidity > 70 && rainChance > 50) ? "high" : "low"
      }
    ];

    return risks;
  }, [activeWeather]);

  // Simulated AI Chat
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: "1", sender: "bot", text: "Xin chào! Tôi là Trợ lý AI Nông nghiệp thông minh AgriSmart. Hãy hỏi tôi về tình hình sâu bệnh, thời tiết canh tác hoặc cách tối ưu hóa phân bón sầu riêng.", time: "08:00" }
  ]);
  const [inputText, setInputText] = useState("");

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const userMsg: ChatMessage = {
      id: String(Date.now()),
      sender: "user",
      text: inputText,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText("");

    // Generate responsive agricultural advisory answers based on questions
    setTimeout(() => {
      let botAnswer = "Mô hình AI đang phân tích câu hỏi của bạn. Khuyên bạn nên kiểm tra độ ẩm vùng sầu riêng (hiện tại " + activeWeather.soilMoisture + "%) và nồng độ Nitơ để có hướng bón phân vi sinh bổ trợ.";
      const textLower = userMsg.text.toLowerCase();
      
      if (textLower.includes("sầu riêng") || textLower.includes("sau rieng")) {
        botAnswer = "Đối với sầu riêng vùng này, hiện độ ẩm đất đạt " + activeWeather.soilMoisture + "%. Khuyến cáo: rải lân hữu cơ vi sinh định kỳ cách 15 ngày, chú ý kiểm tra bọ trĩ phá hoại hoa và đọt non sầu riêng.";
      } else if (textLower.includes("thời tiết") || textLower.includes("thoi tiet") || textLower.includes("mưa")) {
        botAnswer = "Dự báo khu vực của bạn có tỷ lệ mưa khoảng " + activeWeather.rainChance + "%, nhiệt độ " + activeWeather.temp + "°C. Hãy chủ động điều chỉnh lịch tưới nhỏ giọt tự động trên app để tiết kiệm nước tưới tiêu.";
      } else if (textLower.includes("cà phê") || textLower.includes("ca phe")) {
        botAnswer = "Canh tác cà phê Lâm Đồng trong thời tiết này cần duy trì độ ẩm từ 50-60%. Chú ý đề phòng nấm hồng và rệp sáp phá hoại cuống quả khi bước vào mùa mưa dầm.";
      } else if (textLower.includes("lúa") || textLower.includes("lua")) {
        botAnswer = "Lúa mùa cao sản đang trong giai đoạn đẻ nhánh rộ. Hãy bón phân NPK cân đối tỷ lệ N:P:K là " + activeWeather.npk + " để lúa đứng cây, đẻ nhánh khỏe và hạn chế đổ ngã khi giông gió.";
      }

      setMessages((prev) => [...prev, {
        id: String(Date.now() + 1),
        sender: "bot",
        text: botAnswer,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
    }, 1000);
  };

  return (
    <div className="space-y-6 text-slate-200">
      
      {/* Title Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900/40 p-5 rounded-2xl border border-slate-800/60 backdrop-blur-md">
        <div>
          <h2 className="text-xl font-black text-slate-100 flex items-center gap-2.5 uppercase tracking-tight">
            <span className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20">
              <Bot className="w-5 h-5" />
            </span>
            Hệ thống Công nghệ AI & Dự báo thời tiết nông nghiệp
          </h2>
          <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
            Mô hình kết hợp dữ liệu khí tượng vi khí hậu thời gian thực, cảm biến IoT thổ nhưỡng và trợ lý ảo AI để tư vấn kỹ thuật trực quan cho nhà vườn.
          </p>
        </div>
        
        {/* Region Selector dropdown */}
        <div className="flex items-center gap-3 shrink-0">
          <span className="text-xs font-bold text-slate-400">Chọn Khu vực:</span>
          <select 
            value={selectedRegion}
            onChange={(e) => setSelectedRegion(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl py-1.5 px-3 text-xs font-black text-slate-200 outline-none cursor-pointer focus:border-sky-500 transition-colors"
          >
            <option value="Mekong">Vùng Đồng Bằng Sông Cửu Long</option>
            <option value="TayNguyen">Vùng Cao Nguyên Lâm Đồng</option>
            <option value="DongNai">Vùng Đông Nam Bộ - Đồng Nai</option>
          </select>
        </div>
      </div>

      {/* Weather details widgets */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 flex items-center gap-4">
          <div className="p-3 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-xl shrink-0">
            <Thermometer className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Nhiệt độ vi khí hậu</span>
            <strong className="text-lg text-slate-100 font-mono font-black">{activeWeather.temp}°C</strong>
            <span className="text-[9px] text-slate-400 block mt-0.5">Thời gian thực qua vệ tinh</span>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 flex items-center gap-4">
          <div className="p-3 bg-sky-500/10 border border-sky-500/20 text-sky-400 rounded-xl shrink-0">
            <Droplets className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Độ ẩm tương đối (RH)</span>
            <strong className="text-lg text-slate-100 font-mono font-black">{activeWeather.humidity}%</strong>
            <span className="text-[9px] text-slate-400 block mt-0.5">Độ ẩm đất rễ: {activeWeather.soilMoisture}%</span>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 flex items-center gap-4">
          <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-xl shrink-0">
            <CloudRain className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Khả năng có mưa giông</span>
            <strong className="text-lg text-slate-100 font-mono font-black">{activeWeather.rainChance}%</strong>
            <span className="text-[9px] text-emerald-400 block mt-0.5">Khuyến cáo che phủ gốc hoa</span>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 flex items-center gap-4">
          <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-xl shrink-0">
            <Wind className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Thành phần N-P-K (IoT)</span>
            <strong className="text-xs text-slate-200 font-mono font-black block mt-0.5">{activeWeather.npk}</strong>
            <span className="text-[9px] text-indigo-400 block mt-0.5">Dưỡng chất trong đất cân đối</span>
          </div>
        </div>

      </div>

      {/* Main Grid: AI Pest advisory & Chat assistant */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        
        {/* Pest and disease early warning forecasts */}
        <div className="lg:col-span-3 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800/60 pb-3 mb-4">
              <h3 className="text-xs font-black text-slate-100 uppercase tracking-wider flex items-center gap-2">
                <Bug className="w-4 h-4 text-rose-400" />
                Dự báo AI Sâu bệnh & Chỉ dẫn an toàn thực vật
              </h3>
              <span className="px-2 py-0.5 bg-rose-500/15 text-rose-400 border border-rose-500/20 rounded text-[9px] font-mono font-bold animate-pulse">Cảnh báo sâu</span>
            </div>

            <div className="space-y-4">
              {pestRiskForecast.map((pest, idx) => (
                <div key={idx} className="p-4 bg-slate-950/70 border border-slate-900 hover:border-slate-850 rounded-2xl transition-all space-y-2">
                  <div className="flex items-center justify-between">
                    <strong className="text-xs font-bold text-slate-200">{pest.name}</strong>
                    <span className={`px-2 py-0.5 rounded text-[8.5px] font-black uppercase tracking-wider ${
                      pest.severity === "high" 
                        ? "bg-rose-500/10 text-rose-400 border border-rose-500/20" 
                        : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                    }`}>
                      {pest.riskLevel}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 leading-relaxed">
                    💡 <strong>Khuyên dùng:</strong> {pest.recommendation}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-slate-950/40 border border-slate-900 p-3 rounded-xl text-center text-[9px] text-slate-500 mt-4 leading-relaxed">
            * Khuyến cáo sử dụng thuốc bảo vệ thực vật sinh học thân thiện với môi trường, hạn chế thuốc hóa học để đạt chuẩn xuất khẩu EU và Mỹ.
          </div>
        </div>

        {/* Dynamic Interactive AI Advisory Chat */}
        <div className="lg:col-span-2 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl flex flex-col h-[420px]">
          <div className="flex items-center gap-2.5 border-b border-slate-800/60 pb-3 mb-3">
            <div className="p-1.5 bg-indigo-500/15 text-indigo-400 rounded-xl">
              <Sparkles className="w-4 h-4 animate-spin text-indigo-400" style={{ animationDuration: '4s' }} />
            </div>
            <div>
              <h3 className="text-xs font-black text-slate-100 uppercase tracking-wider">Trợ lý ảo Nông nghiệp AgriSmart</h3>
              <span className="text-[8.5px] text-emerald-400 font-bold block">Mô hình GPT-4o tinh chỉnh sầu riêng</span>
            </div>
          </div>

          {/* Message List */}
          <div className="flex-1 overflow-y-auto space-y-3 custom-scrollbar pr-1.5 text-xs mb-3">
            {messages.map((m) => {
              const isBot = m.sender === "bot";
              return (
                <div key={m.id} className={`flex flex-col ${isBot ? 'items-start' : 'items-end'}`}>
                  <div className={`max-w-[85%] p-3 rounded-2xl leading-relaxed ${
                    isBot 
                      ? "bg-slate-950/80 border border-slate-900 text-slate-200 rounded-tl-none" 
                      : "bg-indigo-600 text-slate-100 rounded-tr-none"
                  }`}>
                    {m.text}
                  </div>
                  <span className="text-[8px] text-slate-500 mt-1 block px-1">{m.time}</span>
                </div>
              );
            })}
          </div>

          {/* Input Chat form */}
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <input
              type="text"
              placeholder="Hỏi về bón phân sầu riêng, bệnh lúa..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 outline-none focus:border-indigo-500 placeholder-slate-600"
            />
            <button
              type="submit"
              className="p-2 bg-indigo-600 hover:bg-indigo-500 rounded-xl text-white transition-all cursor-pointer shadow flex items-center justify-center shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>

      </div>

    </div>
  );
}
