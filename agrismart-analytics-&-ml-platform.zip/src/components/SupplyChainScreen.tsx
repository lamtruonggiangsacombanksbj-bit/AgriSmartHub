import React, { useState, useMemo } from "react";
import { 
  Truck, 
  MapPin, 
  Search, 
  QrCode, 
  CheckCircle2, 
  Clock, 
  ExternalLink,
  ShieldCheck,
  Globe2,
  Calendar,
  AlertCircle
} from "lucide-react";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from "recharts";

interface Shipment {
  id: string;
  cropName: string;
  destination: string;
  quantityTons: number;
  temperature: number; // °C cold chain
  status: "packed" | "customs" | "shipping" | "delivered";
  eta: string;
}

const INITIAL_SHIPMENTS: Shipment[] = [
  { id: "EXP-9001", cropName: "Sầu riêng Dona", destination: "Quảng Châu (Trung Quốc)", quantityTons: 18.2, temperature: 4.5, status: "shipping", eta: "03/07/2026" },
  { id: "EXP-9002", cropName: "Cà phê Robusta", destination: "Hải Phòng -> Hamburg (Đức)", quantityTons: 25.0, temperature: 18.0, status: "customs", eta: "15/07/2026" },
  { id: "EXP-9003", cropName: "Lúa mùa ST25", destination: "Thành phố Hồ Chí Minh -> Osaka (Nhật Bản)", quantityTons: 50.0, temperature: 22.0, status: "delivered", eta: "Hôm qua" },
  { id: "EXP-9004", cropName: "Sầu riêng Ri6", destination: "Cửa khẩu Hữu Nghị -> Nam Ninh", quantityTons: 15.4, temperature: 4.2, status: "packed", eta: "05/07/2026" },
];

export default function SupplyChainScreen() {
  const [shipments, setShipments] = useState<Shipment[]>(INITIAL_SHIPMENTS);
  const [traceLotId, setTraceLotId] = useState("EXP-9001");
  
  // Traceability database simulation
  const traceDetails = useMemo(() => {
    const found = shipments.find((s) => s.id === traceLotId) || shipments[0];
    return {
      ...found,
      farm: "Hợp tác xã sầu riêng Bến Tre - Tổ liên kết số 3",
      harvestDate: "2026-06-25",
      phValue: "6.2",
      npkLog: "Phân bón hữu cơ vi lượng đợt 3",
      packDate: "2026-06-26",
      packer: "Trần Văn Hùng",
      globalGAPId: "GG-405-9201-830",
    };
  }, [traceLotId, shipments]);

  const exportMarketsData = [
    { name: "Trung Quốc", volume: 185 },
    { name: "Nhật Bản", volume: 65 },
    { name: "Hoa Kỳ", volume: 92 },
    { name: "Liên minh Châu Âu", volume: 110 },
    { name: "Đông Nam Á", volume: 45 },
  ];

  const getStatusLabel = (status: Shipment["status"]) => {
    switch (status) {
      case "packed": return { text: "Đã Đóng gói", color: "bg-indigo-500/10 text-indigo-400 border-indigo-500/20" };
      case "customs": return { text: "Thông quan", color: "bg-amber-500/10 text-amber-400 border-amber-500/20" };
      case "shipping": return { text: "Đang Vận chuyển", color: "bg-sky-500/10 text-sky-400 border-sky-500/20 animate-pulse" };
      case "delivered": return { text: "Đã Giao hàng", color: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" };
    }
  };

  return (
    <div className="space-y-6 text-slate-200">
      
      {/* Header Title */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-slate-900/40 p-5 rounded-2xl border border-slate-800/60 backdrop-blur-md">
        <div>
          <h2 className="text-xl font-black text-slate-100 flex items-center gap-2.5 uppercase tracking-tight">
            <span className="p-2 bg-sky-500/10 text-sky-400 rounded-xl border border-sky-500/20">
              <Truck className="w-5 h-5" />
            </span>
            Chuỗi cung ứng & Xuất khẩu liên kết toàn cầu
          </h2>
          <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
            Hệ thống giám sát chuỗi lạnh vận chuyển, thông quan biên giới cửa khẩu, truy xuất nguồn gốc QR và phân tích thị trường tiêu thụ thế giới.
          </p>
        </div>
        <span className="px-3 py-1.5 bg-sky-500/10 border border-sky-500/30 text-[10px] font-black uppercase text-sky-400 rounded-xl block shrink-0">
          Vận tải liên tục
        </span>
      </div>

      {/* Grid of Key Logistics indicators */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 flex items-center gap-4">
          <div className="p-3 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-xl shrink-0">
            <Globe2 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Quốc gia Liên kết Xuất khẩu</span>
            <strong className="text-lg text-slate-100 font-mono font-black">18 Quốc gia</strong>
            <span className="text-[9px] text-indigo-400 block mt-0.5">Thị trường chủ lực: Trung Quốc, EU, Mỹ</span>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 flex items-center gap-4">
          <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-xl shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Đạt chuẩn Kiểm dịch Thực vật</span>
            <strong className="text-lg text-slate-100 font-mono font-black">99.8%</strong>
            <span className="text-[9px] text-emerald-400 block mt-0.5">Không phát hiện tì vết hóa chất</span>
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 flex items-center gap-4">
          <div className="p-3 bg-sky-500/10 border border-sky-500/20 text-sky-400 rounded-xl shrink-0">
            <Truck className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-500 uppercase font-bold block">Đội xe Chuỗi lạnh Hoạt động</span>
            <strong className="text-lg text-slate-100 font-mono font-black">12 Xe bảo ôn</strong>
            <span className="text-[9px] text-sky-400 block mt-0.5">Kiểm soát nhiệt độ 4.0 - 5.5°C liên tục</span>
          </div>
        </div>

      </div>

      {/* Main Shipments Track & Market Volume Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        
        {/* Shipment Tracker Feed */}
        <div className="lg:col-span-3 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="border-b border-slate-800/60 pb-3">
            <h3 className="text-xs font-black text-slate-100 uppercase tracking-wider">Hành trình Container Xuất khẩu Đang lưu thông</h3>
            <p className="text-[10px] text-slate-400 mt-0.5">Định vị GPS thực của các container sầu riêng và nông sản thế giới</p>
          </div>

          <div className="space-y-3">
            {shipments.map((ship) => {
              const status = getStatusLabel(ship.status);
              return (
                <div key={ship.id} className="p-3 bg-slate-950/80 border border-slate-900 rounded-xl flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <strong className="text-slate-200 font-bold">{ship.cropName}</strong>
                      <span className="text-[9px] font-mono font-semibold text-slate-500">Mã: {ship.id}</span>
                    </div>
                    <p className="text-[9px] text-slate-400 flex items-center gap-1.5">
                      <MapPin className="w-3 h-3 text-sky-400 shrink-0" /> {ship.destination}
                    </p>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right space-y-0.5">
                      <span className="text-[10.5px] font-mono font-black text-slate-300 block">{ship.quantityTons} Tấn</span>
                      <span className="text-[9px] text-slate-500 block">Nhiệt độ cont: {ship.temperature}°C</span>
                    </div>

                    <div className="text-right space-y-1">
                      <span className={`inline-block px-2 py-0.5 rounded text-[8.5px] font-black uppercase tracking-wider border ${status?.color}`}>
                        {status?.text}
                      </span>
                      <span className="text-[8.5px] text-slate-500 block">ETA: {ship.eta}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Market Volume Chart */}
        <div className="lg:col-span-2 bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl">
          <div className="border-b border-slate-800/60 pb-3 mb-4">
            <h3 className="text-xs font-black text-slate-100 uppercase tracking-wider">Sản lượng Xuất khẩu lũy kế 2026</h3>
            <p className="text-[10px] text-slate-400">Đơn vị: Tấn (Metric Tons)</p>
          </div>

          <div className="h-56 w-full text-slate-900 text-[10px] font-bold">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={exportMarketsData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis type="number" stroke="#64748b" tick={{ fill: '#94a3b8' }} />
                <YAxis dataKey="name" type="category" stroke="#64748b" tick={{ fill: '#94a3b8' }} width={80} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155' }} labelStyle={{ color: '#fff' }} />
                <Bar dataKey="volume" name="Xuất khẩu" fill="#3b82f6" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* Interactive Traceability QR Code Generator */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl space-y-5">
        
        <div className="flex items-center justify-between border-b border-slate-800/60 pb-3">
          <div className="flex items-center gap-2">
            <QrCode className="w-4 h-4 text-emerald-400" />
            <h3 className="text-xs font-black text-slate-100 uppercase tracking-wider">Trình Tạo & Truy xuất nguồn gốc nông sản (QR Trace)</h3>
          </div>
          <span className="text-[8.5px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/20 font-black">VietGAP & GlobalGAP Cert</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Controls to pick shipment lot */}
          <div className="space-y-4">
            <span className="text-xs font-black text-slate-400 uppercase tracking-wider block">1. Chọn lô nông sản cần kiểm tra</span>
            
            <div className="space-y-2">
              {shipments.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setTraceLotId(s.id)}
                  className={`w-full p-3 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                    traceLotId === s.id 
                      ? 'bg-sky-950/20 border-sky-500 text-sky-400' 
                      : 'bg-slate-950/80 border-slate-900 text-slate-300 hover:bg-slate-900/60'
                  }`}
                >
                  <div className="space-y-0.5">
                    <strong className="text-xs font-bold block">{s.cropName}</strong>
                    <span className="text-[9px] text-slate-500">{s.destination}</span>
                  </div>
                  <span className="text-[10px] font-mono font-black">{s.id}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Trace Certificate Detail view */}
          <div className="bg-slate-950/80 border border-slate-900 rounded-2xl p-4 space-y-3.5 text-xs">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block border-b border-slate-900 pb-2">
              2. Chứng chỉ nguồn gốc Xuất xứ
            </span>

            <div className="space-y-2.5">
              <div className="flex justify-between">
                <span className="text-slate-500">Mã Lô Nông sản:</span>
                <span className="font-mono font-black text-slate-300">{traceDetails.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Hợp tác xã trồng:</span>
                <span className="font-semibold text-slate-300 text-right max-w-[60%] truncate">{traceDetails.farm}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Ngày thu hoạch:</span>
                <span className="font-mono font-semibold text-slate-300">{traceDetails.harvestDate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Mã Chứng chỉ GlobalGAP:</span>
                <span className="font-mono font-black text-emerald-400">{traceDetails.globalGAPId}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Kỹ sư đóng gói:</span>
                <span className="font-semibold text-slate-300">{traceDetails.packer}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Độ pH thổ nhưỡng đất:</span>
                <span className="font-mono font-semibold text-slate-300">{traceDetails.phValue} pH</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Nhật ký bón phân:</span>
                <span className="font-semibold text-sky-400">{traceDetails.npkLog}</span>
              </div>
            </div>
          </div>

          {/* QR visual simulator */}
          <div className="bg-slate-950/80 border border-slate-900 rounded-2xl p-4 flex flex-col items-center justify-center space-y-4 text-center">
            
            <div className="p-3 bg-white rounded-xl shadow-lg border-2 border-slate-300 flex items-center justify-center relative group">
              {/* Mock QR code drawing */}
              <div className="w-32 h-32 bg-slate-900 rounded flex items-center justify-center text-white">
                <QrCode className="w-24 h-24 text-slate-100" />
              </div>
              <div className="absolute inset-0 bg-indigo-600/95 opacity-0 group-hover:opacity-100 transition-all rounded-xl flex items-center justify-center p-3 text-slate-100 text-[10px] font-bold">
                Mã QR đại diện liên kết đến Chuỗi Blockchain truy xuất độc bản
              </div>
            </div>

            <div>
              <span className="text-[10px] text-slate-500 block">Quét mã QR để tải đầy đủ tệp chứng thư số</span>
              <strong className="text-xs text-emerald-400 font-black block mt-1 uppercase tracking-wider flex items-center justify-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Đồng bộ Blockchain chuỗi khối
              </strong>
            </div>

            <button className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-slate-100 font-black text-[10px] uppercase tracking-widest rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer">
              Tải tem QR chống giả dạng PDF
            </button>
          </div>

        </div>

      </div>

    </div>
  );
}
