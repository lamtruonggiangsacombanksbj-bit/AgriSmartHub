import React, { useState, useMemo } from "react";
import { parseCSV } from "../utils/csvParser";
import { farmerCSV } from "../data/datasets";
import {
  Banknote,
  Search,
  Sliders,
  DollarSign,
  TrendingUp,
  Award,
  Wallet,
  CheckCircle,
  HelpCircle,
  Sparkles,
} from "lucide-react";

interface FarmerPayrollRow {
  id: string;
  name: string;
  crop: string;
  province: string;
  yieldTons: number;
  isOrganic: boolean;
  baseSalary: number; // calculated
  esgBonus: number; // calculated
  totalSalary: number; // calculated
}

export default function PayrollScreen() {
  const [search, setSearch] = useState("");
  const [baseDurianRate, setBaseDurianRate] = useState<number>(() => {
    try {
      const cached = localStorage.getItem("agrismart_payroll_durian_rate");
      return cached ? Number(cached) : 70000;
    } catch (e) {
      return 70000;
    }
  });
  const [baseCoffeeRate, setBaseCoffeeRate] = useState<number>(() => {
    try {
      const cached = localStorage.getItem("agrismart_payroll_coffee_rate");
      return cached ? Number(cached) : 45000;
    } catch (e) {
      return 45000;
    }
  });
  const [baseRiceRate, setBaseRiceRate] = useState<number>(() => {
    try {
      const cached = localStorage.getItem("agrismart_payroll_rice_rate");
      return cached ? Number(cached) : 12000;
    } catch (e) {
      return 12000;
    }
  });

  React.useEffect(() => {
    try {
      localStorage.setItem("agrismart_payroll_durian_rate", String(baseDurianRate));
    } catch (e) {
      console.error(e);
    }
  }, [baseDurianRate]);

  React.useEffect(() => {
    try {
      localStorage.setItem("agrismart_payroll_coffee_rate", String(baseCoffeeRate));
    } catch (e) {
      console.error(e);
    }
  }, [baseCoffeeRate]);

  React.useEffect(() => {
    try {
      localStorage.setItem("agrismart_payroll_rice_rate", String(baseRiceRate));
    } catch (e) {
      console.error(e);
    }
  }, [baseRiceRate]);

  // Parse farmers list
  const rawFarmers = useMemo(() => {
    return parseCSV(farmerCSV);
  }, []);

  // Compute payroll list
  const payrollData: FarmerPayrollRow[] = useMemo(() => {
    return rawFarmers.map((f: any) => {
      const isOrganic = f.Adopts_Organic === "Yes";
      const yieldTons = f.Annual_Yield_Tons || 3.5;
      
      // Calculate monthly wage portion based on yield and crop price
      let cropPricePerKg = 25000; // default for others
      if (f.Main_Crop === "Sầu riêng") cropPricePerKg = baseDurianRate;
      else if (f.Main_Crop === "Cà phê") cropPricePerKg = baseCoffeeRate;
      else if (f.Main_Crop === "Lúa") cropPricePerKg = baseRiceRate;

      // Yield tons to kg (e.g. 3.5 tons = 3500 kg). Annual revenue split by 12 months
      const annualProductValue = (yieldTons * 1000) * cropPricePerKg;
      const monthlyProductValue = annualProductValue / 12;
      
      // Farmer base salary is 25% of product value as labor fee
      const baseSalary = Math.round(monthlyProductValue * 0.25);
      
      // ESG bonus if organic: 15% extra
      const esgBonus = isOrganic ? Math.round(baseSalary * 0.15) : 0;
      
      return {
        id: f.Farmer_ID || "F000",
        name: f.Farmer_Name || "Nông dân liên kết",
        crop: f.Main_Crop || "Khác",
        province: f.Province || "Đồng bằng sông Cửu Long",
        yieldTons: yieldTons,
        isOrganic: isOrganic,
        baseSalary,
        esgBonus,
        totalSalary: baseSalary + esgBonus,
      };
    });
  }, [rawFarmers, baseDurianRate, baseCoffeeRate, baseRiceRate]);

  const filteredPayroll = useMemo(() => {
    if (!search) return payrollData;
    return payrollData.filter(
      (p) =>
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        p.id.toLowerCase().includes(search.toLowerCase()) ||
        p.crop.toLowerCase().includes(search.toLowerCase())
    );
  }, [payrollData, search]);

  const stats = useMemo(() => {
    const totalPayout = filteredPayroll.reduce((sum, p) => sum + p.totalSalary, 0);
    const avgSalary = filteredPayroll.length > 0 ? totalPayout / filteredPayroll.length : 0;
    const totalEsgBonuses = filteredPayroll.reduce((sum, p) => sum + p.esgBonus, 0);
    return {
      totalPayout: Math.round(totalPayout),
      avgSalary: Math.round(avgSalary),
      totalEsgBonuses: Math.round(totalEsgBonuses),
    };
  }, [filteredPayroll]);

  return (
    <div id="payroll-screen-root" className="space-y-6">
      {/* 1. Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-sky-400 text-[10px] font-black uppercase tracking-widest block">Quản lý tài chính</span>
          <h2 className="text-slate-100 font-black text-2xl tracking-tight">Chi trả & Bảng lương Nông hộ</h2>
          <p className="text-slate-400 text-xs mt-0.5">Xác định thu nhập, chi trả tiền công thu hoạch kèm trợ giá ESG dựa trên sản lượng thực đong đo</p>
        </div>
      </div>

      {/* 2. Simulation Sliders & Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sliders Card */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-5">
          <h3 className="text-slate-100 font-extrabold text-xs uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-800 pb-3">
            <Sliders className="w-4 h-4 text-sky-400" />
            Trợ giá Thu mua Nông sản (đ/kg)
          </h3>

          <div className="space-y-4 text-xs font-semibold">
            {/* Durian */}
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Sầu riêng Ri6 / Dona:</span>
                <span className="text-sky-400 font-mono">{baseDurianRate.toLocaleString()} đ</span>
              </div>
              <input
                type="range"
                min={40000}
                max={120000}
                step={500}
                value={baseDurianRate}
                onChange={(e) => setBaseDurianRate(Number(e.target.value))}
                className="w-full accent-indigo-500 bg-slate-950 h-1 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            {/* Coffee */}
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Cà phê Robusta chín đỏ:</span>
                <span className="text-sky-400 font-mono">{baseCoffeeRate.toLocaleString()} đ</span>
              </div>
              <input
                type="range"
                min={30000}
                max={90000}
                step={500}
                value={baseCoffeeRate}
                onChange={(e) => setBaseCoffeeRate(Number(e.target.value))}
                className="w-full accent-indigo-500 bg-slate-950 h-1 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            {/* Rice */}
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Lúa hữu cơ cao sản:</span>
                <span className="text-sky-400 font-mono">{baseRiceRate.toLocaleString()} đ</span>
              </div>
              <input
                type="range"
                min={80000 / 10}
                max={25000}
                step={100}
                value={baseRiceRate}
                onChange={(e) => setBaseRiceRate(Number(e.target.value))}
                className="w-full accent-indigo-500 bg-slate-950 h-1 rounded-lg appearance-none cursor-pointer"
              />
            </div>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-850 text-[10px] leading-relaxed text-slate-500">
            * Thu nhập thực tế được mô phỏng theo tỷ trọng 25% giá trị nông sản quy đổi, hỗ trợ bảo đảm sinh kế tối thiểu cho nông hộ liên kết.
          </div>
        </div>

        {/* Stats cards columns */}
        <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex flex-col justify-between h-full">
            <div className="p-2.5 bg-slate-950 text-indigo-400 rounded-xl border border-slate-800 w-fit">
              <Banknote className="w-5 h-5" />
            </div>
            <div className="mt-4">
              <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Tổng quỹ lương tháng</span>
              <span className="text-xl font-black text-slate-100 font-mono">
                {stats.totalPayout.toLocaleString()} đ
              </span>
            </div>
          </div>

          <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex flex-col justify-between h-full">
            <div className="p-2.5 bg-slate-950 text-emerald-400 rounded-xl border border-slate-800 w-fit">
              <Wallet className="w-5 h-5" />
            </div>
            <div className="mt-4">
              <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Lương trung bình / hộ</span>
              <span className="text-xl font-black text-emerald-400 font-mono">
                {stats.avgSalary.toLocaleString()} đ
              </span>
            </div>
          </div>

          <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 flex flex-col justify-between h-full">
            <div className="p-2.5 bg-slate-950 text-teal-400 rounded-xl border border-slate-800 w-fit">
              <Award className="w-5 h-5" />
            </div>
            <div className="mt-4">
              <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Quỹ thưởng xanh ESG</span>
              <span className="text-xl font-black text-teal-400 font-mono">
                {stats.totalEsgBonuses.toLocaleString()} đ
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Payroll Spreadsheets */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row gap-3 justify-between items-center">
          <h3 className="text-slate-100 font-bold text-sm">Bảng kê chi tiết thu nhập vụ mùa</h3>
          
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 w-3.5 h-3.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Tìm tên, mã hộ, nông sản..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-850">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/40 text-[10px] font-black text-slate-400 uppercase tracking-wider">
                <th className="py-3 px-4">Mã hộ</th>
                <th className="py-3 px-4">Họ & Tên</th>
                <th className="py-3 px-4">Cây trồng</th>
                <th className="py-3 px-4">Sản lượng năm (Tấn)</th>
                <th className="py-3 px-4">Công gốc / tháng</th>
                <th className="py-3 px-4">Thưởng canh tác hữu cơ</th>
                <th className="py-3 px-4 text-right">Tổng thực lĩnh (Tháng)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-xs text-slate-300">
              {filteredPayroll.slice(0, 15).map((p) => (
                <tr key={p.id} className="hover:bg-slate-800/20 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-indigo-400">{p.id}</td>
                  <td className="py-3.5 px-4 font-bold text-slate-200">{p.name}</td>
                  <td className="py-3.5 px-4">
                    <span className="text-[10px] bg-slate-950 px-2 py-0.5 border border-slate-850 rounded font-semibold text-slate-400">
                      {p.crop}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-mono">{p.yieldTons} tấn</td>
                  <td className="py-3.5 px-4 font-mono">{p.baseSalary.toLocaleString()} đ</td>
                  <td className="py-3.5 px-4">
                    {p.isOrganic ? (
                      <span className="text-emerald-400 font-mono font-bold">+{p.esgBonus.toLocaleString()} đ</span>
                    ) : (
                      <span className="text-slate-650 font-mono">-</span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono font-black text-emerald-400">
                    {p.totalSalary.toLocaleString()} đ
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="text-[10px] text-slate-500 font-medium text-center">Hiển thị 15 dòng dữ liệu tiêu biểu — Để phân tích sâu hơn vui lòng xem mục Báo cáo</p>
      </div>

    </div>
  );
}
