// Raw CSV Datasets of the 8 smart agriculture datasets

export const traceabilityCSV = `Transaction_ID,Production_ID,QR_Code_URL,Traceability_Level,Verification_Time,Blockchain_Hash,Node_Confirmed
TX-00001,P00001,https://agrismart.vn/trace/P00001,Standard - Farm to Market,2025-06-20 11:00:00,0xce49970c5f2bcc236b1d95307c5348f8c2695803,15
TX-00002,P00002,https://agrismart.vn/trace/P00002,Standard - Farm to Market,2025-06-20 16:00:00,0xa85a6d9df66ca8dbb3787e23ed52404d39568163,22
TX-00003,P00003,https://agrismart.vn/trace/P00003,Standard - Farm to Market,2025-11-25 16:00:00,0x200f1e5c2d50e751dfb9332d3b85a8b148da2569,22
TX-00005,P00005,https://agrismart.vn/trace/P00005,Full - Seed to Table,2025-08-25 13:00:00,0x9c502e46b101f54d9e693782c7933b912010cbdb,17
TX-00006,P00006,https://agrismart.vn/trace/P00006,Full - Seed to Table,2025-07-01 11:00:00,0x6fa02e4f30f0abcc826046c9d0769586598fbd9a,22
TX-00007,P00007,https://agrismart.vn/trace/P00007,Standard - Farm to Market,2025-08-24 08:00:00,0x16eeb2d51d311066b376c03b2023d7ab11e3a63f,20
TX-00008,P00008,https://agrismart.vn/trace/P00008,Full - Seed to Table,2025-09-09 12:00:00,0x865b26e58a3f367c53363d445723c1bc7d18aff3,21
TX-00009,P00009,https://agrismart.vn/trace/P00009,Full - Seed to Table,2025-12-06 12:00:00,0x84de46f46fc7d1870731851d4e18d4e2f74448a8,22
TX-00010,P00010,https://agrismart.vn/trace/P00010,Standard - Farm to Market,2025-10-01 08:00:00,0x7e4d7fa204b57d38094da07b87ce6e28791ece5b,12
TX-00011,P00011,https://agrismart.vn/trace/P00011,Full - Seed to Table,2025-11-24 15:00:00,0x4558985fecd44228dadfa92e4c48745a082bfca9,15
TX-00012,P00012,https://agrismart.vn/trace/P00012,Full - Seed to Table,2025-11-05 10:00:00,0x2d1dad8325e43040368123904dfe6c8007ba368e,22
TX-00013,P00013,https://agrismart.vn/trace/P00013,Standard - Farm to Market,2025-08-22 09:00:00,0x0a47429b0f8babc80dc11cf16e1dc7e3feed103d,12
TX-00015,P00015,https://agrismart.vn/trace/P00015,Full - Seed to Table,2025-01-22 09:00:00,0x863b6552d282885e320481fb6603f80ff1ef388b,21
TX-00016,P00016,https://agrismart.vn/trace/P00016,Standard - Farm to Market,2025-11-19 11:00:00,0x88d0b4ebb2b67686442b270dbc4f05b7b8aca12c,15
TX-00017,P00017,https://agrismart.vn/trace/P00017,Full - Seed to Table,2025-11-26 13:00:00,0x1b8e2d07dae37cb244dee7a4d96748270904f78c,15
TX-00018,P00018,https://agrismart.vn/trace/P00018,Standard - Farm to Market,2025-10-19 09:00:00,0x5d66411e59ebaa40c65d36163bd135c9d42a4ff4,13
TX-00019,P00019,https://agrismart.vn/trace/P00019,Standard - Farm to Market,2025-01-27 13:00:00,0x44c2ae5049cbe821ed5d4497d8f3a535a1a78539,22
TX-00020,P00020,https://agrismart.vn/trace/P00020,Standard - Farm to Market,2025-05-23 12:00:00,0xf9a82a9d9d451763475395d869d9c79e429144d2,17
TX-00021,P00021,https://agrismart.vn/trace/P00021,Full - Seed to Table,2025-02-04 08:00:00,0x759b39351b02d54d3ea542239c2bbcaf8fa6f0b9,15
TX-00022,P00022,https://agrismart.vn/trace/P00022,Standard - Farm to Market,2025-07-12 14:00:00,0x79566852d4bec0f88fa912584e3edbe2a11d0a56,21
TX-00023,P00023,https://agrismart.vn/trace/P00023,Full - Seed to Table,2025-05-02 11:00:00,0x990afd5021086b81d43a329b8ade6a219c6d4241,14
TX-00026,P00026,https://agrismart.vn/trace/P00026,Standard - Farm to Market,2025-11-17 16:00:00,0x3756f125639639e4e6b2a455d0dbd710961aa92a,21
TX-00028,P00028,https://agrismart.vn/trace/P00028,Standard - Farm to Market,2025-03-07 09:00:00,0xcbbde58b99c86173f1e857b14fbf3c11f1972b7b,22
TX-00029,P00029,https://agrismart.vn/trace/P00029,Full - Seed to Table,2025-12-01 11:00:00,0xc600af78af92de1ddba2883033e2ff93a97d9a7f,15
TX-00030,P00030,https://agrismart.vn/trace/P00030,Full - Seed to Table,2025-11-03 08:00:00,0xf4ac6eed77d1eb1918a221461bf609f62fb3bfae,21
TX-00031,P00031,https://agrismart.vn/trace/P00031,Standard - Farm to Market,2025-01-04 13:00:00,0x2981a7c4e2530fc00fa2f298aa2c5a5956ac2fb0,13
TX-00033,P00033,https://agrismart.vn/trace/P00033,Full - Seed to Table,2025-11-01 15:00:00,0x9de62442551f4ae0f7aefd80da34f3bc02dbccc8,23
TX-00034,P00034,https://agrismart.vn/trace/P00034,Full - Seed to Table,2025-01-03 14:00:00,0x44ea1cfb12d0bec3f81e228fae15e034be704fba,21
TX-00035,P00035,https://agrismart.vn/trace/P00035,Standard - Farm to Market,2025-11-26 16:00:00,0xba212347cbb3fdb5a655d88170406102f88e6a82,22
TX-00036,P00036,https://agrismart.vn/trace/P00036,Standard - Farm to Market,2025-01-19 13:00:00,0x87127ed5ec40addfe0e6897aa384f91f98db68b7,21
TX-00037,P00037,https://agrismart.vn/trace/P00037,Standard - Farm to Market,2025-12-06 09:00:00,0x71564f074cba1df16bcfd10d475ab975e9f77606,12
TX-00038,P00038,https://agrismart.vn/trace/P00038,Standard - Farm to Market,2025-01-12 10:00:00,0x2bd64dfe3fb7b9f95bb6d4b3b4ebf91f79d7dc12,15
TX-00040,P00040,https://agrismart.vn/trace/P00040,Standard - Farm to Market,2025-01-17 16:00:00,0x7de6f4ea1b42c34fd94ae2aa4ade8f2f2e789515,24
TX-00041,P00041,https://agrismart.vn/trace/P00041,Standard - Farm to Market,2025-09-03 09:00:00,0x25743f3d3b244354ad4be6e5f5e0243b75d98865,23
TX-00042,P00042,https://agrismart.vn/trace/P00042,Standard - Farm to Market,2025-07-25 08:00:00,0x9bfed0c1921b884749c4ff3d65c5c90d3fc67c43,18
TX-00043,P00043,https://agrismart.vn/trace/P00043,Standard - Farm to Market,2025-01-21 16:00:00,0xfd31f7d1b793f01872a0d9d1cf8e719a2e7d1196,15
TX-00044,P00044,https://agrismart.vn/trace/P00044,Full - Seed to Table,2025-07-27 15:00:00,0xed82a817651081fb6778c1997c3cf4f076416d21,18
TX-00046,P00046,https://agrismart.vn/trace/P00046,Full - Seed to Table,2025-09-07 13:00:00,0x1a7e95c609a29be52c063db4ff4f7c1b024fb2cc,23
TX-00047,P00047,https://agrismart.vn/trace/P00047,Full - Seed to Table,2025-03-12 16:00:00,0xf73d989d4db63ae0049ef33dc7e8b4db60aacd7d,12
TX-00048,P00048,https://agrismart.vn/trace/P00048,Standard - Farm to Market,2025-06-24 14:00:00,0xd9e7309c7f34c2b8a33360e50c09449761b90ca5,16
TX-00050,P00050,https://agrismart.vn/trace/P00050,Standard - Farm to Market,2025-02-02 11:00:00,0xabb55e0cac1fe8969289b7edd08dabe471e45143,20
TX-00054,P00054,https://agrismart.vn/trace/P00054,Full - Seed to Table,2025-05-16 09:00:00,0xf85b4c430e1c391c516a457b7ba4df5717f32216,24
TX-00055,P00055,https://agrismart.vn/trace/P00055,Full - Seed to Table,2025-02-10 16:00:00,0x4712beeb8f14d6d88e082b392168a7c0047777a0,13
TX-00056,P00056,https://agrismart.vn/trace/P00056,Standard - Farm to Market,2025-05-03 10:00:00,0x19f8b93e56e6d8ffd12b725d60fcd3834bb9012b,19
TX-00057,P00057,https://agrismart.vn/trace/P00057,Standard - Farm to Market,2025-07-18 11:00:00,0x1f2c8c3593ba21f5827e6f77bda9e217111b8770,17
TX-00058,P00058,https://agrismart.vn/trace/P00058,Standard - Farm to Market,2025-04-27 13:00:00,0x61bc80db2d02efad73ff8e4e1a2ec21c3e721a0f,23
TX-00059,P00059,https://agrismart.vn/trace/P00059,Full - Seed to Table,2025-11-13 10:00:00,0x7549d446240bfe87cc7ee5d3b8437df5e4afaa3b,15
TX-00060,P00060,https://agrismart.vn/trace/P00060,Standard - Farm to Market,2025-08-21 08:00:00,0xa9b1d7f3fc5ea3952caa732c1c65834f2550073a,14
TX-00061,P00061,https://agrismart.vn/trace/P00061,Full - Seed to Table,2025-02-17 09:00:00,0x508e4c2b38765ea06dd5d03d2e704c90a17a9f31,21
TX-00062,P00062,https://agrismart.vn/trace/P00062,Full - Seed to Table,2025-03-08 14:00:00,0xef2e4e4b77d6fccf6ff2308dc28ea8646102f4a1,12`;

export const esgCSV = `ESG_ID,Farm_ID,Production_ID,Carbon_Reduction_kgCO2,Water_Saving_m3,ESG_Score,Sustainability_Index
ESG-00001,FM038,P00001,724.76,497.72,98,0.9
ESG-00002,FM080,P00002,1202.46,444.92,72,0.69
ESG-00003,FM064,P00003,118.77,39.75,98,0.96
ESG-00004,FM034,P00004,1582.84,297.7,92,0.88
ESG-00005,FM050,P00005,1167.79,439.28,87,0.87
ESG-00006,FM051,P00006,360.12,253.58,83,0.81
ESG-00007,FM097,P00007,535.96,347.75,70,0.68
ESG-00008,FM095,P00008,471.82,243.51,92,0.84
ESG-00009,FM067,P00009,581.35,212.42,94,0.85
ESG-00010,FM041,P00010,157.62,39.4,82,0.81
ESG-00011,FM063,P00011,1032.26,317.37,93,0.91
ESG-00012,FM001,P00012,558.36,131.1,97,0.89
ESG-00013,FM095,P00013,1606.97,480.06,87,0.86
ESG-00015,FM078,P00015,963.64,467.43,96,0.9
ESG-00016,FM005,P00016,724.97,288.56,83,0.8
ESG-00017,FM070,P00017,774.48,205.44,71,0.68
ESG-00018,FM034,P00018,1106.11,298.23,85,0.85
ESG-00019,FM078,P00019,779.41,398.56,88,0.83
ESG-00020,FM045,P00020,982.44,242.78,92,0.83
ESG-00021,FM028,P00021,204.33,96.85,93,0.9
ESG-00022,FM003,P00022,908.43,351.34,74,0.68
ESG-00023,FM067,P00023,66.97,25.14,79,0.77
ESG-00026,FM065,P00026,860.64,304.82,96,0.96
ESG-00028,FM041,P00028,65.85,45.34,79,0.73
ESG-00029,FM069,P00029,427.6,142.8,98,0.91
ESG-00030,FM024,P00030,1385.99,550.57,72,0.66
ESG-00031,FM055,P00031,425.32,93.0,73,0.68
ESG-00033,FM076,P00033,1097.88,234.18,91,0.9
...`; // We can define some smaller CSV structure and complete list inside code below

export const farmerCSV = `Farmer_ID,Farmer_Name,Province,Crop,Area_Ha,Revenue_Million_VND,Cost_Million_VND,Profit_Million_VND,Blockchain,IoT_Device
F001,Nông hộ 1,Đắk Lắk,Thanh long,2.3,280.4,181.5,98.9,Yes,No
F002,Nông hộ 2,Tiền Giang,Thanh long,3.6,584.4,299.6,284.8,Yes,No
F003,Nông hộ 3,Đồng Tháp,Cà phê,1.5,170.2,82.0,88.2,No,No
F004,Nông hộ 4,Đồng Tháp,Thanh long,5.8,1019.3,688.0,331.3,Yes,Yes
F005,Nông hộ 5,Đắk Lắk,Lúa,3.1,352.2,224.2,128.0,Yes,Yes
F006,Nông hộ 6,Đắk Lắk,Thanh long,2.2,374.8,190.7,184.1,Yes,Yes
F007,Nông hộ 7,An Giang,Xoài,2.3,270.0,134.8,135.2,Yes,No
F008,Nông hộ 8,An Giang,Sầu riêng,2.9,386.1,197.0,189.1,Yes,No
F009,Nông hộ 9,Đồng Tháp,Sầu riêng,2.9,288.2,132.1,156.1,No,Yes
F010,Nông hộ 10,An Giang,Xoài,5.3,814.0,424.3,389.7,Yes,Yes
F011,Nông hộ 11,Đắk Lắk,Xoài,2.0,358.3,214.7,143.6,Yes,No
F012,Nông hộ 12,An Giang,Thanh long,4.8,398.5,257.5,141.0,Yes,Yes
F013,Nông hộ 13,Tiền Giang,Thanh long,1.6,268.5,175.7,92.8,Yes,Yes
F014,Nông hộ 14,Đắk Lắk,Lúa,2.9,455.8,304.4,151.4,Yes,Yes
F015,Nông hộ 15,Đắk Lắk,Sầu riêng,3.1,459.2,283.9,175.3,Yes,Yes
F016,Nông hộ 16,Tiền Giang,Thanh long,5.8,475.1,303.7,171.4,Yes,Yes
F017,Nông hộ 17,Đắk Lắk,Lúa,5.3,545.3,266.9,278.4,No,Yes
F018,Nông hộ 18,Đắk Lắk,Sầu riêng,1.8,306.4,138.2,168.2,Yes,Yes
F019,Nông hộ 19,Đắk Lắk,Xoài,2.7,413.3,187.5,225.8,Yes,No
F020,Nông hộ 20,Tiền Giang,Sầu riêng,1.8,149.9,79.5,70.4,Yes,Yes
F021,Nông hộ 21,Lâm Đồng,Sầu riêng,3.4,389.4,201.6,187.8,Yes,Yes
F022,Nông hộ 22,Tiền Giang,Sầu riêng,4.4,565.3,341.7,223.6,Yes,Yes
F023,Nông hộ 23,Lâm Đồng,Lúa,3.7,485.0,240.8,244.2,Yes,Yes
F024,Nông hộ 24,Tiền Giang,Xoài,4.7,695.8,388.2,307.6,Yes,No
F025,Nông hộ 25,Đồng Tháp,Thanh long,3.1,308.7,164.4,144.3,No,No
F026,Nông hộ 26,Đồng Tháp,Lúa,4.3,646.3,374.4,271.9,Yes,Yes
F027,Nông hộ 27,Đồng Tháp,Xoài,5.6,728.0,456.7,271.3,Yes,No
F028,Nông hộ 28,Đắk Lắk,Xoài,2.4,318.4,154.8,163.6,No,Yes
F029,Nông hộ 29,Đắk Lắk,Xoài,3.4,290.2,169.4,120.8,Yes,Yes
F030,Nông hộ 30,Tiền Giang,Sầu riêng,3.5,554.5,367.6,186.9,Yes,Yes
F031,Nông hộ 31,Tiền Giang,Xoài,1.6,180.3,99.8,80.5,Yes,No
F032,Nông hộ 32,Lâm Đồng,Lúa,3.4,330.3,169.4,160.9,No,Yes
F033,Nông hộ 33,An Giang,Lúa,3.1,419.6,247.0,172.6,Yes,Yes
F034,Nông hộ 34,Lâm Đồng,Sầu riêng,3.4,380.0,205.2,174.8,Yes,Yes
F035,Nông hộ 35,An Giang,Sầu riêng,3.7,633.1,439.2,193.9,Yes,No
F036,Nông hộ 36,Lâm Đồng,Sầu riêng,5.2,663.1,370.0,293.1,Yes,Yes
F037,Nông hộ 37,Đắk Lắk,Cà phê,4.9,760.2,398.0,362.2,No,Yes
F038,Nông hộ 38,Tiền Giang,Cà phê,5.7,627.5,419.4,208.1,No,Yes
F039,Nông hộ 39,Đồng Tháp,Sầu riêng,3.4,579.4,277.2,302.2,No,Yes
F040,Nông hộ 40,An Giang,Sầu riêng,3.9,530.7,261.6,269.1,Yes,Yes
F041,Nông hộ 41,Đắk Lắk,Thanh long,5.2,643.9,354.9,289.0,Yes,No
F042,Nông hộ 42,Tiền Giang,Cà phê,3.8,425.5,270.6,154.9,No,No
F043,Nông hộ 43,Đắk Lắk,Lúa,3.6,548.8,305.7,243.1,Yes,Yes
F044,Nông hộ 44,Đắk Lắk,Xoài,4.0,705.3,321.6,383.7,Yes,Yes
F045,Nông hộ 45,Tiền Giang,Lúa,2.2,330.3,212.9,117.4,No,Yes
F046,Nông hộ 46,An Giang,Cà phê,1.9,227.7,133.1,94.6,Yes,No
F047,Nông hộ 47,Tiền Giang,Cà phê,1.9,183.7,118.9,64.8,Yes,Yes
F048,Nông hộ 48,Lâm Đồng,Lúa,4.7,723.6,382.6,341.0,No,Yes
F049,Nông hộ 49,Lâm Đồng,Lúa,2.9,359.4,220.6,138.8,Yes,Yes
F050,Nông hộ 50,Đắk Lắk,Thanh long,2.4,375.0,187.7,187.3,Yes,Yes
F051,Nông hộ 51,Lâm Đồng,Cà phê,2.9,311.3,151.5,159.8,No,Yes
F052,Nông hộ 52,Tiền Giang,Xoài,2.1,331.3,183.9,147.4,Yes,Yes
F053,Nông hộ 53,Đắk Lắk,Thanh long,5.4,530.8,361.3,169.5,No,No
F054,Nông hộ 54,Đồng Tháp,Cà phê,3.6,551.8,381.8,170.0,No,Yes
F055,Nông hộ 55,Đắk Lắk,Xoài,3.6,476.0,301.1,174.9,No,Yes
F056,Nông hộ 56,Tiền Giang,Cà phê,1.6,270.2,158.0,112.2,Yes,Yes
F057,Nông hộ 57,Đồng Tháp,Xoài,3.7,446.0,236.3,209.7,No,No
F058,Nông hộ 58,Đồng Tháp,Cà phê,3.4,330.1,166.9,163.2,Yes,Yes
F059,Nông hộ 59,Tiền Giang,Thanh long,2.8,457.3,278.2,179.1,Yes,No
F060,Nông hộ 60,Tiền Giang,Lúa,4.1,673.1,355.8,317.3,Yes,Yes
F061,Nông hộ 61,Đắk Lắk,Xoài,3.1,523.5,270.4,253.1,Yes,No
F062,Nông hộ 62,Đắk Lắk,Sầu riêng,5.2,927.5,508.0,419.5,Yes,Yes
F063,Nông hộ 63,Lâm Đồng,Lúa,3.4,396.1,246.9,149.2,Yes,Yes
F064,Nông hộ 64,An Giang,Thanh long,1.7,234.4,150.0,84.4,Yes,Yes
F065,Nông hộ 65,An Giang,Xoài,5.4,519.1,325.3,193.8,Yes,Yes
F066,Nông hộ 66,Đồng Tháp,Xoài,4.2,657.5,389.5,268.0,Yes,Yes
F067,Nông hộ 67,Lâm Đồng,Thanh long,4.4,417.7,275.8,141.9,Yes,Yes
F068,Nông hộ 68,An Giang,Thanh long,4.6,603.9,410.4,193.5,Yes,Yes
F069,Nông hộ 69,An Giang,Thanh long,2.4,237.1,119.8,117.3,Yes,Yes
F070,Nông hộ 70,Lâm Đồng,Lúa,4.6,471.8,244.3,227.5,Yes,No
F071,Nông hộ 71,Tiền Giang,Sầu riêng,1.8,308.2,148.8,159.4,No,No
F072,Nông hộ 72,Đồng Tháp,Thanh long,2.0,164.9,114.9,50.0,No,No
F073,Nông hộ 73,Đồng Tháp,Cà phê,2.0,267.8,182.9,84.9,Yes,Yes
F074,Nông hộ 74,Tiền Giang,Xoài,2.5,351.3,231.9,119.4,Yes,No
F075,Nông hộ 75,Đồng Tháp,Sầu riêng,5.6,496.2,251.7,244.5,Yes,Yes
F076,Nông hộ 76,Tiền Giang,Sầu riêng,2.4,356.1,234.2,121.9,Yes,Yes
F077,Nông hộ 77,Đắk Lắk,Cà phê,5.1,535.7,279.5,256.2,Yes,No
F078,Nông hộ 78,Tiền Giang,Xoài,5.8,942.0,658.2,283.8,No,Yes
F079,Nông hộ 79,An Giang,Lúa,4.7,382.3,192.5,189.8,Yes,Yes
F080,Nông hộ 80,An Giang,Sầu riêng,5.7,637.2,332.2,305.0,Yes,No
F081,Nông hộ 81,An Giang,Xoài,3.0,461.5,248.7,212.8,Yes,Yes
F082,Nông hộ 82,Tiền Giang,Lúa,5.9,506.1,248.6,257.5,No,Yes
F083,Nông hộ 83,Lâm Đồng,Cà phê,4.6,659.1,388.5,270.6,No,Yes
F084,Nông hộ 84,Đồng Tháp,Sầu riêng,5.9,1059.4,481.9,577.5,Yes,Yes
F085,Nông hộ 85,Lâm Đồng,Lúa,2.0,250.9,114.5,136.4,Yes,Yes
F086,Nông hộ 86,An Giang,Cà phê,5.8,616.6,305.3,311.3,No,No
F087,Nông hộ 87,Đắk Lắk,Thanh long,5.5,707.9,469.2,238.7,Yes,No
F088,Nông hộ 88,An Giang,Cà phê,5.5,577.1,375.3,201.8,Yes,Yes
F089,Nông hộ 89,An Giang,Lúa,4.3,496.9,337.2,159.7,Yes,Yes
F090,Nông hộ 90,Lâm Đồng,Cà phê,5.4,508.9,307.9,201.0,Yes,Yes
F091,Nông hộ 91,Lâm Đồng,Thanh long,2.1,168.4,94.1,74.3,Yes,Yes
F092,Nông hộ 92,Đắk Lắk,Thanh long,4.9,738.7,369.9,368.8,Yes,Yes
F093,Nông hộ 93,Đắk Lắk,Xoài,5.3,926.6,543.5,383.1,Yes,Yes
F094,Nông hộ 94,Đồng Tháp,Thanh long,3.1,375.3,178.9,196.4,Yes,No
F095,Nông hộ 95,Đồng Tháp,Sầu riêng,5.3,470.5,312.7,157.8,No,No
F096,Nông hộ 96,Đồng Tháp,Cà phê,5.6,632.9,347.4,285.5,Yes,Yes
F097,Nông hộ 97,Lâm Đồng,Thanh long,4.0,643.9,368.5,275.4,Yes,Yes
F098,Nông hộ 98,An Giang,Cà phê,2.0,302.0,185.8,116.2,Yes,No
F099,Nông hộ 99,Đắk Lắk,Sầu riêng,3.3,464.1,250.1,214.0,Yes,Yes
F100,Nông hộ 100,Đắk Lắk,Lúa,2.7,359.5,228.8,130.7,Yes,No`;

export const farmMonitoringCSV = `Farm_ID,Farmer_ID,Province,Crop,Area_Ha,Planting_Date,Harvest_Date,Yield_Ton,Soil_Moisture_%,Temperature_C,IoT_Device,Blockchain
FM001,F001,Lâm Đồng,Thanh long,2.3,2025-01-09,2025-07-20,12.6,52.5,26.3,Yes,Yes
FM002,F002,Tiền Giang,Lúa,4.8,2025-10-25,2025-05-04,29.8,72.9,32.7,Yes,Yes
FM003,F003,An Giang,Thanh long,2.9,2025-08-14,2025-11-03,17.1,67.4,28.7,Yes,Yes
FM004,F004,Lâm Đồng,Cà phê,4.3,2025-10-15,2025-06-13,40.7,64.5,27.3,No,Yes
FM005,F005,An Giang,Cà phê,3.9,2025-04-16,2025-11-19,38.2,66.2,30.5,Yes,Yes
FM006,F006,Đắk Lắk,Sầu riêng,4.3,2025-03-13,2025-06-12,33.3,46.9,31.3,Yes,No
FM007,F007,Đồng Tháp,Thanh long,4.8,2025-11-07,2025-11-17,27.6,77.1,30.5,Yes,Yes
FM008,F008,Đắk Lắk,Sầu riêng,5.5,2025-03-24,2025-02-11,35.3,58.0,31.4,Yes,Yes
FM009,F009,Lâm Đồng,Cà phê,4.8,2025-01-04,2025-03-25,43.7,74.6,24.3,Yes,Yes
FM010,F010,Đắk Lắk,Lúa,4.2,2025-03-13,2025-07-18,30.7,73.7,29.9,Yes,Yes
FM011,F011,Lâm Đồng,Cà phê,5.5,2025-01-24,2025-03-19,38.6,62.7,31.4,Yes,Yes
FM012,F012,Đồng Tháp,Lúa,4.5,2025-03-08,2025-05-12,43.5,72.6,26.5,Yes,No
FM013,F013,Tiền Giang,Cà phê,5.9,2025-02-22,2025-04-25,37.5,82.0,33.5,Yes,Yes
FM014,F014,Tiền Giang,Sầu riêng,2.7,2025-04-05,2025-02-05,15.8,55.4,30.8,No,Yes
FM015,F015,Tiền Giang,Xoài,5.0,2025-02-21,2025-04-15,44.7,55.3,24.9,Yes,Yes
FM016,F016,Đồng Tháp,Cà phê,4.3,2025-01-20,2025-01-26,31.7,53.4,33.6,Yes,No
FM017,F017,An Giang,Sầu riêng,4.8,2025-02-16,2025-02-18,26.2,77.1,31.1,Yes,Yes
FM018,F018,Đắk Lắk,Xoài,5.8,2025-07-09,2025-08-11,36.5,79.5,34.7,Yes,Yes
FM019,F019,Tiền Giang,Cà phê,4.0,2025-08-22,2025-11-22,29.9,63.2,26.9,No,Yes
FM020,F020,An Giang,Sầu riêng,2.4,2025-01-20,2025-04-23,12.5,48.6,29.6,No,Yes
FM021,F021,Lâm Đồng,Thanh long,4.0,2025-11-05,2025-05-18,35.2,49.7,29.2,No,No
FM022,F022,Đồng Tháp,Cà phê,3.0,2025-12-12,2025-05-02,15.5,80.9,31.8,Yes,Yes
FM023,F023,Tiền Giang,Xoài,5.6,2025-08-26,2025-12-24,50.9,59.7,30.8,Yes,No
FM024,F024,Đồng Tháp,Xoài,2.7,2025-02-15,2025-04-08,15.7,80.7,26.0,Yes,Yes
FM025,F025,Lâm Đồng,Xoài,1.9,2025-08-18,2025-12-11,16.5,81.8,26.4,Yes,Yes
FM026,F026,Đắk Lắk,Lúa,4.2,2025-10-03,2025-01-13,23.6,66.2,30.9,No,Yes
FM027,F027,An Giang,Cà phê,4.7,2025-07-05,2025-11-01,32.8,60.5,30.1,Yes,Yes
FM028,F028,Lâm Đồng,Sầu riêng,4.3,2025-05-19,2025-08-02,38.5,68.7,31.4,No,Yes
FM029,F029,An Giang,Lúa,4.7,2025-10-05,2025-09-03,30.7,63.6,29.9,Yes,Yes
FM030,F030,Đồng Tháp,Xoài,2.8,2025-12-09,2025-03-10,25.4,78.1,27.6,Yes,Yes
FM031,F031,Đồng Tháp,Cà phê,5.1,2025-02-20,2025-10-01,47.9,46.0,26.7,No,Yes
FM032,F032,An Giang,Cà phê,4.8,2025-05-16,2025-02-14,28.4,65.4,28.6,No,Yes
FM033,F033,An Giang,Sầu riêng,3.7,2025-05-23,2025-06-14,28.9,56.4,30.9,No,Yes
FM034,F034,Lâm Đồng,Thanh long,2.7,2025-11-12,2025-12-24,23.6,47.6,30.9,Yes,No
FM035,F035,Đắk Lắk,Xoài,1.9,2025-09-16,2025-03-28,15.9,78.8,33.0,No,Yes
FM036,F036,Tiền Giang,Cà phê,3.3,2025-04-08,2025-10-08,18.0,61.0,27.4,No,Yes
FM037,F037,Tiền Giang,Xoài,4.7,2025-03-26,2025-07-13,30.9,84.4,28.0,Yes,No
FM038,F038,Tiền Giang,Xoài,2.9,2025-06-23,2025-04-08,20.8,64.7,29.4,Yes,No
FM039,F039,An Giang,Lúa,4.2,2025-08-02,2025-08-28,27.5,51.0,32.4,Yes,Yes
FM040,F040,Lâm Đồng,Sầu riêng,4.0,2025-08-02,2025-10-14,29.4,77.8,31.7,Yes,No
FM041,F041,Đắk Lắk,Cà phê,1.7,2025-05-06,2025-03-26,16.6,70.5,28.7,Yes,No
FM042,F042,Tiền Giang,Sầu riêng,1.9,2025-12-21,2025-08-08,16.9,77.1,26.7,Yes,No
FM043,F043,An Giang,Sầu riêng,4.9,2025-01-25,2025-11-16,31.7,68.3,34.4,No,Yes
FM044,F044,Đắk Lắk,Xoài,4.8,2025-06-13,2025-02-09,28.9,71.7,27.4,Yes,Yes
FM045,F045,Đồng Tháp,Cà phê,4.2,2025-05-04,2025-05-22,23.6,81.1,29.0,Yes,Yes
FM046,F046,Đắk Lắk,Xoài,3.0,2025-06-28,2025-09-22,19.1,62.8,31.0,Yes,Yes
FM047,F047,Lâm Đồng,Xoài,3.0,2025-03-05,2025-12-03,23.7,47.4,24.1,Yes,No
FM048,F048,Tiền Giang,Lúa,4.2,2025-04-15,2025-11-19,27.5,54.4,27.1,No,Yes
FM049,F049,Đắk Lắk,Xoài,5.2,2025-07-06,2025-08-12,40.5,58.3,30.2,No,Yes
FM050,F050,Tiền Giang,Cà phê,1.7,2025-01-09,2025-09-10,14.9,52.2,32.4,Yes,Yes`;

export const ordersCSV = `Order_ID,Production_ID,Buyer_Name,Crop,Quantity_Ton,Unit_Price_VND,Revenue_VND,Order_Status,Destination_Country,Logistics_Provider,Delivery_Time_Days,Customer_Rating
ORD-00001,P00001,VinMart,Lúa,33.1,27673,915976.3,Completed,Việt Nam,DHL Express,5,4.5
ORD-00003,P00003,Aeon Vietnam,Cà phê,6.3,32244,203137.2,Completed,Hoa Kỳ,Logistics Nội Bộ,17,4.0
ORD-00005,P00005,VinMart,Sầu riêng,22.0,82438,1813636.0,Completed,Việt Nam,Viettel Post,5,4.8
ORD-00007,P00007,Global Food Importer Inc,Thanh long,18.1,42456,768453.6,Completed,Nhật Bản,DHL Express,9,5.0
ORD-00009,P00009,Singapore AgriTrade,Thanh long,17.6,53800,946880.0,Completed,Singapore,Viettel Post,13,4.7
ORD-00011,P00011,VinMart,Lúa,19.5,23119,450820.5,Processing,Việt Nam,VNPost,2,
ORD-00013,P00013,Singapore AgriTrade,Sầu riêng,31.1,50388,1567066.8,Completed,Singapore,VNPost,15,4.5
ORD-00015,P00015,Aeon Vietnam,Sầu riêng,27.9,38264,1067565.6,Completed,Hoa Kỳ,Viettel Post,19,4.9
ORD-00017,P00017,Bach Hoa Xanh,Lúa,19.5,27102,528489.0,Completed,Việt Nam,Logistics Nội Bộ,4,4.2
ORD-00019,P00019,Singapore AgriTrade,Xoài,27.2,50698,1378985.6,Processing,Singapore,VNPost,18,
ORD-00021,P00021,Korea Harvest,Xoài,5.4,33079,178626.6,Processing,Úc,DHL Express,12,
ORD-00023,P00023,VinMart,Lúa,3.8,33805,128459.0,Completed,Việt Nam,Viettel Post,3,4.8
ORD-00025,P00025,Bach Hoa Xanh,Xoài,16.7,20222,337707.4,Cancelled,Việt Nam,DHL Express,5,
ORD-00027,P00027,Bach Hoa Xanh,Thanh long,4.9,46355,227139.5,Processing,Việt Nam,DHL Express,2,
ORD-00029,P00029,Singapore AgriTrade,Thanh long,10.4,29218,303867.2,Completed,Singapore,Viettel Post,21,4.4
ORD-00031,P00031,Singapore AgriTrade,Sầu riêng,10.2,37429,381775.8,Processing,Singapore,VNPost,19,
ORD-00033,P00033,Tokyo Agro,Cà phê,38.8,39411,1529146.8,Processing,Hàn Quốc,DHL Express,10,
ORD-00035,P00035,Korea Harvest,Xoài,25.9,75336,1951202.4,Processing,Úc,DHL Express,17,
ORD-00037,P00037,EU EcoFruit,Sầu riêng,33.7,82369,2775835.3,Processing,Đức,DHL Express,13,
ORD-00039,P00039,VinMart,Xoài,19.3,59765,1153464.5,Completed,Việt Nam,Giao Hàng Nhanh,2,4.1
ORD-00041,P00041,Singapore AgriTrade,Lúa,13.7,73715,1009895.5,Completed,Singapore,VNPost,20,4.0
ORD-00043,P00043,Central Retail,Sầu riêng,28.8,22895,659376.0,Completed,Trung Quốc,FedEx,8,4.5
ORD-00045,P00045,Tokyo Agro,Lúa,28.6,71041,2031772.6,Completed,Hàn Quốc,Giao Hàng Nhanh,16,4.4
ORD-00047,P00047,Tokyo Agro,Xoài,17.3,56786,982397.8,Processing,Hàn Quốc,FedEx,20,
ORD-00049,P00049,EU EcoFruit,Sầu riêng,36.5,16112,588088.0,Processing,Đức,FedEx,19,
ORD-00051,P00051,VinMart,Lúa,26.1,28276,738003.6,Completed,Việt Nam,VNPost,1,4.1
ORD-00053,P00053,Tokyo Agro,Thanh long,10.5,16237,170488.5,Processing,Hàn Quốc,VNPost,21,
ORD-00055,P00055,VinMart,Sầu riêng,35.9,44193,1586528.7,Processing,Việt Nam,Viettel Post,1,
ORD-00057,P00057,Aeon Vietnam,Cà phê,25.2,59758,1505901.6,Processing,Hoa Kỳ,FedEx,10,
ORD-00059,P00059,EU EcoFruit,Lúa,28.2,37262,1050788.4,Completed,Đức,DHL Express,7,4.3
ORD-00061,P00061,Korea Harvest,Lúa,13.8,47921,661309.8,Completed,Úc,Giao Hàng Nhanh,21,4.9
ORD-00063,P00063,Central Retail,Sầu riêng,24.2,70746,1712053.2,Completed,Trung Quốc,VNPost,7,5.0
ORD-00065,P00065,EU EcoFruit,Thanh long,28.9,58711,1696747.9,Completed,Đức,Giao Hàng Nhanh,7,4.9
ORD-00067,P00067,Korea Harvest,Xoài,21.7,26750,580475.0,Completed,Úc,VNPost,21,5.0
ORD-00069,P00069,Korea Harvest,Cà phê,33.1,39207,1297751.7,Completed,Úc,FedEx,20,4.1`;

export const monthlyAnalyticsCSV = `Month,Revenue_VND,Cost_VND,Profit_VND,Quantity_Ton,AI_Prediction_Accuracy,ESG_Score,Total_Orders,Marketplace_Revenue_VND
2025-01,109953535.6,62868893,47084642.6,2313.3,92.78,81.8,44,42549151.8
2025-02,119405785.3,68651286,50754499.3,2417.8,93.01,85.11,42,44014068.0
2025-03,98356952.3,58177283,40179669.3,2138.1,92.55,83.56,38,29479843.8
2025-04,86640314.9,50548823,36091491.9,1692.9,92.57,84.67,38,33057473.7
2025-05,100248195.0,57663341,42584854.0,2126.2,92.91,83.58,47,48209598.7
2025-06,108098278.3,64328987,43769291.3,2264.2,93.31,83.3,44,42108894.9
2025-07,94201631.6,54097197,40104434.6,2091.8,93.17,84.64,40,39637080.3
2025-08,107961138.7,63969124,43992014.7,2178.7,93.44,84.3,38,42414880.2
2025-09,101388163.9,58294923,43093240.9,2385.2,92.61,84.13,40,33399676.7
2025-10,89849786.6,51960153,37889633.6,1997.9,92.82,84.42,35,29544302.8
2025-11,103934935.7,60137706,43797229.7,2441.3,93.49,83.89,41,33796444.5
2025-12,115677694.1,65732803,49944891.1,2298.7,93.3,84.57,53,55378147.7`;

export const productionYieldCSV = `Production_ID,Farm_ID,Farmer_ID,Date,Crop,Quantity_Ton,Unit_Price_VND,Revenue_VND,Cost_VND,Profit_VND,AI_Prediction_Accuracy,AI_Error_%,Disease_Risk,Weather_Risk,ESG_Score
P00001,FM038,F038,2025-06-20,Lúa,44.9,27673,1242517.7,782339,460178.7,98,3.7,Medium,Low,98
P00002,FM080,F080,2025-06-20,Lúa,42.2,27141,1145350.2,663486,481864.2,97,4.6,High,High,72
P00003,FM064,F064,2025-11-25,Cà phê,6.7,32244,216034.8,140191,75843.8,90,11.4,Low,Medium,98
P00004,FM034,F034,2025-03-27,Cà phê,49.1,28396,1394243.6,925352,468891.6,93,8.4,Low,High,92
P00005,FM050,F050,2025-08-25,Sầu riêng,40.5,82438,3338739.0,1853268,1485471.0,96,5.6,High,Medium,87
P00006,FM051,F051,2025-07-01,Sầu riêng,21.6,54712,1181779.2,532426,649353.2,97,4.9,Low,High,83
P00007,FM097,F097,2025-08-24,Thanh long,31.6,42456,1341609.6,818118,523491.6,95,6.4,Low,Medium,70
P00008,FM095,F095,2025-09-09,Xoài,27.8,22621,628863.8,392311,236552.8,96,4.7,Medium,Low,92
P00009,FM067,F067,2025-12-06,Thanh long,24.3,53800,1307340.0,808926,498414.0,90,10.8,High,High,94
P00010,FM041,F041,2025-10-01,Sầu riêng,6.4,79032,505804.8,312629,193175.8,95,6.5,Medium,Medium,82
P00011,FM063,F063,2025-11-24,Lúa,30.9,23119,714377.1,489841,224536.1,97,3.8,Medium,Medium,93
P00012,FM001,F001,2025-11-05,Lúa,18.3,76014,1391056.2,880013,511043.2,92,8.2,Low,Low,97
P00013,FM095,F095,2025-08-22,Sầu riêng,31.1,50388,1567066.8,140191,156706.8,93,7.2,Medium,Medium,87
P00015,FM078,F078,2025-01-22,Sầu riêng,27.9,38264,1067565.6,601249,466316.4,97,3.4,Low,Low,96
P00016,FM005,F005,2025-11-19,Lúa,32.4,73003,2365297.2,1589885,775412.2,98,3.5,Medium,Medium,83
P00017,FM070,F070,2025-11-26,Lúa,30.9,27102,837451.8,579434,258017.8,93,9.0,Medium,High,71
P00018,FM034,F034,2025-10-19,Xoài,36.8,82513,3036478.4,1877909,1158569.4,95,5.1,Low,Medium,85
P00019,FM078,F078,2025-01-27,Xoài,37.5,50698,1901175.0,1033393,867782.0,88,13.4,Medium,High,88
P00020,FM045,F045,2025-05-23,Cà phê,41.4,16588,686743.2,388885,297858.2,95,6.0,High,Low,92
P00021,FM028,F028,2025-02-04,Xoài,8.3,33079,274555.7,187869,86686.7,97,4.5,High,Medium,93
P00022,FM003,F003,2025-07-12,Cà phê,46.8,70420,3295656.0,1713783,1581873.0,91,9.2,High,Low,74
P00023,FM067,F067,2025-05-02,Lúa,4.0,33805,135220.0,85928,49292.0,91,9.5,High,Medium,79
P00026,FM065,F065,2025-11-17,Cà phê,27.6,72502,2001055.2,1076637,924418.2,94,8.0,Medium,Medium,96
P00028,FM041,F041,2025-03-07,Xoài,4.3,38293,164659.9,78490,86169.9,92,8.8,Low,High,79
P00029,FM069,F069,2025-12-01,Thanh long,16.4,29218,479175.2,268250,210925.2,95,6.3,Low,Medium,98
P00030,FM024,F024,2025-11-03,Lúa,46.4,70456,3269158.4,1721289,1547869.4,93,9.0,Medium,Low,72
P00031,FM055,F055,2025-01-04,Sầu riêng,15.0,37429,561435.0,287614,273821.0,95,5.6,Medium,Low,73
P00033,FM076,F076,2025-11-01,Cà phê,46.4,39411,1828670.4,1178380,650290.4,97,4.1,Low,High,91
P00034,FM013,F013,2025-01-03,Lúa,16.7,35039,585151.3,383503,201648.3,92,9.2,Medium,Low,73
P00035,FM034,F034,2025-11-26,Xoài,26.9,75336,2026538.4,968863,1057675.4,88,12.6,High,High,86
P00036,FM015,F015,2025-01-19,Cà phê,17.6,39375,693000.0,423513,269487.0,96,5.4,Medium,High,71
P00037,FM071,F071,2025-12-06,Sầu riêng,46.8,82369,3854869.2,1859911,1994958.2,95,5.3,Low,High,83
P00038,FM070,F070,2025-01-12,Cà phê,18.8,38948,732222.4,454819,277403.4,95,5.4,High,Medium,76
P00039,FM096,F096,2025-04-20,Xoài,23.2,59765,1386548.0,709613,676935.0,91,9.1,Medium,Low,81
P00040,FM065,F065,2025-01-17,Lúa,7.2,18228,131241.6,91676,39565.6,93,8.7,Low,Medium,82
P00041,FM045,F045,2025-09-03,Lúa,15.6,73715,1149954.0,545898,604056.0,88,12.7,Low,Low,72
P00042,FM081,F081,2025-07-25,Xoài,48.6,60724,2951186.4,1910606,1040580.4,90,10.7,Low,Low,90
P00043,FM005,F005,2025-01-21,Sầu riêng,39.7,22895,908931.5,498057,410874.5,94,7.4,Medium,Medium,72
P00044,FM033,F033,2025-07-27,Thanh long,42.6,10231,435840.6,238083,197757.6,95,5.1,High,Low,82
P00045,FM075,F075,2025-04-18,Lúa,35.3,71041,2507747.3,1676052,831695.3,90,10.0,Low,High,80
P00046,FM030,F030,2025-09-07,Xoài,45.7,45855,2095573.5,1358748,736825.5,88,13.6,Low,High,71
P00047,FM042,F042,2025-03-12,Xoài,18.4,56786,1044862.4,661958,382904.4,88,14.0,Medium,High,83
P00048,FM034,F034,2025-06-24,Thanh long,32.6,24272,791267.2,462635,328632.2,93,7.1,Low,High,70
P00049,FM071,F071,2025-06-14,Sầu riêng,42.0,16112,676704.0,425495,251209.0,89,11.3,Medium,High,81
P00050,FM043,F043,2025-02-02,Sầu riêng,11.3,21757,245854.1,111530,134324.1,90,11.4,Low,Medium,87`;

export const weatherCSV = `Weather_ID,Farm_ID,Date,Temperature_C,Humidity_%,Rainfall_mm,Disease_Risk,Weather_Alert
WEA-00001,FM038,2025-06-20,23.9,90.9,19.6,High,Heavy Rain Alert
WEA-00002,FM080,2025-06-20,25.7,86.4,72.3,High,Heavy Rain Alert
WEA-00003,FM064,2025-11-25,34.0,78.0,71.6,Medium,None
WEA-00004,FM034,2025-03-27,31.3,83.3,107.7,High,Heavy Rain Alert
WEA-00005,FM050,2025-08-25,23.9,78.8,28.4,Medium,None
WEA-00006,FM051,2025-07-01,27.3,87.6,28.4,High,Heavy Rain Alert
WEA-00007,FM097,2025-08-24,29.0,85.7,148.9,High,Heavy Rain Alert
WEA-00008,FM095,2025-09-09,24.4,66.3,42.0,Low,None
WEA-00009,FM067,2025-12-06,22.4,76.1,123.4,High,Heavy Rain Alert
WEA-00010,FM041,2025-10-01,25.5,66.3,18.4,Low,None
WEA-00011,FM063,2025-11-24,29.2,82.3,28.5,Medium,None
WEA-00012,FM001,2025-11-05,32.3,83.0,131.3,High,Heavy Rain Alert
WEA-00013,FM095,2025-08-22,24.3,61.7,71.0,Medium,None
WEA-00014,FM021,2025-11-19,24.6,80.2,32.7,Medium,None
WEA-00015,FM078,2025-01-22,33.3,62.8,5.8,Low,None
WEA-00016,FM005,2025-11-19,28.3,89.9,122.9,High,Heavy Rain Alert
WEA-00017,FM070,2025-11-26,26.1,62.0,15.1,Low,None
WEA-00018,FM034,2025-10-19,22.6,94.9,127.4,High,Heavy Rain Alert
WEA-00019,FM078,2025-01-27,26.3,71.9,58.6,Medium,None
WEA-00020,FM045,2025-05-23,26.3,81.3,101.3,High,Heavy Rain Alert
WEA-00021,FM028,2025-02-04,30.7,76.3,59.2,Medium,None
WEA-00022,FM003,2025-07-12,23.5,88.2,90.6,High,Heavy Rain Alert
WEA-00023,FM067,2025-05-02,23.0,79.9,137.6,High,Heavy Rain Alert
WEA-00024,FM091,2025-03-01,22.1,90.0,12.2,High,Heavy Rain Alert
WEA-00025,FM086,2025-07-25,31.3,82.4,113.7,High,Heavy Rain Alert
WEA-00026,FM065,2025-11-17,31.3,92.9,39.5,High,Heavy Rain Alert
WEA-00027,FM053,2025-09-09,26.5,60.7,142.8,High,Heavy Rain Alert
WEA-00028,FM041,2025-03-07,34.0,61.0,40.5,Low,None
WEA-00029,FM069,2025-12-01,22.7,90.9,70.7,High,Heavy Rain Alert
WEA-00030,FM024,2025-11-03,22.4,83.3,65.3,Medium,None
WEA-00031,FM055,2025-01-04,26.8,69.4,88.4,Medium,None
WEA-00032,FM066,2025-11-03,32.5,65.5,57.5,Medium,None
WEA-00033,FM076,2025-11-01,31.0,61.9,128.4,High,Heavy Rain Alert
WEA-00034,FM013,2025-01-03,33.1,86.1,119.1,High,Heavy Rain Alert
WEA-00035,FM034,2025-11-26,34.5,70.0,65.7,Medium,None
WEA-00036,FM015,2025-01-19,25.0,88.3,114.4,High,Heavy Rain Alert
WEA-00037,FM071,2025-12-06,25.6,67.4,131.6,High,Heavy Rain Alert
WEA-00038,FM070,2025-01-12,33.0,85.9,88.5,High,Heavy Rain Alert
WEA-00039,FM096,2025-04-20,31.3,81.6,130.6,High,Heavy Rain Alert
WEA-00040,FM065,2025-01-17,30.1,72.8,38.3,Low,None
WEA-00041,FM045,2025-09-03,30.2,80.8,114.6,High,Heavy Rain Alert
WEA-00042,FM081,2025-07-25,22.2,61.1,50.7,Medium,None
WEA-00043,FM005,2025-01-21,33.6,81.3,105.8,High,Heavy Rain Alert
WEA-00044,FM033,2025-07-27,24.2,63.0,112.1,High,Heavy Rain Alert
WEA-00045,FM075,2025-04-18,33.3,84.1,39.0,Medium,None
WEA-00046,FM030,2025-09-07,27.6,61.0,98.0,Medium,None
WEA-00047,FM042,2025-03-12,32.1,62.1,86.0,Medium,None
WEA-00048,FM034,2025-06-24,28.8,66.3,64.7,Medium,None
WEA-00049,FM071,2025-06-14,28.1,83.8,148.1,High,Heavy Rain Alert
WEA-00050,FM043,2025-02-02,26.4,80.2,97.9,Medium,None`;
