import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import backgroundImg from "./assets/images/smart_farming_bg_1782793350810.jpg";
import farmSatelliteMap from "./assets/images/farm_satellite_map_1782887092074.jpg";
import { parseCSV } from "./utils/csvParser";
import { monthlyAnalyticsCSV, farmerCSV } from "./data/datasets";
import DataExplorer from "./components/DataExplorer";
import DataPreprocessing from "./components/DataPreprocessing";
import ModelSandbox from "./components/ModelSandbox";
import AIAssistant from "./components/AIAssistant";
import LoginScreen, { DemoUser } from "./components/LoginScreen";
import AlertCards from "./components/AlertCards";
import WeatherForecast from "./components/WeatherForecast";
import NotificationCenter from "./components/NotificationCenter";
import { fetchAndSyncFromServer } from "./utils/sync";

// New high-fidelity screens
import AttendanceScreen from "./components/AttendanceScreen";
import ContributorScreen from "./components/ContributorScreen";
import ShiftCalendarScreen from "./components/ShiftCalendarScreen";
import TaskDispatchScreen from "./components/TaskDispatchScreen";
import ApprovalScreen, { PendingApproval } from "./components/ApprovalScreen";
import PayrollScreen from "./components/PayrollScreen";
import ReportsScreen from "./components/ReportsScreen";
import AccountScreen from "./components/AccountScreen";
import FarmingMapScreen, { REGIONS, RegionData } from "./components/FarmingMapScreen";
import FinanceBusinessScreen from "./components/FinanceBusinessScreen";
import CropYieldScreen from "./components/CropYieldScreen";
import AIWeatherScreen from "./components/AIWeatherScreen";
import SupplyChainScreen from "./components/SupplyChainScreen";
import ESGSustainabilityScreen from "./components/ESGSustainabilityScreen";

import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

import {
  LayoutDashboard,
  Clock,
  Users,
  Calendar,
  ClipboardList,
  ShieldAlert,
  Banknote,
  BarChart3,
  User,
  Cpu,
  Database,
  Hammer,
  TreePine,
  Sparkles,
  TrendingUp,
  BarChart4,
  Leaf,
  ChevronRight,
  Menu,
  X,
  Activity,
  CheckCircle,
  Sun,
  Moon,
  MapPin,
  Bug,
  Droplet,
  Thermometer,
  Wind,
  CloudRain,
  ShoppingCart,
  Map,
  AlertTriangle,
  Check,
  ExternalLink,
  AlertCircle,
  Wheat,
  Truck
} from "lucide-react";

const INITIAL_APPROVALS: PendingApproval[] = [
  {
    id: "1",
    name: "Trần Văn Hùng",
    role: "Cộng tác viên Sầu riêng",
    crop: "Sầu riêng Ri6 - Bến Tre",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
    issue: "Check-in muộn 5 phút do sự cố nghẽn mạng thiết bị cầm tay IoT",
    timeDetail: "Hôm nay 07:45 (Yêu cầu ca trực 07:40)",
    status: "pending",
  },
  {
    id: "2",
    name: "Phạm Đức Minh",
    role: "Chủ hộ cà phê liên kết",
    crop: "Cà phê Robusta - Lâm Đồng",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150",
    issue: "Thiếu dữ liệu check-out vân tay ca chiều hôm qua",
    timeDetail: "Hôm qua 17:15 (Ca trực kết thúc lúc 17:00)",
    status: "pending",
  },
  {
    id: "3",
    name: "Lê Hoàng Anh",
    role: "Khảo sát viên thổ nhưỡng",
    crop: "Tiêu sọ vùng Đắk Lắk",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150",
    issue: "Check-out sớm hơn 10 phút để khắc phục sự cố cảm biến đất",
    timeDetail: "Hôm qua 11:20 (Yêu cầu ca trực đến 11:30)",
    status: "pending",
  },
];

const CHART_METRICS = [
  { key: "Revenue_VND", label: "Doanh thu", unit: "đ", color: "#6366f1" },
  { key: "Cost_VND", label: "Chi phí", unit: "đ", color: "#f43f5e" },
  { key: "Profit_VND", label: "Lợi nhuận", unit: "đ", color: "#10b981" },
  { key: "Quantity_Ton", label: "Sản lượng giao dịch", unit: "Tấn", color: "#f59e0b" },
  { key: "Total_Orders", label: "Số lượng Đơn hàng", unit: "đơn", color: "#ec4899" },
  { key: "Marketplace_Revenue_VND", label: "Doanh thu Sàn TMĐT", unit: "đ", color: "#06b6d4" },
  { key: "AI_Prediction_Accuracy", label: "Độ chính xác AI", unit: "%", color: "#14b8a6" },
  { key: "ESG_Score", label: "Điểm ESG bền vững", unit: "điểm", color: "#8b5cf6" },
];

const formatYAxisValue = (value: number, metricKey: string) => {
  if (metricKey.endsWith("_VND")) {
    if (value >= 1000000) {
      return `${(value / 1000000).toFixed(0)} Tr`;
    }
    if (value >= 1000) {
      return `${(value / 1000).toFixed(0)} K`;
    }
    return value.toString();
  }
  if (metricKey === "Quantity_Ton") {
    return `${value.toLocaleString("vi-VN")} T`;
  }
  if (metricKey === "AI_Prediction_Accuracy") {
    return `${value}%`;
  }
  return value.toLocaleString("vi-VN");
};

const formatTooltipValue = (value: number, metricKey: string) => {
  if (metricKey.endsWith("_VND")) {
    return `${value.toLocaleString("vi-VN")} VNĐ`;
  }
  if (metricKey === "Quantity_Ton") {
    return `${value.toLocaleString("vi-VN")} Tấn`;
  }
  if (metricKey === "AI_Prediction_Accuracy") {
    return `${value} %`;
  }
  if (metricKey === "Total_Orders") {
    return `${value} Đơn hàng`;
  }
  return `${value} Điểm`;
};

export default function App() {
  const [currentUser, setCurrentUser] = useState<DemoUser | null>(null);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [approvals, setApprovals] = useState<PendingApproval[]>(INITIAL_APPROVALS);

  const [regions, setRegions] = useState<RegionData[]>(() => {
    const cached = localStorage.getItem("farming_regions");
    if (cached) {
      try { return JSON.parse(cached); } catch (e) { return REGIONS; }
    }
    return REGIONS;
  });

  const [editingRegion, setEditingRegion] = useState<RegionData | null>(null);
  // Quick edit inputs for dashboard modal
  const [editCrop, setEditCrop] = useState("");
  const [editArea, setEditArea] = useState(0);
  const [editStatus, setEditStatus] = useState<"active" | "warning" | "idle">("active");

  React.useEffect(() => {
    if (editingRegion) {
      setEditCrop(editingRegion.crop);
      setEditArea(editingRegion.areaHa);
      setEditStatus(editingRegion.status);
    }
  }, [editingRegion]);

  const handleUpdateRegion = (updated: RegionData) => {
    const nextRegions = regions.map((r) => r.id === updated.id ? updated : r);
    setRegions(nextRegions);
    localStorage.setItem("farming_regions", JSON.stringify(nextRegions));
  };

  const handleUpdateRegionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRegion) return;

    const updated: RegionData = {
      ...editingRegion,
      crop: editCrop,
      areaHa: editArea,
      status: editStatus,
    };

    handleUpdateRegion(updated);
    setEditingRegion(null);
  };

  const totalArea = useMemo(() => {
    return regions
      .filter((r) => r.id !== "vietnam-full")
      .reduce((acc, r) => acc + r.areaHa, 0);
  }, [regions]);

  const activeArea = useMemo(() => {
    return regions
      .filter((r) => r.id !== "vietnam-full" && r.status === "active")
      .reduce((acc, r) => acc + r.areaHa, 0);
  }, [regions]);

  const nonActiveArea = useMemo(() => {
    return regions
      .filter((r) => r.id !== "vietnam-full" && r.status !== "active")
      .reduce((acc, r) => acc + r.areaHa, 0);
  }, [regions]);

  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem("agrismart_theme");
      return stored !== "light"; // Default to dark mode (true)
    } catch (e) {
      return true;
    }
  });

  // Sync theme with body or container classes
  React.useEffect(() => {
    try {
      localStorage.setItem("agrismart_theme", isDarkMode ? "dark" : "light");
    } catch (e) {
      console.error(e);
    }
  }, [isDarkMode]);

  // Real-time local storage synchronization across tabs/frames
  React.useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === "farming_regions" && e.newValue) {
        try {
          setRegions(JSON.parse(e.newValue));
        } catch (err) {
          console.error("Failed to sync regions from storage:", err);
        }
      }
    };
    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);

  // Real-time synchronization periodic polling across devices
  React.useEffect(() => {
    // Initial fetch from server
    fetchAndSyncFromServer();

    // Check every 4 seconds
    const interval = setInterval(() => {
      fetchAndSyncFromServer();
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  // Load static analytics data
  const monthlyData = useMemo(() => parseCSV(monthlyAnalyticsCSV), []);
  const farmerData = useMemo(() => parseCSV(farmerCSV), []);

  const [selectedMetric, setSelectedMetric] = useState("Revenue_VND");
  const [selectedQuarter, setSelectedQuarter] = useState("all");
  const [selectedChartType, setSelectedChartType] = useState("area");

  const filteredChartData = useMemo(() => {
    if (selectedQuarter === "all") return monthlyData;
    return monthlyData.filter((row: any) => {
      const month = row.Month;
      if (!month) return false;
      const parts = month.split("-");
      if (parts.length < 2) return false;
      const m = parseInt(parts[1], 10);
      if (selectedQuarter === "q1") return m >= 1 && m <= 3;
      if (selectedQuarter === "q2") return m >= 4 && m <= 6;
      if (selectedQuarter === "q3") return m >= 7 && m <= 9;
      if (selectedQuarter === "q4") return m >= 10 && m <= 12;
      return true;
    });
  }, [monthlyData, selectedQuarter]);

  const selectedMetricMeta = useMemo(() => {
    return CHART_METRICS.find((m) => m.key === selectedMetric) || CHART_METRICS[0];
  }, [selectedMetric]);

  const stats = useMemo(() => {
    if (filteredChartData.length === 0) return { sum: 0, avg: 0, min: 0, max: 0 };
    const values = filteredChartData.map((row: any) => Number(row[selectedMetric]) || 0);
    const sum = values.reduce((a, b) => a + b, 0);
    const avg = sum / values.length;
    const min = Math.min(...values);
    const max = Math.max(...values);
    return { sum, avg, min, max };
  }, [filteredChartData, selectedMetric]);

  const pendingApprovalsCount = useMemo(() => {
    return approvals.filter((a) => a.status === "pending").length;
  }, [approvals]);

  const handleApprovalAction = (id: string, action: "approved" | "rejected") => {
    setApprovals(approvals.map((a) => (a.id === id ? { ...a, status: action } : a)));
  };

  const handleResetApprovals = () => {
    setApprovals(INITIAL_APPROVALS);
  };

  const handleAddApproval = (newApproval: PendingApproval) => {
    setApprovals((prev) => [newApproval, ...prev]);
  };

  // Compute stats for dashboard header
  const dashboardStats = useMemo(() => {
    if (monthlyData.length === 0) return { totalRevenue: 0, totalOrders: 0, avgAccuracy: 0, totalFarmers: 100 };
    const rev = monthlyData.reduce((sum, m) => sum + (m.Revenue_VND || 0), 0);
    const ords = monthlyData.reduce((sum, m) => sum + (m.Total_Orders || 0), 0);
    const acc = monthlyData.reduce((sum, m) => sum + (m.AI_Prediction_Accuracy || 0), 0) / monthlyData.length;
    return {
      totalRevenue: rev,
      totalOrders: ords,
      avgAccuracy: Number(acc.toFixed(2)),
      totalFarmers: farmerData.length || 100,
    };
  }, [monthlyData, farmerData]);

  // Sidebar navigation configuration
  const navigationItems = [
    { section: "QUẢN LÝ", items: [
      { id: "dashboard", label: "Tổng quan", icon: LayoutDashboard },
      { id: "map", label: "Bản đồ vùng trồng", icon: Map },
      { id: "attendance", label: "Chấm công", icon: Clock },
      { id: "contributor", label: "Quản lý CTV", icon: Users },
      { id: "shifts", label: "Ca & Sự kiện", icon: Calendar },
      { id: "tasks", label: "Giao việc", icon: ClipboardList },
      { id: "approvals", label: "Duyệt công", icon: ShieldAlert, badge: pendingApprovalsCount },
      { id: "payroll", label: "Bảng lương", icon: Banknote },
      { id: "reports", label: "Báo cáo", icon: BarChart3 },
    ]},
    { section: "CHIẾN LƯỢC & ESG", items: [
      { id: "finance_business", label: "Tài chính & Kinh doanh", icon: TrendingUp },
      { id: "crop_yield", label: "Nông sản & Sản lượng", icon: Wheat },
      { id: "ai_weather", label: "Công nghệ AI & Thời tiết", icon: CloudRain },
      { id: "supply_chain", label: "Chuỗi cung ứng & Xuất khẩu", icon: Truck },
      { id: "esg_sustainability", label: "ESG & Bền vững", icon: Leaf },
    ]},
    { section: "HỆ THỐNG", items: [
      { id: "account", label: "Tài khoản", icon: User },
      { id: "sandbox", label: "Mô hình ML", icon: Cpu },
      { id: "explorer", label: "Explorer Dữ liệu", icon: Database },
      { id: "preprocessing", label: "Tiền xử lý", icon: Hammer },
    ]}
  ];

  const activeTabLabel = useMemo(() => {
    for (const sec of navigationItems) {
      const found = sec.items.find((item) => item.id === activeTab);
      if (found) return found.label;
    }
    return "Menu";
  }, [activeTab]);

  if (!currentUser) {
    return (
      <div className={isDarkMode ? "theme-dark" : "theme-light"}>
        <LoginScreen 
          onLogin={setCurrentUser} 
          isDarkMode={isDarkMode} 
          onToggleTheme={() => setIsDarkMode(!isDarkMode)} 
        />
      </div>
    );
  }

  return (
    <div
      id="agrismart-app-container"
      className={`min-h-screen flex font-sans antialiased text-slate-200 relative ${isDarkMode ? "theme-dark" : "theme-light"}`}
      style={{
        backgroundImage: isDarkMode
          ? `radial-gradient(circle at center, rgba(15, 23, 42, 0.8) 0%, rgba(3, 7, 18, 0.98) 100%), url(${backgroundImg})`
          : `radial-gradient(circle at center, rgba(255, 255, 255, 0.88) 0%, rgba(241, 245, 249, 0.99) 100%), url(${backgroundImg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
      }}
    >
      
      {/* 1. Desktop Sidebar */}
      <aside className="hidden lg:flex flex-col w-72 bg-slate-950 border-r border-slate-900 shrink-0 sticky top-0 h-screen select-none z-50">
        
        {/* Header Branding */}
        <div className="p-6 border-b border-slate-900 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-tr from-indigo-600 to-sky-500 rounded-xl text-white shadow-lg shadow-indigo-950/40">
              <TreePine className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-sm font-black text-slate-100 tracking-tight uppercase">AgriSmart Hub</h1>
              <span className="text-[10px] text-sky-400 font-bold block -mt-1 uppercase tracking-wider">
                Hệ thống Điều phối & ML
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Notification Center */}
            <NotificationCenter isDarkMode={isDarkMode} />

            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-880 hover:border-slate-750 text-slate-400 hover:text-indigo-400 transition-all shadow-md cursor-pointer flex items-center justify-center shrink-0"
              title={isDarkMode ? "Chuyển sang Chế độ Sáng (Light Mode)" : "Chuyển sang Chế độ Tối (Dark Mode)"}
            >
              {isDarkMode ? <Sun className="w-4 h-4 text-amber-400 animate-pulse" /> : <Moon className="w-4 h-4 text-indigo-500" />}
            </button>
          </div>
        </div>

        {/* Scrollable Navigation List */}
        <nav className="flex-1 overflow-y-auto p-4 space-y-5 custom-scrollbar">
          {navigationItems.map((group) => (
            <div key={group.section} className="space-y-1">
              <span className="text-[9px] font-black text-slate-600 tracking-wider block px-3 mb-2 uppercase">
                {group.section}
              </span>

              {group.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    id={`sidebar-tab-${item.id}`}
                    onClick={() => {
                      setActiveTab(item.id);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`w-full px-3 py-2.5 rounded-xl transition-all duration-200 font-bold text-xs flex items-center justify-between group cursor-pointer ${
                      isActive
                        ? "text-sky-400 bg-sky-950/20 border border-sky-900/30"
                        : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/50 border border-transparent"
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className={`w-4 h-4 transition-transform group-hover:scale-105 ${
                        isActive ? "text-sky-400" : "text-slate-500 group-hover:text-slate-400"
                      }`} />
                      <span>{item.label}</span>
                    </div>

                    {item.badge !== undefined && item.badge > 0 && (
                      <span className="px-1.5 py-0.5 bg-rose-500 text-white rounded-full text-[9px] font-mono font-black border border-rose-600 animate-pulse">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </nav>

        {/* Logged in User Profile Info (Moved below menu list) */}
        <div className="p-5 border-t border-slate-900 bg-slate-900/10 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center justify-center font-black text-sm shrink-0">
            {currentUser.name.split(' ').pop()?.charAt(0) || 'U'}
          </div>
          <div className="truncate flex-1">
            <span className="text-xs font-black text-slate-200 block truncate">{currentUser.name}</span>
            <span className="text-[9px] text-sky-400 font-bold uppercase tracking-wider block -mt-0.5 truncate">{currentUser.role}</span>
          </div>
          <button
            onClick={() => setCurrentUser(null)}
            className="px-2 py-1 bg-slate-950 hover:bg-rose-950/30 text-slate-500 hover:text-rose-400 text-[9px] font-black border border-slate-900 hover:border-rose-900/30 rounded-lg transition-all uppercase cursor-pointer"
            title="Đăng xuất khỏi hệ thống"
          >
            Thoát
          </button>
        </div>

        {/* Sidebar Footer Node Indicators */}
        <div className="p-4 border-t border-slate-900/80 bg-slate-950">
          <div className="flex items-center justify-between text-[9px] font-mono text-slate-500">
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
              NODE: LIVE
            </span>
            <span>v1.2.6-stable</span>
          </div>
        </div>

      </aside>

      {/* 2. Right Main Layout Content */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* Mobile Header / Navigation Drawer */}
        <header className="lg:hidden bg-slate-950 border-b border-slate-900 h-16 flex items-center justify-between px-4 sticky top-0 z-40 select-none">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 hover:bg-slate-900 rounded-xl text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
            <div className="flex items-center gap-2">
              <TreePine className="w-5 h-5 text-sky-400" />
              <span className="font-black text-slate-200 text-xs uppercase tracking-tight">AgriSmart Hub</span>
            </div>
          </div>

          <div className="text-right flex items-center gap-2">
            {/* Mobile Notification Center */}
            <NotificationCenter isDarkMode={isDarkMode} />

            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-1.5 rounded-lg bg-slate-900 border border-slate-850 hover:border-slate-750 text-slate-400 transition-all flex items-center justify-center cursor-pointer shrink-0"
              title={isDarkMode ? "Chế độ Sáng" : "Chế độ Tối"}
            >
              {isDarkMode ? <Sun className="w-3.5 h-3.5 text-amber-400" /> : <Moon className="w-3.5 h-3.5 text-indigo-500" />}
            </button>
            <span className="text-[10px] font-mono font-bold text-slate-400 px-2 py-0.5 bg-slate-900 border border-slate-850 rounded-lg">
              {activeTabLabel}
            </span>
            <div className="w-8 h-8 rounded-lg bg-indigo-500/15 text-indigo-400 border border-indigo-500/20 flex items-center justify-center font-black text-xs shrink-0 select-none">
              {currentUser.name.split(' ').pop()?.charAt(0) || 'U'}
            </div>
          </div>
        </header>

        {/* Mobile Navigation Dropdown/Drawer Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="lg:hidden bg-slate-950 border-b border-slate-900 overflow-hidden z-30 select-none"
            >
              <div className="p-4 grid grid-cols-2 gap-2">
                {navigationItems.flatMap((g) => g.items).map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setActiveTab(item.id);
                        setIsMobileMenuOpen(false);
                      }}
                      className={`px-3 py-2 rounded-xl transition-all font-bold text-xs flex items-center gap-2.5 cursor-pointer ${
                        isActive
                          ? "text-sky-400 bg-sky-950/20 border border-sky-900/30"
                          : "text-slate-400 hover:text-slate-200 hover:bg-slate-900/50 border border-transparent"
                      }`}
                    >
                      <Icon className={`w-4 h-4 ${isActive ? "text-sky-400" : "text-slate-500"}`} />
                      <span>{item.label}</span>
                      {item.badge !== undefined && item.badge > 0 && (
                        <span className="ml-auto px-1.5 py-0.5 bg-rose-500 text-white rounded-full text-[8px] font-mono font-black animate-pulse">
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
                <button
                  onClick={() => {
                    setCurrentUser(null);
                    setIsMobileMenuOpen(false);
                  }}
                  className="col-span-2 mt-2 py-2.5 bg-rose-950/20 text-rose-400 hover:bg-rose-950/40 rounded-xl text-xs font-black transition-all border border-rose-900/30 cursor-pointer text-center"
                >
                  ĐĂNG XUẤT HỆ THỐNG
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 3. Main Stage Content Viewport */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2, ease: "easeInOut" }}
              id="tab-content-container"
            >
              
              {activeTab === "dashboard" && (
                <div id="tab-dashboard" className="space-y-6">
                  
                  {/* Welcome banner strip */}
                  <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 shadow-sm">
                    <div>
                      <span className="text-sky-400 text-[10px] font-extrabold uppercase tracking-widest block">Phiên làm việc bảo mật</span>
                      <h3 className="text-slate-100 font-black text-2xl tracking-tight mt-1">Chào mừng, {currentUser.name}!</h3>
                      <p className="text-slate-300 text-sm mt-1.5">
                        Vai trò: <span className="text-sky-300 font-bold">{currentUser.role} ({currentUser.roleTag})</span>. Hệ thống AgriSmart Hub hân hạnh phục vụ.
                      </p>
                    </div>
                    <div className="bg-slate-950 px-4 py-2 rounded-xl border border-slate-800 text-xs font-semibold text-slate-200 flex items-center gap-2 shrink-0">
                      <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                      <span>Hệ thống: Hoạt động ổn định</span>
                    </div>
                  </div>

                  {/* System Alerts Banner block */}
                  <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-rose-500/10 text-rose-400 rounded-xl border border-rose-500/20">
                        <ShieldAlert className="w-5.5 h-5.5 animate-pulse" />
                      </div>
                      <div>
                        <h4 className="text-slate-100 font-black text-sm">Hệ thống Cảnh báo Sức khỏe Cây trồng Tự động (AI-IoT)</h4>
                        <p className="text-slate-300 text-xs mt-1">
                          Phát hiện dấu hiệu bất thường và dự đoán rủi ro sớm dựa trên dữ liệu cảm biến, thời tiết và lịch sử sinh trưởng.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <div className="px-3 py-1 bg-rose-500/15 border border-rose-500/30 text-rose-400 text-xs font-extrabold rounded-lg flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>8 Nguy cấp</span>
                      </div>
                      <div className="px-3 py-1 bg-amber-500/15 border border-amber-500/30 text-amber-400 text-xs font-extrabold rounded-lg flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>7 Cảnh báo</span>
                      </div>
                    </div>
                  </div>

                  {/* High level analytics grid */}
                  <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
                    {/* Card 1 */}
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:bg-slate-800/60 transition-all duration-300 shadow-md flex items-center gap-4 hover:scale-[1.03] active:scale-[0.98] hover:border-slate-700 hover:shadow-lg relative group cursor-help">
                      {/* Tooltip */}
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 w-56 sm:w-64 bg-slate-950/95 backdrop-blur border border-slate-800 text-slate-200 rounded-xl p-3.5 shadow-2xl opacity-0 group-hover:opacity-100 group-hover:translate-y-0 translate-y-2 transition-all duration-300 pointer-events-none z-50 text-left leading-relaxed">
                        <div className="flex items-center gap-1.5 border-b border-slate-800 pb-1.5 mb-1.5">
                          <Map className="w-3.5 h-3.5 text-sky-400" />
                          <span className="font-extrabold text-[10px] text-slate-100 uppercase tracking-wider">Chi tiết Vùng trồng</span>
                        </div>
                        <p className="text-[11px] text-slate-300 font-normal">
                          Tổng diện tích đất canh tác nông nghiệp công nghệ cao đang được quản lý và giám sát thời gian thực trên hệ thống AgriSmart Hub.
                        </p>
                        <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-950" />
                      </div>

                      <div className="p-3 bg-sky-500/15 text-sky-450 rounded-xl border border-sky-500/30 shrink-0">
                        <Map className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <span className="text-slate-400 text-xs font-bold uppercase tracking-wider block truncate">Vùng trồng</span>
                        <span className="text-2xl font-black text-slate-100 block font-mono mt-0.5">1.250 ha</span>
                        <span className="text-xs text-emerald-400 font-bold block mt-1 truncate">↑ 12% tháng trước</span>
                      </div>
                    </div>

                    {/* Card 2 */}
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:bg-slate-800/60 transition-all duration-300 shadow-md flex items-center gap-4 hover:scale-[1.03] active:scale-[0.98] hover:border-slate-700 hover:shadow-lg relative group cursor-help">
                      {/* Tooltip */}
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 w-56 sm:w-64 bg-slate-950/95 backdrop-blur border border-slate-800 text-slate-200 rounded-xl p-3.5 shadow-2xl opacity-0 group-hover:opacity-100 group-hover:translate-y-0 translate-y-2 transition-all duration-300 pointer-events-none z-50 text-left leading-relaxed">
                        <div className="flex items-center gap-1.5 border-b border-slate-800 pb-1.5 mb-1.5">
                          <Leaf className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="font-extrabold text-[10px] text-slate-100 uppercase tracking-wider">Chi tiết Sản lượng</span>
                        </div>
                        <p className="text-[11px] text-slate-300 font-normal">
                          Tổng lượng nông sản thu hoạch và xuất kho tích lũy trong mùa vụ hiện tại, bao gồm các loại nông sản đạt tiêu chuẩn VietGAP xuất khẩu.
                        </p>
                        <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-950" />
                      </div>

                      <div className="p-3 bg-emerald-500/15 text-emerald-400 rounded-xl border border-emerald-500/30 shrink-0">
                        <Leaf className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <span className="text-slate-400 text-xs font-bold uppercase tracking-wider block truncate">Sản lượng</span>
                        <span className="text-2xl font-black text-slate-100 block font-mono mt-0.5">3.450 tấn</span>
                        <span className="text-xs text-emerald-400 font-bold block mt-1 truncate">↑ 8% tháng trước</span>
                      </div>
                    </div>

                    {/* Card 3 */}
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:bg-slate-800/60 transition-all duration-300 shadow-md flex items-center gap-4 hover:scale-[1.03] active:scale-[0.98] hover:border-slate-700 hover:shadow-lg relative group cursor-help">
                      {/* Tooltip */}
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 w-56 sm:w-64 bg-slate-950/95 backdrop-blur border border-slate-800 text-slate-200 rounded-xl p-3.5 shadow-2xl opacity-0 group-hover:opacity-100 group-hover:translate-y-0 translate-y-2 transition-all duration-300 pointer-events-none z-50 text-left leading-relaxed">
                        <div className="flex items-center gap-1.5 border-b border-slate-800 pb-1.5 mb-1.5">
                          <ShoppingCart className="w-3.5 h-3.5 text-indigo-400" />
                          <span className="font-extrabold text-[10px] text-slate-100 uppercase tracking-wider">Chi tiết Đơn hàng</span>
                        </div>
                        <p className="text-[11px] text-slate-300 font-normal">
                          Số lượng đơn đặt hàng từ đối tác thu mua, chuỗi siêu thị và đại lý liên kết đang được xử lý, đóng gói hoặc giao nhận.
                        </p>
                        <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-950" />
                      </div>

                      <div className="p-3 bg-indigo-500/15 text-indigo-400 rounded-xl border border-indigo-500/30 shrink-0">
                        <ShoppingCart className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <span className="text-slate-400 text-xs font-bold uppercase tracking-wider block truncate">Đơn hàng</span>
                        <span className="text-2xl font-black text-slate-100 block font-mono mt-0.5">320 đơn</span>
                        <span className="text-xs text-emerald-400 font-bold block mt-1 truncate">↑ 15% tháng trước</span>
                      </div>
                    </div>

                    {/* Card 4 */}
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:bg-slate-800/60 transition-all duration-300 shadow-md flex items-center gap-4 hover:scale-[1.03] active:scale-[0.98] hover:border-slate-700 hover:shadow-lg relative group cursor-help">
                      {/* Tooltip */}
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 w-56 sm:w-64 bg-slate-950/95 backdrop-blur border border-slate-800 text-slate-200 rounded-xl p-3.5 shadow-2xl opacity-0 group-hover:opacity-100 group-hover:translate-y-0 translate-y-2 transition-all duration-300 pointer-events-none z-50 text-left leading-relaxed">
                        <div className="flex items-center gap-1.5 border-b border-slate-800 pb-1.5 mb-1.5">
                          <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
                          <span className="font-extrabold text-[10px] text-slate-100 uppercase tracking-wider">Chi tiết Doanh thu</span>
                        </div>
                        <p className="text-[11px] text-slate-300 font-normal">
                          Doanh thu lũy kế từ giao dịch nông sản thực tế, đã hoàn tất đối soát tài chính bảo mật thông qua hệ thống cổng AgriSmart.
                        </p>
                        <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-950" />
                      </div>

                      <div className="p-3 bg-amber-500/15 text-amber-400 rounded-xl border border-amber-500/30 shrink-0">
                        <TrendingUp className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <span className="text-slate-400 text-xs font-bold uppercase tracking-wider block truncate">Doanh thu</span>
                        <span className="text-2xl font-black text-slate-100 block font-mono mt-0.5">12,8 tỷ</span>
                        <span className="text-xs text-emerald-400 font-bold block mt-1 truncate">↑ 10% tháng trước</span>
                      </div>
                    </div>

                    {/* Card 5 */}
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 hover:bg-slate-800/60 transition-all duration-300 shadow-md flex items-center gap-4 col-span-2 lg:col-span-1 hover:scale-[1.03] active:scale-[0.98] hover:border-slate-700 hover:shadow-lg relative group cursor-help">
                      {/* Tooltip */}
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 w-56 sm:w-64 bg-slate-950/95 backdrop-blur border border-slate-800 text-slate-200 rounded-xl p-3.5 shadow-2xl opacity-0 group-hover:opacity-100 group-hover:translate-y-0 translate-y-2 transition-all duration-300 pointer-events-none z-50 text-left leading-relaxed">
                        <div className="flex items-center gap-1.5 border-b border-slate-800 pb-1.5 mb-1.5">
                          <Users className="w-3.5 h-3.5 text-teal-400" />
                          <span className="font-extrabold text-[10px] text-slate-100 uppercase tracking-wider">Chi tiết Thành viên</span>
                        </div>
                        <p className="text-[11px] text-slate-300 font-normal">
                          Tổng số lượng nông hộ canh tác, kỹ sư chuyên môn, cán bộ điều hành hợp tác xã kết nối và đồng bộ dữ liệu trên AgriSmart Hub.
                        </p>
                        <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-950" />
                      </div>

                      <div className="p-3 bg-teal-500/15 text-teal-450 rounded-xl border border-teal-500/30 shrink-0">
                        <Users className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <span className="text-slate-400 text-xs font-bold uppercase tracking-wider block truncate">Thành viên</span>
                        <span className="text-2xl font-black text-slate-100 block font-mono mt-0.5">1.200+</span>
                        <span className="text-xs text-emerald-400 font-bold block mt-1 truncate">↑ 11% tháng trước</span>
                      </div>
                    </div>
                  </div>

                  {/* Middle grid */}
                  <div className="space-y-6">
                    
                    {/* Map widget - Expanded Full Width */}
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between h-[450px] shadow-md hover:border-slate-700/80 transition-all duration-300">
                      <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
                        <Map className="w-5 h-5 text-sky-400" />
                        <span className="font-semibold text-slate-100 text-sm">Bản đồ vùng trồng</span>
                      </div>

                      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1 pt-5 items-stretch min-h-0">
                        {/* Left Info Column */}
                        <div className="lg:col-span-4 flex flex-col justify-between pr-4 border-r border-slate-800 space-y-4">
                          <div className="space-y-4">
                            <div>
                              <span className="text-[13px] text-slate-400 font-medium">Tổng số vùng</span>
                              <strong className="text-3xl font-bold text-slate-100 block mt-1">
                                {regions.filter(r => r.id !== "vietnam-full").length * 14}
                              </strong>
                            </div>
                            
                            <div className="border-t border-slate-850 w-full" />
                            
                            <div>
                              <span className="text-[13px] text-slate-400 font-medium font-sans">Diện tích</span>
                              <strong className="text-xl font-bold text-sky-400 block mt-1">
                                {totalArea.toLocaleString("vi-VN")} ha
                              </strong>
                            </div>
                            <div>
                              <span className="text-[13px] text-slate-400 font-medium font-sans">Đang sản xuất</span>
                              <strong className="text-xl font-bold text-emerald-400 block mt-1">
                                {activeArea.toLocaleString("vi-VN")} ha
                              </strong>
                            </div>
                            <div>
                              <span className="text-[13px] text-slate-400 font-medium font-sans">Tạm ngưng</span>
                              <strong className="text-xl font-bold text-amber-500 block mt-1">
                                {nonActiveArea.toLocaleString("vi-VN")} ha
                              </strong>
                            </div>
                          </div>
                          
                          <button 
                            onClick={() => setActiveTab("map")}
                            className="px-4 py-2 border border-slate-800 hover:border-slate-700 hover:bg-slate-850/60 text-slate-300 text-xs font-semibold rounded-xl transition-all tracking-wide cursor-pointer w-fit self-start"
                          >
                            Xem chi tiết
                          </button>
                        </div>

                        {/* Right Satellite Map - Beautiful Green Farmland plots background */}
                        <div className="lg:col-span-8 relative rounded-3xl bg-slate-950 border border-slate-800 overflow-hidden flex items-center justify-center min-h-[220px] shadow-inner">
                          <img 
                            src={farmSatelliteMap} 
                            alt="Bản đồ vệ tinh nông trại" 
                            className="absolute inset-0 w-full h-full object-cover opacity-90 select-none pointer-events-none"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-slate-950/15" />

                          {[
                            { id: "bentre-pomelo", top: "25%", left: "30%", animate: true },
                            { id: "daklak-coffee", top: "35%", left: "70%", animate: false },
                            { id: "binhthuan-dragon", top: "58%", left: "44%", animate: true },
                            { id: "tiengiang-mango", top: "70%", left: "78%", animate: false },
                          ].map((pin) => {
                            const region = regions.find((r) => r.id === pin.id);
                            if (!region) return null;

                            const isWarning = region.status === "warning";
                            const isIdle = region.status === "idle";
                            const dotColor = isWarning 
                              ? "bg-amber-500" 
                              : isIdle 
                              ? "bg-slate-400" 
                              : "bg-emerald-500";

                            return (
                              <div 
                                key={pin.id} 
                                className="absolute group cursor-pointer z-25"
                                style={{ top: pin.top, left: pin.left }}
                              >
                                {/* Highly Polished White Pin with Inner Status Indicator from Image 2 */}
                                <div className="relative w-7 h-7 bg-white rounded-full flex items-center justify-center shadow-lg border border-slate-200/50 transition-transform duration-300 hover:scale-125 hover:z-30">
                                  <div className={`w-3 h-3 ${dotColor} rounded-full ${pin.animate ? "animate-pulse" : ""}`} />
                                  <div className="absolute top-[90%] left-1/2 -translate-x-1/2 w-0 h-0 border-l-[4px] border-r-[4px] border-t-[5px] border-l-transparent border-r-transparent border-t-white filter drop-shadow-[0_2px_1px_rgba(0,0,0,0.15)]" />
                                </div>

                                {/* Custom elegant hover tooltip with high-contrast styling */}
                                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 w-48 bg-slate-950/95 border border-slate-800 text-slate-200 rounded-xl p-3 shadow-2xl opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-auto text-left scale-90 origin-bottom group-hover:scale-100 z-50">
                                  <div className="flex items-center gap-1.5 border-b border-slate-850 pb-1.5 mb-2 justify-between">
                                    <span className="font-extrabold text-[9px] text-sky-400 uppercase tracking-wider truncate max-w-[110px]">{region.crop}</span>
                                    <span className={`w-1.5 h-1.5 rounded-full ${isWarning ? 'bg-amber-500 animate-pulse' : isIdle ? 'bg-slate-500' : 'bg-emerald-500'}`} />
                                  </div>
                                  <h5 className="text-[10px] font-extrabold text-slate-100 leading-tight">{region.name}</h5>
                                  <p className="text-[9px] text-slate-400 mt-1">
                                    Quy mô: <span className="font-mono text-slate-200 font-bold">{region.areaHa} ha</span>
                                  </p>
                                  <p className="text-[8.5px] text-slate-500 mt-0.5 leading-snug">
                                    {region.locationName}
                                  </p>
                                  
                                  {/* Quick Edit popup trigger button inside tooltip */}
                                  <button
                                    onClick={(e) => {
                                      e.preventDefault();
                                      e.stopPropagation();
                                      setEditingRegion(region);
                                    }}
                                    className="mt-2.5 w-full text-center py-1.5 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-slate-100 font-black rounded-lg text-[9px] uppercase tracking-wider transition-all cursor-pointer shadow shadow-indigo-950/40"
                                  >
                                    Hiệu chỉnh nhanh
                                  </button>
                                  <div className="absolute top-full left-1/2 -translate-x-1/2 border-4 border-transparent border-t-slate-950" />
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>

                    {/* Chart widget - Expanded Full Width */}
                    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between h-[420px] shadow-md hover:border-slate-700/80 transition-all duration-300">
                      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                        <div className="flex items-center gap-2">
                          <BarChart4 className="w-4 h-4 text-emerald-400" />
                          <span className="font-black text-slate-100 text-xs uppercase tracking-wider">Thống kê sản lượng</span>
                        </div>
                        <select className="bg-slate-950 border border-slate-800 text-slate-200 text-[10px] font-black rounded-lg px-2.5 py-1 focus:outline-none focus:border-emerald-500 transition-all cursor-pointer">
                          <option>Năm 2024</option>
                          <option>Năm 2025</option>
                        </select>
                      </div>

                      <div className="h-[260px] w-full pt-4">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart
                            data={[
                              { name: "T1", value: 1.2 },
                              { name: "T2", value: 1.8 },
                              { name: "T3", value: 3.2 },
                              { name: "T4", value: 2.1 },
                              { name: "T5", value: 2.5 },
                              { name: "T6", value: 3.1 },
                              { name: "T7", value: 2.8 },
                              { name: "T8", value: 3.6 },
                              { name: "T9", value: 4.1 },
                              { name: "T10", value: 3.8 },
                              { name: "T11", value: 4.2 },
                              { name: "T12", value: 4.9 },
                            ]}
                            margin={{ top: 10, right: 15, left: -20, bottom: 5 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} opacity={0.3} />
                            <XAxis dataKey="name" stroke="#64748b" style={{ fontSize: 10, fill: '#cbd5e1', fontWeight: 'bold' }} tickLine={false} />
                            <YAxis stroke="#64748b" style={{ fontSize: 10, fill: '#cbd5e1', fontWeight: 'bold' }} tickLine={false} tickFormatter={(v) => `${v}k`} />
                            <Tooltip
                              contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: 11, color: '#f1f5f9' }}
                              formatter={(val: any) => [`${val * 1000} Tấn`, "Sản lượng"]}
                            />
                            <Line
                              type="monotone"
                              dataKey="value"
                              stroke="#10b981"
                              strokeWidth={3.5}
                              dot={{ r: 5, fill: '#10b981', strokeWidth: 0 }}
                              activeDot={{ r: 7, fill: '#34d399' }}
                            />
                          </LineChart>
                        </ResponsiveContainer>
                      </div>

                      <div className="grid grid-cols-3 gap-4 border-t border-slate-800 pt-4 text-center">
                        <div>
                          <span className="text-base font-black text-slate-100 block font-mono">3.450 tấn</span>
                          <span className="text-[10px] text-slate-400 font-bold block uppercase mt-0.5">Tổng sản lượng</span>
                        </div>
                        <div>
                          <span className="text-base font-black text-emerald-400 block font-mono">↑ 8%</span>
                          <span className="text-[10px] text-slate-400 font-bold block uppercase mt-0.5">So với tháng trước</span>
                        </div>
                        <div>
                          <span className="text-base font-black text-emerald-400 block font-mono">↑ 18%</span>
                          <span className="text-[10px] text-slate-400 font-bold block uppercase mt-0.5">So với cùng kỳ</span>
                        </div>
                      </div>
                    </div>

                  </div>

                  {/* Bottom section layout reorganized */}
                  <div className="space-y-6">
                    
                    {/* Row 1: Weather and System Activities */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      
                      {/* Weather card */}
                      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between h-[280px] shadow-md hover:border-slate-700/80 transition-all duration-300">
                        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                          <div className="flex items-center gap-2">
                            <CloudRain className="w-4 h-4 text-sky-400" />
                            <span className="font-black text-slate-100 text-xs uppercase tracking-wider">Cảnh báo thời tiết & môi trường</span>
                          </div>
                          <button className="text-xs font-bold text-sky-400 hover:text-sky-300 transition-colors cursor-pointer">Xem chi tiết</button>
                        </div>

                        <div className="grid grid-cols-4 gap-2 py-4 flex-1 items-center">
                          <div className="text-center border-r border-slate-800 h-full flex flex-col justify-center items-center px-1">
                            <div className="p-2.5 bg-rose-500/20 text-rose-400 rounded-xl mb-1.5">
                              <Thermometer className="w-4 h-4" />
                            </div>
                            <span className="text-[10px] text-slate-400 font-bold block uppercase truncate w-full">Nhiệt độ</span>
                            <span className="text-xs font-extrabold text-slate-100 font-mono block mt-0.5">35-37°C</span>
                            <span className="text-[10px] text-slate-300 block truncate w-full">2 ngày tới</span>
                          </div>

                          <div className="text-center border-r border-slate-800 h-full flex flex-col justify-center items-center px-1">
                            <div className="p-2.5 bg-sky-500/20 text-sky-400 rounded-xl mb-1.5 animate-bounce">
                              <CloudRain className="w-4 h-4" />
                            </div>
                            <span className="text-[10px] text-slate-400 font-bold block uppercase truncate w-full">Mưa lớn</span>
                            <span className="text-xs font-extrabold text-slate-100 font-mono block mt-0.5">80-120mm</span>
                            <span className="text-[10px] text-slate-300 block truncate w-full">Ngày mai</span>
                          </div>

                          <div className="text-center border-r border-slate-800 h-full flex flex-col justify-center items-center px-1">
                            <div className="p-2.5 bg-teal-500/20 text-teal-400 rounded-xl mb-1.5">
                              <Droplet className="w-4 h-4" />
                            </div>
                            <span className="text-[10px] text-slate-400 font-bold block uppercase truncate w-full">Độ ẩm</span>
                            <span className="text-xs font-extrabold text-slate-100 font-mono block mt-0.5">70 - 80%</span>
                            <span className="text-[10px] text-emerald-400 font-bold block truncate w-full">Cao</span>
                          </div>

                          <div className="text-center h-full flex flex-col justify-center items-center px-1">
                            <div className="p-2.5 bg-cyan-500/20 text-cyan-400 rounded-xl mb-1.5">
                              <Wind className="w-4 h-4" />
                            </div>
                            <span className="text-[10px] text-slate-400 font-bold block uppercase truncate w-full">Gió</span>
                            <span className="text-xs font-extrabold text-slate-100 font-mono block mt-0.5">10-15km/h</span>
                            <span className="text-[10px] text-slate-300 block truncate w-full">Cấp 3</span>
                          </div>
                        </div>
                      </div>

                      {/* System activity log */}
                      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between h-[280px] shadow-md hover:border-slate-700/80 transition-all duration-300">
                        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                          <div className="flex items-center gap-2">
                            <Activity className="w-4 h-4 text-emerald-400" />
                            <span className="font-black text-slate-100 text-xs uppercase tracking-wider">Hoạt động hệ thống</span>
                          </div>
                          <button className="text-xs font-bold text-sky-400 hover:text-sky-300 transition-colors cursor-pointer">Xem chi tiết</button>
                        </div>

                        <div className="flex-1 flex flex-col justify-center gap-3.5 py-3">
                          {/* Log 1 */}
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex items-start gap-2.5 min-w-0">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse mt-1.5 shrink-0" />
                              <span className="text-xs font-semibold text-slate-200 leading-tight">Hệ thống AI-IoT đã phân tích 1.250 mẫu dữ liệu</span>
                            </div>
                            <span className="text-[10px] text-slate-450 font-mono font-bold shrink-0">2 phút trước</span>
                          </div>

                          {/* Log 2 */}
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex items-start gap-2.5 min-w-0">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse mt-1.5 shrink-0" />
                              <span className="text-xs font-semibold text-slate-200 leading-tight">Cảm biến tại vùng VTB-12 gửi dữ liệu mới</span>
                            </div>
                            <span className="text-[10px] text-slate-450 font-mono font-bold shrink-0">5 phút trước</span>
                          </div>

                          {/* Log 3 */}
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex items-start gap-2.5 min-w-0">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse mt-1.5 shrink-0" />
                              <span className="text-xs font-semibold text-slate-200 leading-tight">Đơn hàng DH-2024-089 đã được xác nhận</span>
                            </div>
                            <span className="text-[10px] text-slate-450 font-mono font-bold shrink-0">15 phút trước</span>
                          </div>

                          {/* Log 4 */}
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex items-start gap-2.5 min-w-0">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse mt-1.5 shrink-0" />
                              <span className="text-xs font-semibold text-slate-200 leading-tight">Nhật ký điện tử từ HTX An Phú được cập nhật</span>
                            </div>
                            <span className="text-[10px] text-slate-450 font-mono font-bold shrink-0">30 phút trước</span>
                          </div>
                        </div>
                      </div>

                    </div>

                    {/* Row 2: Pest Warnings and Tasks to Process */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

                      {/* Pest card */}
                      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between h-[280px] shadow-md hover:border-slate-700/80 transition-all duration-300">
                        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                          <div className="flex items-center gap-2">
                            <Bug className="w-4 h-4 text-rose-400 animate-pulse" />
                            <span className="font-black text-slate-100 text-xs uppercase tracking-wider">Cảnh báo sâu bệnh</span>
                          </div>
                          <button className="text-xs font-bold text-sky-400 hover:text-sky-300 transition-colors cursor-pointer">Xem chi tiết</button>
                        </div>

                        <div className="flex-1 flex flex-col justify-center gap-4 py-3">
                          {/* Row 1 */}
                          <div className="flex items-center justify-between">
                            <div className="flex items-start gap-2.5 min-w-0">
                              <div className="p-1.5 bg-rose-500/20 text-rose-400 rounded-lg shrink-0">
                                <ShieldAlert className="w-3.5 h-3.5" />
                              </div>
                              <div className="min-w-0">
                                <span className="text-xs font-extrabold text-slate-200 block truncate">Sâu đục thân</span>
                                <span className="text-[11px] text-slate-300 block truncate">Nguy cơ cao tại 5 vùng trồng</span>
                              </div>
                            </div>
                            <span className="px-2 py-0.5 bg-rose-950 border border-rose-800 text-rose-400 text-[10px] font-black uppercase tracking-wider rounded-lg shrink-0">Nguy cấp</span>
                          </div>

                          {/* Row 2 */}
                          <div className="flex items-center justify-between">
                            <div className="flex items-start gap-2.5 min-w-0">
                              <div className="p-1.5 bg-amber-500/20 text-amber-400 rounded-lg shrink-0">
                                <AlertCircle className="w-3.5 h-3.5" />
                              </div>
                              <div className="min-w-0">
                                <span className="text-xs font-extrabold text-slate-200 block truncate">Bệnh đạo ôn</span>
                                <span className="text-[11px] text-slate-300 block truncate">Nguy cơ TB tại 3 vùng trồng</span>
                              </div>
                            </div>
                            <span className="px-2 py-0.5 bg-amber-950 border border-amber-800 text-amber-400 text-[10px] font-black uppercase tracking-wider rounded-lg shrink-0">Cảnh báo</span>
                          </div>

                          {/* Row 3 */}
                          <div className="flex items-center justify-between">
                            <div className="flex items-start gap-2.5 min-w-0">
                              <div className="p-1.5 bg-emerald-500/20 text-emerald-400 rounded-lg shrink-0">
                                <Leaf className="w-3.5 h-3.5" />
                              </div>
                              <div className="min-w-0">
                                <span className="text-xs font-extrabold text-slate-200 block truncate">Rầy nâu</span>
                                <span className="text-[11px] text-slate-300 block truncate">Nguy cơ thấp tại 2 vùng trồng</span>
                              </div>
                            </div>
                            <span className="px-2 py-0.5 bg-emerald-950 border border-emerald-800 text-emerald-400 text-[10px] font-black uppercase tracking-wider rounded-lg shrink-0">An toàn</span>
                          </div>
                        </div>
                      </div>

                      {/* Task checklist widget */}
                      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between h-[280px] shadow-md hover:border-slate-700/80 transition-all duration-300">
                        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                          <div className="flex items-center gap-2">
                            <ClipboardList className="w-4 h-4 text-sky-400" />
                            <span className="font-black text-slate-100 text-xs uppercase tracking-wider">Công việc cần xử lý</span>
                          </div>
                          <button className="text-xs font-bold text-sky-400 hover:text-sky-300 transition-colors cursor-pointer">Xem tất cả</button>
                        </div>

                        <div className="flex-1 divide-y divide-slate-850 flex flex-col justify-center py-2">
                          {/* Row 1 */}
                          <div className="flex items-center justify-between py-1.5">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div className="p-1.5 bg-emerald-500/15 text-emerald-400 rounded-lg shrink-0">
                                <Leaf className="w-3 h-3" />
                              </div>
                              <span className="text-[11px] font-semibold text-slate-200 truncate">Yêu cầu duyệt vùng trồng</span>
                            </div>
                            <span className="px-2.5 py-0.5 bg-slate-950 border border-slate-800 text-slate-300 text-[10px] font-black rounded-lg shrink-0">12</span>
                          </div>

                          {/* Row 2 */}
                          <div className="flex items-center justify-between py-1.5">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div className="p-1.5 bg-sky-500/15 text-sky-400 rounded-lg shrink-0">
                                <ClipboardList className="w-3 h-3" />
                              </div>
                              <span className="text-[11px] font-semibold text-slate-200 truncate">Nhật ký điện tử cần kiểm tra</span>
                            </div>
                            <span className="px-2.5 py-0.5 bg-slate-950 border border-slate-800 text-slate-300 text-[10px] font-black rounded-lg shrink-0">18</span>
                          </div>

                          {/* Row 3 */}
                          <div className="flex items-center justify-between py-1.5">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div className="p-1.5 bg-rose-500/15 text-rose-400 rounded-lg shrink-0">
                                <Bug className="w-3 h-3" />
                              </div>
                              <span className="text-[11px] font-semibold text-slate-200 truncate">Cảnh báo sâu bệnh</span>
                            </div>
                            <span className="px-2.5 py-0.5 bg-slate-950 border border-slate-800 text-slate-300 text-[10px] font-black rounded-lg shrink-0">8</span>
                          </div>

                          {/* Row 4 */}
                          <div className="flex items-center justify-between py-1.5">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div className="p-1.5 bg-indigo-500/15 text-indigo-400 rounded-lg shrink-0">
                                <ShoppingCart className="w-3 h-3" />
                              </div>
                              <span className="text-[11px] font-semibold text-slate-200 truncate">Đơn hàng mới</span>
                            </div>
                            <span className="px-2.5 py-0.5 bg-slate-950 border border-slate-800 text-slate-300 text-[10px] font-black rounded-lg shrink-0">15</span>
                          </div>

                          {/* Row 5 */}
                          <div className="flex items-center justify-between py-1.5">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div className="p-1.5 bg-amber-500/15 text-amber-400 rounded-lg shrink-0">
                                <Clock className="w-3 h-3" />
                              </div>
                              <span className="text-[11px] font-semibold text-slate-200 truncate">Công việc quá hạn</span>
                            </div>
                            <span className="px-2.5 py-0.5 bg-slate-950 border border-slate-800 text-slate-300 text-[10px] font-black rounded-lg shrink-0">6</span>
                          </div>
                        </div>
                      </div>

                    </div>

                  </div>

                </div>
              )}

              {activeTab === "map" && (
                <FarmingMapScreen 
                  regions={regions} 
                  onUpdateRegion={handleUpdateRegion} 
                />
              )}
              {activeTab === "attendance" && <AttendanceScreen />}
              {activeTab === "contributor" && <ContributorScreen />}
              {activeTab === "shifts" && <ShiftCalendarScreen />}
              {activeTab === "tasks" && <TaskDispatchScreen />}
              {activeTab === "approvals" && (
                <ApprovalScreen
                  approvals={approvals}
                  onAction={handleApprovalAction}
                  onReset={handleResetApprovals}
                  onAddApproval={handleAddApproval}
                />
              )}
              {activeTab === "payroll" && <PayrollScreen />}
              {activeTab === "reports" && <ReportsScreen />}
              {activeTab === "finance_business" && <FinanceBusinessScreen />}
              {activeTab === "crop_yield" && <CropYieldScreen />}
              {activeTab === "ai_weather" && <AIWeatherScreen />}
              {activeTab === "supply_chain" && <SupplyChainScreen />}
              {activeTab === "esg_sustainability" && <ESGSustainabilityScreen />}
              {activeTab === "account" && currentUser && (
                <AccountScreen user={currentUser} onUpdateUser={setCurrentUser} />
              )}
              
              {/* Existing Core Modules */}
              {activeTab === "explorer" && <DataExplorer />}
              {activeTab === "preprocessing" && <DataPreprocessing />}
              {activeTab === "sandbox" && <ModelSandbox />}

            </motion.div>
          </AnimatePresence>
        </main>

        {/* Footer */}
        <footer id="agrismart-footer" className="bg-slate-950 border-t border-slate-900 py-6 text-center text-xs text-slate-600 shrink-0 select-none">
          <p>© 2026 AgriSmart Analytics & Machine Learning Platform. Thiết lập cấu trúc bảo mật thông suốt.</p>
          <p className="mt-1 text-[10px] text-slate-700">
            Hỗ trợ kết nối kho lưu trữ GitHub và triển khai trực tiếp lên đám mây Vercel / Cloud Run.
          </p>
        </footer>

      </div>

      {/* Quick Edit Popup Modal */}
      {editingRegion && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-[9999] p-4">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-3xl w-full max-w-md shadow-2xl relative space-y-4 text-left">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-sky-400 text-[10px] font-black uppercase tracking-widest block">Hiệu chỉnh vùng trồng</span>
                <h3 className="text-slate-100 font-extrabold text-base mt-0.5">{editingRegion.name}</h3>
              </div>
              <button 
                type="button"
                onClick={() => setEditingRegion(null)}
                className="text-slate-400 hover:text-slate-200 text-sm font-bold p-1 bg-slate-950 rounded-lg border border-slate-850 cursor-pointer w-6 h-6 flex items-center justify-center"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleUpdateRegionSubmit} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Cây trồng canh tác</label>
                <input
                  type="text"
                  required
                  value={editCrop}
                  onChange={(e) => setEditCrop(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-semibold"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Diện tích quy mô (ha)</label>
                <input
                  type="number"
                  required
                  min="1"
                  max="10000"
                  value={editArea}
                  onChange={(e) => setEditArea(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-semibold font-mono"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Trạng thái sinh học</label>
                <select
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-850 rounded-xl px-3 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 font-semibold"
                >
                  <option value="active">🟢 Hoạt động (Phát triển tốt)</option>
                  <option value="warning">🟡 Cảnh báo (Rủi ro rễ/dinh dưỡng)</option>
                  <option value="idle">⚫ Tạm ngưng canh tác</option>
                </select>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingRegion(null)}
                  className="flex-1 py-2.5 bg-slate-950 border border-slate-850 hover:bg-slate-850 text-slate-300 text-xs font-bold rounded-xl transition-all cursor-pointer text-center"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-slate-100 text-xs font-black rounded-xl transition-all shadow-lg shadow-indigo-950/40 cursor-pointer text-center"
                >
                  Cập nhật ngay
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
